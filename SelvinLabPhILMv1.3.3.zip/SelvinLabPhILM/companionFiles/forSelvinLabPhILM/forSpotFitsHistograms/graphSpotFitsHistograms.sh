

CreateHistogramFilesForSpotFits -l ../A5_50.shrimpFits.txt 106.67 2.5 20
gnuplot localizationErrorGraph_a.plt 

timeOptions="0.2 20 20"
CreateHistogramFilesForSpotFits -i ../../3.tif $timeOptions
CreateHistogramFilesForSpotFits -f ../A5_50.shrimpFits.txt $timeOptions
gnuplot spotsPerFrameHistogram_a.plt

