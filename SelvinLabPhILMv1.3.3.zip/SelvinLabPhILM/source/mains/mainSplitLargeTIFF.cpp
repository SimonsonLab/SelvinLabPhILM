//
//  mainSplitLargeTIFF.cpp
//  SelvinLabPhILM_XCode
//
//  Created by Paul Simonson on 3/31/11.
//  Copyright 2011 University of Illinois at Urbana-Champaign. All rights reserved.
//

#include <vector>
#include <iostream>
#include <fstream>


#include "Magick++.h"
#include "SimonsonLibTIFF_IO.h"



void showUsage(void)
{
    std::cout << "Usage: SplitLargeTIFF framesPerDivision tiffFileName minSpacing threshold zoomFactor outputFolder\n";
}


///This function splits the large tiff and writes the resulting sections.
///It is waaaaaay too slow for large images!
void writeImages(std::string originalTIFFFileName, const unsigned int numFramesPerDivision, const unsigned int numDivisions)
{
    std::vector< Magick::Image > imageVector;
    readImages( &imageVector, originalTIFFFileName);
    //unsigned int numFramesTotal = (unsigned int)imageVector.size();
    
    
    char startingCharacter = 'a';
    
    unsigned int i;
    //#pragma omp parallel for
    for (i = 0; i < numDivisions - 1; i++) {
        std::string newFileName(1, startingCharacter);
        newFileName.append(".tif");
        startingCharacter++;
        std::cout << "New file name is " << newFileName << "\n";
        
        std::vector<Magick::Image>::iterator startIterator = imageVector.begin() + i * numFramesPerDivision;
        std::vector<Magick::Image>::iterator endIterator = startIterator + numFramesPerDivision;
        
        writeImages(startIterator, endIterator, newFileName);
    }
    
    //Last division should be handled separately because there might not be enough frames to make a whole division.
    {
        std::string newFileName(1, startingCharacter);
        newFileName.append(".tif");
        std::cout << "New file name is " << newFileName << "\n";
        
        std::vector<Magick::Image>::iterator startIterator = imageVector.begin() + (numDivisions - 1) * numFramesPerDivision;
        std::vector<Magick::Image>::iterator endIterator = imageVector.end();
        
        writeImages(startIterator, endIterator, newFileName);
    }

}

///This function writes fast compared to the ImageMagick version.
void writeImagesUsingSimonsonLibTIFF_IO(std::string originalTIFFFileName, const unsigned int numFramesPerDivision, const unsigned int numDivisions)
{
    std::vector< TNT::Array2D<unsigned int> > imageVector = SimonsonLibTIFF_IO::readTIFFStack<unsigned int>(originalTIFFFileName);
    
    std::cout << "Finished reading in file " << originalTIFFFileName << "\n";
    
    
    char startingCharacter = 'a';
    
    unsigned int i;
    //#pragma omp parallel for
    for (i = 0; i < numDivisions - 1; i++) {
        std::string newFileName(1, startingCharacter);
        newFileName.append(".tif");
        startingCharacter++;
        std::cout << "New file name is " << newFileName << "\n";
        
        unsigned int startFrame = i * numFramesPerDivision + 1;
        unsigned int endFrame = startFrame + numFramesPerDivision - 1;
        
        SimonsonLibTIFF_IO::writePartialTIFFStack(newFileName, imageVector, startFrame, endFrame);
    }
    
    //Last division should be handled separately because there might not be enough frames to make a whole division.
    {
        std::string newFileName(1, startingCharacter);
        newFileName.append(".tif");
        std::cout << "New file name is " << newFileName << "\n";
        
        unsigned int startFrame = i * numFramesPerDivision + 1;
        unsigned int endFrame = imageVector.size();
        
        SimonsonLibTIFF_IO::writePartialTIFFStack(newFileName, imageVector, startFrame, endFrame);
    }
    
}

void writeScriptToConcatenateResults(const unsigned int numFramesPerDivision, const unsigned int numDivisions, int argc, char *argv[])
{
    std::ofstream outputFile("concatenateResults.sh");

    //Now for writing the commands to concatenate the results.
    if (numDivisions > 1) 
    {
        //Write the lines for concatenating fits files.
        char startingCharacter;
        outputFile << "SelvinLabPhILM -w a.spotFits.txt b.spotFits.txt spotFits.txt\n";
        if (numDivisions > 2) {
            startingCharacter = 'c';
            unsigned int i;
            for (i = 2; i < numDivisions; i++) {
                std::string newFileName(1, startingCharacter);
                newFileName.append(".tif");
                outputFile << "SelvinLabPhILM -w spotFits.txt " << startingCharacter << ".spotFits.txt spotFits.txt\n";
                startingCharacter++;
            }
        }
        //write the lines for drawing the final super-resolution images.
        outputFile << "SelvinLabPhILM -g " << "a.tif" << " " << argv[3] << " " << argv[4] << " " << argv[5] << " " << argv[6] << " " <<"\n";
        outputFile << "SelvinLabPhILM -h " << "a.tif" << " " << argv[3] << " " << argv[4] << " " << argv[5] << " " << argv[6] << " " <<"\n";
        outputFile << "SelvinLabPhILM -i " << "a.tif" << " " << argv[3] << " " << argv[4] << " " << argv[5] << " " << argv[6] << " " <<"\n";
        outputFile << "SelvinLabPhILM -m " << "a.tif" << " " << argv[3] << " " << argv[4] << " " << argv[5] << " " << argv[6] << " " <<"\n";
    }
    else
    {
        std::cout << "Error: there was only one tiff file, so not enough to concatenate...\n";
    }
    
    outputFile.close();
}

void writeUNIXScriptToProcessImages(const unsigned int numFramesPerDivision, const unsigned int numDivisions, int argc, char *argv[])
{
    std::ofstream outputFile("processSplitTIFF.sh");
    char startingCharacter = 'a';

    if (argc > 5) {
        unsigned int i;
        for (i = 0; i < numDivisions; i++) {
            std::string newFileName(1, startingCharacter);
            newFileName.append(".tif");
            outputFile << "SelvinLabPhILM -A " << newFileName << " " << argv[3] << " " << argv[4] << " " << argv[5] << " " << argv[6] << " " << startingCharacter << ".\n";
            startingCharacter++;
        }
    }
    else
    {
        unsigned int i;
        for (i = 0; i < numDivisions; i++) {
            std::string newFileName(1, startingCharacter);
            newFileName.append(".tif");
            outputFile << "SelvinLabPhILM -A " << newFileName << " 6 50 10.667 ./ " << startingCharacter << ".\n";
            startingCharacter++;
        }
    }
    
    if (numDivisions > 1) {
        outputFile << "sh concatenateResults.sh\n";
    }
    
    outputFile.close();
    std::cout << "Script file was created.\n";
}




void writeOneCondorFile(const char startingCharacter, const int argc, char *argv[])
{
    
    std::string newFileName(1, startingCharacter);
    newFileName.append(".condorFile.txt");
    
    std::ofstream outputFile(newFileName.c_str());

    outputFile 
    << "Executable     = /home/psimonso/SelvinLabPhILM/dist/bin/SelvinLabPhILM/SelvinLabPhILM\n"
    << "Universe       = vanilla\n"
    << "should_transfer_files = yes\n"
    << "when_to_transfer_output = on_exit\n"
    << "transfer_input_files = " << startingCharacter << ".tif, PhILMPreferences.txt\n\n"
    << "Arguments      = -A " << startingCharacter << ".tif " << " " << argv[3] << " " << argv[4] << " " << argv[5] << " " << argv[6] << " " << startingCharacter << ".\n"
    << "Output  = " << startingCharacter << ".output.txt\n"
    << "Error  = " << startingCharacter << ".error.txt\n"
    << "log  = " << startingCharacter << ".log.txt\n"
    << "getEnv = true\n"
    << "Queue\n"
    ;
    
    outputFile.close();
}

void writeCondorFiles(const unsigned int numFramesPerDivision, const unsigned int numDivisions, int argc, char *argv[])
{
    char startingCharacter = 'a';
    
    if (argc > 5) {
        unsigned int i;
        for (i = 0; i < numDivisions; i++) 
        {
            writeOneCondorFile(startingCharacter, argc, argv);
            startingCharacter++;
        }
    }
    
    startingCharacter = 'a';
    std::ofstream submitCondorJobsFile("submitCondorJobs.sh");
    unsigned int i;
    for (i = 0; i < numDivisions; i++) 
    {
        submitCondorJobsFile << "condor_submit " << startingCharacter << ".condorFile.txt\n";
        startingCharacter++;
    }
    submitCondorJobsFile.close();
    
}


int main(int argc, char *argv[])
{
    showUsage();
    
    unsigned int numFramesPerDivision;
    if (argc < 2) {
        std::cout << "How many frames per division?  Suggested is 2000: ";
        std::cin >> numFramesPerDivision;
    }
    else {
        numFramesPerDivision = strtod(argv[1], NULL);
    }
    
    std::string inputFileName;
    if (argc < 3) {
        std::cout << "Enter input TIFF file name: ";
        std::cin >> inputFileName;
    }
    else 
    {
        inputFileName = argv[2];
    }
    
    //std::vector< Magick::Image > imageVector;
    //readImages( &imageVector, inputFileName);
    unsigned int numFramesTotal = SimonsonLibTIFF_IO::countFramesInTIFFStack(inputFileName);
    
    unsigned int numDivisions = numFramesTotal/numFramesPerDivision;
    if (numFramesPerDivision * numDivisions < numFramesTotal) {
        numDivisions++;
    }
        
    //writeImages(inputFileName, numFramesPerDivision, numDivisions);
    writeImagesUsingSimonsonLibTIFF_IO(inputFileName, numFramesPerDivision, numDivisions);

    writeUNIXScriptToProcessImages(numFramesPerDivision, numDivisions, argc, argv);
    
    writeCondorFiles(numFramesPerDivision, numDivisions, argc, argv);

    writeScriptToConcatenateResults(numFramesPerDivision, numDivisions, argc, argv);

    return 0;
}

