/*
 *  fitTo2DGaussianUsingGSL.h
 *  TwoPhotonMicroscopy
 *
 *  Created by Paul Simonson on 5/30/08.
 *  Copyright 2008 __MyCompanyName__. All rights reserved.
 *
 */



#ifndef fitTo2DGaussianUsingGSL_HEADER
#define fitTo2DGaussianUsingGSL_HEADER

#include <vector>
//#include "FreeImage.h"
#include "tnt.h"
#include "twoDGaussianFit.h"

namespace Fitting2DGaussianUsingGSL {
	

	
	int printFit(TwoDGaussianFittingParametersAndErrors);
	
	std::vector<double> returnFitAsVector(TwoDGaussianFittingParametersAndErrors);
	
	double estimateTotalCountsUsingFittingParameters(TwoDGaussianFittingParametersAndErrors fittingParameters);
	double estimateTotalPhotonsUsingFittingParameters(TwoDGaussianFittingParametersAndErrors fittingParameters, 
													  double countsToPhotonsConversionFactor);

	
	TwoDGaussianFittingParametersAndErrors fitTo2DGaussianUsingGSL(std::vector<double> xPositions, 
																		  std::vector<double> yPositions, 
																		  std::vector<double> pixelIntensities);
	
	/*TwoDGaussianFittingParametersAndErrors weightedFitTo2DGaussianUsingGSL(std::vector<double> xPositions, 
																				  std::vector<double> yPositions, 
																				  std::vector<double> pixelIntensities, 
																				  std::vector<double> sigmas);*/
	
	//weightedFitTo2DGaussianUsingGSL
	TwoDGaussianFittingParametersAndErrors 
	weightedFitTo2DGaussianUsingGSL(std::vector<double> xPositions, 
									std::vector<double> yPositions, 
									std::vector<double> pixelIntensities, 
									std::vector<double> sigmas,
									int verboseFitting = 0);
	
	
	TwoDGaussianFittingParametersAndErrors 
	weightedFitTo2DGaussian(std::vector<double> xPositions, 
							std::vector<double> yPositions, 
							std::vector<double> pixelIntensities, 
							double cameraBaseline, 
							double backgroundNoise);
	
	TwoDGaussianFittingParametersAndErrors 
	weightedFitTo2DGaussian(std::vector<double> xPositions, 
							std::vector<double> yPositions, 
							std::vector<double> pixelIntensities, 
							double backgroundNoise);

	TwoDGaussianFittingParametersAndErrors 
	weightedFitTo2DGaussian(std::vector<double> xPositions, 
							std::vector<double> yPositions, 
							std::vector<double> pixelIntensities, 
							std::vector<double> presubtractedPixelIntensities, 
							double cameraBaseline, 
							double backgroundNoise,
							int numFramesToBeAveragedBeforePhotobleaching = 1,
							int numFramesToBeAveragedAfterPhotobleaching = 1);
												
	TwoDGaussianFittingParametersAndErrors 
	weightedFitTo2DGaussian(std::vector<double> xPositions, 
							std::vector<double> yPositions, 
							std::vector<double> pixelIntensities, 
							std::vector<double> preSubtractedPixelIntensities, 
							double backgroundNoise,
							int numFramesToBeAveragedBeforePhotobleaching = 1,
							int numFramesToBeAveragedAfterPhotobleaching = 1);
	
	double returnSpotWidth(std::vector<double> xPositions, 
						   std::vector<double> yPositions, 
						   std::vector<double> pixelIntensities);
	
	TwoDGaussianFittingParametersAndErrors 
	subtractRectangularImageAndFitTo2DGaussian(char *inputFileName, int frameNumberToAnalyze, int frameNumberToSubtract, double backgroundNoise);
	
	TwoDGaussianFittingParametersAndErrors 
	subtractRoundImageAndFitTo2DGaussian(char *inputFileName, 
										 int frameNumberToAnalyze, 
										 int frameNumberToSubtract, 
										 double backgroundNoise, 
										 double x, 
										 double y, 
										 double spotRadius,
										 int numFramesToBeAveragedBeforePhotobleaching = 1,
										 int numFramesToBeAveragedAfterPhotobleaching = 1);
	
	TwoDGaussianFittingParametersAndErrors 
	subtractRoundImageAndFitTo2DGaussian(TNT::Array2D<int> beforePhotobleachingArray,
										 TNT::Array2D<int> afterPhotobleachingArray,
										 double backgroundNoise, 
										 double x, 
										 double y, 
										 double spotRadius,
										 int numFramesToBeAveragedBeforePhotobleaching = 1,
										 int numFramesToBeAveragedAfterPhotobleaching = 1);
	
	TwoDGaussianFittingParametersAndErrors 
	subtractRoundImageAndFitTo2DGaussian(TNT::Array2D<int> beforePhotobleachingArray,
										 TwoDGaussianFittingParametersAndErrors fitOfLastFluorophore,
										 double backgroundNoise, 
										 double x, 
										 double y, 
										 double spotRadius,
										 int numFramesToBeAveragedBeforePhotobleaching = 1,
										 int numFramesToBeAveragedAfterPhotobleaching = 1);

	double estimateTotalCountsUsingFittingParameters(TwoDGaussianFittingParametersAndErrors fittingParameters);

	TwoDGaussianFittingParametersAndErrors 
	fitIndicatedSpotTo2DGaussian(char *inputFileName, 
								 int frameNumberToAnalyze, 
								 double backgroundNoise, 
								 double x, 
								 double y, 
								 double spotRadius);
	/*
	TwoDGaussianFittingParametersAndErrors 
	fitIndicatedSpotTo2DGaussian(FIMULTIBITMAP *multibitmap, 
								 int frameNumberToAnalyze, 
								 double backgroundNoise, 
								 double x, 
								 double y, 
								 double spotRadius);
	 */
	
	TwoDGaussianFittingParametersAndErrors 
	fitIndicatedSpotTo2DGaussianTNT(TNT::Array2D<int> imageArray, 
								 double backgroundNoise, 
								 double x, 
								 double y, 
								 double spotRadius);
}

#endif


