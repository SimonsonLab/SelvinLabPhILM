/*
 *  ExponentialDecayFit.cpp
 *  ReverseSTORM_SL
 *
 *  Created by Paul Simonson on 3/22/10.
 *  Copyright 2010 University of Illinois at Urbana-Champaign. All rights reserved.
 *
 */

#include "ExponentialDecayFit.h"

ExponentialDecayFit::ExponentialDecayFit()
{
	A = B = C = 1;
	A_error = B_error = C_error = 0;
	numIterations = 0;
	frameAcquisitionTime = 1;
	
	fitTolerance = 1e-10;
	maxNumberOfFitIterations = 1000;
}

struct data {
	size_t n;
	double * y;
	double * sigma;
	double frameAcquisitionTime;
};


int ExponentialDecayFit::expb_f (const gsl_vector * x, void *data, gsl_vector * f)
{
	size_t n = ((struct data *)data)->n;
	double *y = ((struct data *)data)->y;
	double *sigma = ((struct data *) data)->sigma;
	double frameAcquisitionTime = ((struct data *) data)->frameAcquisitionTime;
	
	double A = gsl_vector_get (x, 0);
	double B = gsl_vector_get (x, 1);
	double C = gsl_vector_get (x, 2);
	
	size_t i;
	
	for (i = 0; i < n; i++)
	{
		double Yi = A * exp(-((double)i * frameAcquisitionTime)/B) + C;
		gsl_vector_set (f, i, (Yi - y[i]) / sigma[i]);
	}
	
	return GSL_SUCCESS;
}

int ExponentialDecayFit::expb_df (const gsl_vector * x, void *data, gsl_matrix * J)
{
	size_t n = ((struct data *)data)->n;
	double *sigma = ((struct data *) data)->sigma;
	double frameAcquisitionTime = ((struct data *) data)->frameAcquisitionTime;

	double A = gsl_vector_get (x, 0);
	double B = gsl_vector_get (x, 1);
	//double C = gsl_vector_get (x, 2);
	
	size_t i;
	
	for (i = 0; i < n; i++)
	{
		/* Jacobian matrix J(i,j) = dfi / dxj, */
		/* where fi = (Yi - yi)/sigma[i],      */
		/*       Yi = A * exp(-lambda * i) + b  */
		/* and the xj are the parameters (A,lambda,b) */
		
		double partial_A = exp(-((double)i * frameAcquisitionTime)/B);
		double partial_B = A * exp(-((double)i * frameAcquisitionTime)/B) * ((double)i * frameAcquisitionTime)/(B*B);
		double partial_C = 1;
		
		gsl_matrix_set (J, i, 0, partial_A /sigma[i]); 
		gsl_matrix_set (J, i, 1, partial_B /sigma[i]);
		gsl_matrix_set (J, i, 2, partial_C /sigma[i]); 
	}
	return GSL_SUCCESS;
}

int ExponentialDecayFit::expb_fdf (const gsl_vector * x, void *data, gsl_vector * f, gsl_matrix * J)
{
	expb_f (x, data, f);
	expb_df (x, data, J);
	
	return GSL_SUCCESS;
}

void ExponentialDecayFit::print_state (size_t iter, gsl_multifit_fdfsolver * s)
{
	printf ("iter: %3u x = % 15.8f % 15.8f % 15.8f "
			"|f(x)| = %g\n",
			(unsigned int)iter,
			gsl_vector_get (s->x, 0), 
			gsl_vector_get (s->x, 1),
			gsl_vector_get (s->x, 2), 
			gsl_blas_dnrm2 (s->f));
}

void ExponentialDecayFit::fit(double frameAcquisitionTimeInput, std::vector<double> yValuesInput, std::vector<double> sigmasInput, bool verboseFitting)
{
	numIterations = 0;
	yValues.clear();
	yValues = yValuesInput;
	sigmas = sigmasInput;
	
	const gsl_multifit_fdfsolver_type *T;
	gsl_multifit_fdfsolver *s;
	int status;
	unsigned int i, iter = 0;
	const size_t n = yValues.size();
	const size_t p = 3;
	
	//Determine initial fitting parameters
	C = yValues.at(n - 1);
	A = yValues.at(0) - C;
	B = 1;
	
	gsl_matrix *covar = gsl_matrix_alloc (p, p);
	
	double y[n], sigma[n];
	struct data d = { n, y, sigma, frameAcquisitionTimeInput};
	
	gsl_multifit_function_fdf f;		
	double x_init[p] = {A, B, C};
	
	gsl_vector_view x = gsl_vector_view_array (x_init, p);

	
	f.f = &expb_f;
	f.df = &expb_df;
	f.fdf = &expb_fdf;
	f.n = n;
	f.p = p;
	f.params = &d;
		
	// These are the data to be fitted
	for (i = 0; i < n; i++)
	{
		y[i] = yValues.at(i);
		sigma[i] = sigmas.at(i);
	}


	T = gsl_multifit_fdfsolver_lmsder;
	s = gsl_multifit_fdfsolver_alloc (T, n, p);
	gsl_multifit_fdfsolver_set (s, &f, &x.vector);
	
	if(verboseFitting)
		print_state (iter, s);

	do
	{
		iter++;
		status = gsl_multifit_fdfsolver_iterate (s);
		
		if(verboseFitting)
		{
			printf ("status = %s\n", gsl_strerror (status));
			print_state (iter, s);
		}
		
		if (status)
			break;
		
		status = gsl_multifit_test_delta (s->dx, s->x,
										  fitTolerance, fitTolerance);
	}
	while (status == GSL_CONTINUE && iter < maxNumberOfFitIterations);
	
	if(iter == maxNumberOfFitIterations)
		if(verboseFitting)
			std::cout << "Could not fit within " << maxNumberOfFitIterations << " iterations.\n";
	
	//std::cout << gsl_strerror (status) << "\n";
	
	gsl_multifit_covar (s->J, 0.0, covar);
	
#define FIT(i) gsl_vector_get(s->x, i)
#define ERR(i) sqrt(gsl_matrix_get(covar,i,i))
	
	
	{
		double chi = gsl_blas_dnrm2(s->f);
		double dof = n - p;
		double c = GSL_MAX_DBL(1, chi / sqrt(dof)); 
		
		if(verboseFitting)
		{
			printf("chisq/dof = %g\n",  pow(chi, 2.0) / dof);
			printf ("A	=	%.5f +/- %.5f\n", FIT(0), c*ERR(0));
			printf ("B	=	%.5f +/- %.5f\n", FIT(1), c*ERR(1));
			printf ("C	=	%.5f +/- %.5f\n", FIT(2), c*ERR(2));
		}
		
		A =  FIT(0);
		B =  FIT(1);
		C =  FIT(2);
		
		A_error = c*ERR(0);
		B_error = c*ERR(1);
		C_error = c*ERR(2);
	}
	if(verboseFitting)
		printf ("status = %s\n", gsl_strerror (status));
	gsl_multifit_fdfsolver_free (s);
	gsl_matrix_free (covar);
}


