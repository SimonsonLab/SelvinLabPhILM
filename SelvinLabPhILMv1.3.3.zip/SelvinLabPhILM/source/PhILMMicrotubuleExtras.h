/*
 *  PhILMMicrotubuleExtras.h
 *  
 *
 *  Created by Paul Simonson on 2/7/11.
 *  Copyright 2011 Champaign Illinois Stake. All rights reserved.
 *
 */


#ifndef PhILMMicrotubuleExtras_H
#define PhILMMicrotubuleExtras_H

#include <iostream>
#include <fstream>

#include "FreeImage.h"
#include "tnt.h"
#include "Magick++.h"


#include "ScienceFile.h"
#include "twoDGaussianFit.h"
#include "ExponentialDecayFit.h"
#include "drawingSuperResolutionImages.h"
#include "PhILMPreferences.h"

using namespace DrawingSuperResolutionImages;

namespace PhILM_namespace
{

	//Finding microtubule widths
	int concatenateShrimpFitsFiles(const char* firstFile, const char * secondFile, const char * outputFile);
	
	std::vector<double> fitDataToStraightLine(std::vector<double> x0s, std::vector<double> y0s);
	std::vector<double> rotateCoordinates(double x, double y, double rotationAngle);
	int rotateShrimpFitsFile(const char *inputFileName, const char *outputFileName, double rotationAngle, double yIntercept);
	
	
	class MicrotubuleLineFit {
	public:
		MicrotubuleLineFit()
		{
			superResolutionZoomFactor = 10.667;
			calculationDone = 0;
		}
		
		Magick::Image outputImage;
		std::vector<double> lineFit;
		double superResolutionZoomFactor;
		
		std::string tiffFileName;
		std::string outputDirectory;
		std::string outputFilePrefix;
		
		int setTIFFFileName(const char *fileName)
		{
			tiffFileName = fileName;
			chooseOutputDirectoryUsingTIFFName();
			return 0;
		}
		
		std::string formOutputFilePath(std::string simpleFileName)
		{
			std::string newFilePath;
			newFilePath = outputDirectory + outputFilePrefix + simpleFileName;
			return newFilePath;
		}
		
		
		void drawLineFitInSuperResolutionImage();
		
		
		void drawLineFitInSuperResolutionImage(const std::string outputFileName)
		{
			drawLineFitInSuperResolutionImage();
			outputImage.write(formOutputFilePath(outputFileName));
		}
		
		
	private:
		bool calculationDone;
		int chooseOutputDirectoryUsingTIFFName(void)
		{
			size_t found;
			
			found = tiffFileName.find("/");
			if(found != std::string::npos)
			{
				
				std::cout << "Splitting: " << tiffFileName << std::endl;
				found = tiffFileName.find_last_of("/\\");
				
				outputDirectory = tiffFileName.substr(0,found) + "/";
				
				std::cout << " output folder: " << outputDirectory << std::endl;
				std::cout << " tiff file: " << tiffFileName.substr(found+1) << std::endl;
			}
			else {
				outputDirectory = "./";
				std::cout << " output folder: " << outputDirectory << std::endl;
				std::cout << " tiff file: " << tiffFileName.substr(found+1) << std::endl;
			}
			return 0;
		}
		
		int convertFitXToOutputX(int fitX);
		int convertFitYToOutputY(int fitY, int height);
		
	};
	
	
}

#endif
