/*
 *  reversePhotobleachingSTORM.h
 *  ReverseSTORM
 *
 *  Created by Paul Simonson on 4/24/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef reversePhotobleachingSTORM_H
#define reversePhotobleachingSTORM_H

#include <iostream>
#include <fstream>

#include "FreeImage.h"
#include "tnt.h"


#include "ScienceFile.h"
#include "twoDGaussianFit.h"
#include "ExponentialDecayFit.h"
#include "drawingSuperResolutionImages.h"
#include "PhILMPreferences.h"

using namespace DrawingSuperResolutionImages;

namespace PhILM_namespace 
{
	int checkWhetherFileIsPresent(const char *cpath);
	int checkForExitCommand(const char *cpath);
	
	int createBackwardsSubtractedTIFFs(FIMULTIBITMAP *multibitmap);
	
    
    std::vector< TNT::Array2D< int > > returnBackwardsSubtracted(std::vector< TNT::Array2D< int > > &imageVector);
    
    //int calculateSpotFrameRanges(const char *tiffFileName = "backwardsSubtracted.tif", double minimumSeparation = 0);
    //int calculateAntiSpotFrameRanges(const char *tiffFileName = "backwardsSubtracted.tif", double minimumSeparation = 0);
    int fastCalculateSpotFrameRanges(const char *tiffFileName = "backwardsSubtracted.tif", double minimumSeparation = 0);
    int fastCalculateAntiSpotFrameRanges(const char *tiffFileName = "backwardsSubtracted.tif", double minimumSeparation = 0);
    void throwAwayIntermediateFramesUsingFrameRangesFiles(void);
    
    int createSpotFitsFile(const char *inputFileName, int minimumNumberOfFramesToAverage, double darkCountsNoise);
    int createSpotFitsFile(std::vector< TNT::Array2D< int > > &imageVector, int minimumNumberOfFramesToAverage, double darkCountsNoise);
    
    int createSpotFitsFileFromBackwardsSubtracted(const char *inputFileName, double darkCountsNoise, double minimumSeparation);
    
    //int createDriftCorrectedSpotFitsFile(const char *driftCorrectionFileName, const char *spotFitsFileName, const char *outputFileName);
    
    int checkWhetherSpotIsGood(TwoDGaussianFittingParametersAndErrors &spotFit, bool verboseSpotChecking = false);
    
}

#endif
