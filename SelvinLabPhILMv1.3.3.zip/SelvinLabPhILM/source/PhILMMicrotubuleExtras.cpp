/*
 *  PhILMMicrotubuleExtras.cpp
 *  
 *
 *  Created by Paul Simonson on 2/7/11.
 *  Copyright 2011 Champaign Illinois Stake. All rights reserved.
 *
 */

#include "PhILMMicrotubuleExtras.h"

#include <cstring>
#include <vector>
#include <iostream>
#include <fstream>
#include <list>
#include <cmath>

//#include "Magick++.h"
#include "writeTIFFFileUsingMagick.h"
#include "PhILMCoreCode.h"
#include "return2DArrayFromMultiBitmap.h"
#include "ScienceFile.h"
#include "tiffStackOperations.h"
#include "tiffFrameOperations.h"
#include "returnSpotIntensity.h"
//#include "fitTo2DGaussianUsingGSL.h"
#include "fitTo2DEllipticalGaussian.h"
#include "tiffFrameOperations.h"
#include "basicStatistics.h"
#include "FreeImage.h"

using namespace Fitting2DEllipticalGaussianUsingGSL;

#define RESTRICTING_FRAME_RANGES


extern PhILMPreferences thePhILMPreferences;
extern const int newPixelOffset;
const double pixelShiftForDrawingSuperResolutionImages = 0.5;

namespace PhILM_namespace 
{	

	std::vector<double> rotateCoordinates(double x, double y, double rotationAngle)
	{
		double rotationMatrix[2][2];
		rotationMatrix[0][0] = cos(rotationAngle);
		rotationMatrix[0][1] = -sin(rotationAngle);
		rotationMatrix[1][0] = sin(rotationAngle);
		rotationMatrix[1][1] = cos(rotationAngle);
		
		std::vector<double> newCoordinates;
		newCoordinates.push_back(rotationMatrix[0][0] * x + rotationMatrix[0][1] * y);
		newCoordinates.push_back(rotationMatrix[1][0] * x + rotationMatrix[1][1] * y);
		
		return newCoordinates;
	}
	
	
	int rotateShrimpFitsFile(const char *inputFileName, const char *outputFileName, double rotationAngle, double yIntercept)
	{
		ScienceFile shrimpFitsFile(inputFileName);
		int numSpots = shrimpFitsFile.numRows();
		int i;
		for(i = 0; i < numSpots; i++)
		{
			double x = shrimpFitsFile.at(i, 1);
			double y = shrimpFitsFile.at(i, 2) - yIntercept;
			std::vector<double> newCoordinates = rotateCoordinates(x, y, rotationAngle);
			shrimpFitsFile.setElement(i, 1, newCoordinates.at(0));
			shrimpFitsFile.setElement(i, 2, newCoordinates.at(1));
		}
		shrimpFitsFile.writeToFile(outputFileName);
		return 0;
	}
	
	
	//From "An Introduction to Error Analysis" by John R. Taylor, 2nd Edition, page 184.
	std::vector<double> fitDataToStraightLine(std::vector<double> x0s, std::vector<double> y0s)
	{
		std::vector<double> lineFit;
		
		double sumX = 0;
		double sumY = 0;
		double sumXSquared = 0;
		double sumXY = 0;
		
		int numPoints = x0s.size();
		int i;
		for(i = 0; i < numPoints; i++)
		{
			sumX += x0s.at(i);
			sumY += y0s.at(i);
			sumXSquared += pow(x0s.at(i), 2);
			sumXY += x0s.at(i) * y0s.at(i);
		}
		
		double delta = numPoints * sumXSquared - pow(sumX, 2);
		double oneOverDelta = 1.0L/delta;
		
		double B = oneOverDelta * (sumXSquared * sumY - sumX * sumXY);
		double A = oneOverDelta * (numPoints * sumXY - sumX * sumY);
		
		std::cout << "Line fit: slope = " << A << ", intercept = " << B << "\n";
		
		lineFit.push_back(A);
		lineFit.push_back(B);
		return lineFit;
	}
	
	
	int concatenateShrimpFitsFiles(const char* firstFile, const char * secondFile, const char * outputFile)
	{
		ScienceFile file1(firstFile);
		ScienceFile file2(secondFile);
		
		int lastFrameInFile1 = ScienceFile::findMax(file1.returnColumn(16));
		
		std::cout << "The last frame in file 1 is " << lastFrameInFile1 << ".\n";
		
		int numRowsInFile2 = file2.numRows();
		
		int i;
		
		for(i = 0; i < numRowsInFile2; i++)
		{
			file2.setElement(i, 14, file2.at(i,14) + lastFrameInFile1);
			file2.setElement(i, 15, file2.at(i,15) + lastFrameInFile1);
			file2.setElement(i, 16, file2.at(i,16) + lastFrameInFile1);
			
			file1.addRow(file2.returnRow(i));
		}
		
		file1.writeToFile(outputFile, "%%peakHeight	x0	y0	xWidth	yWidth	background	tiltAngle	peakHeightError	x0Error	y0Error	xWidthError	yWidthError	backgroundError tiltAngleError");
		
		return 0;
	}
	
	
	int createDriftCorrectedSpotFitsFile(const char *driftCorrectionFileName, const char *spotFitsFileName, const char *outputFileName)
	{
		const int frameWherePhotobleachingOccursColumn = 15;
		const int x0Column = 1;
		const int y0Column = 2;
		
		ScienceFile stageDriftCorrectionFile(driftCorrectionFileName);
		ScienceFile spotFitsFile(spotFitsFileName);
		
		double driftOriginX = stageDriftCorrectionFile.at(0, 1);
		double driftOriginY = stageDriftCorrectionFile.at(0, 2);
		
		int numSpotFits = spotFitsFile.numRows();
		int i;
		for (i = 0; i < numSpotFits; i++) 
		{
			//std::cout << "i = " << i << "\n";
			int frameOfTheGivenSpot = spotFitsFile.at(i, frameWherePhotobleachingOccursColumn) - 1;
			
			double xCorrection = driftOriginX - stageDriftCorrectionFile.at(frameOfTheGivenSpot, 1);
			double yCorrection = driftOriginY - stageDriftCorrectionFile.at(frameOfTheGivenSpot, 2);
			
			//std::cout << "Drift correcting spot" << i + 1 << ", frameOfTheGivenSpot = " << frameOfTheGivenSpot << ", " << xCorrection << "	" << yCorrection << "\n";
			
			//std::cout << "This far...\n";
			double newX = xCorrection + spotFitsFile.at(i, x0Column);
			double newY = yCorrection + spotFitsFile.at(i, y0Column);
			
			spotFitsFile.setElement(i, x0Column, newX);
			spotFitsFile.setElement(i, y0Column, newY);
		}
		
		spotFitsFile.writeToFile(outputFileName);
		std::cout << "Created " << outputFileName << ".\n";
		
		return 0;
	}
	
	
	int MicrotubuleLineFit::convertFitXToOutputX(int fitX)
	{
		return superResolutionZoomFactor * (fitX + pixelShiftForDrawingSuperResolutionImages);
	}
	
	
	int MicrotubuleLineFit::convertFitYToOutputY(int fitY, int height)
	{
		return superResolutionZoomFactor * (height - 1 - fitY + pixelShiftForDrawingSuperResolutionImages);
	}
	
	
	void MicrotubuleLineFit::drawLineFitInSuperResolutionImage(void)
	{
		outputImage.read(formOutputFilePath("superResolutionImage.pixels.tif").c_str());
		outputImage.normalize();
		
		// Set draw options
		outputImage.strokeColor("red"); // Outline color
		outputImage.strokeWidth(1);
		
		//Draw the line
		
		if(checkWhetherFileIsPresent((tiffFileName).c_str()))
		{
			std::cout << "Tiff file " << (tiffFileName) << " is present.\a\n";
		}
		else {
			std::cout << "Tiff file " << (tiffFileName) << " is not present.\a\a\n";
		}
		
		Magick::Image originalImage(tiffFileName);
		
		std::cout << "This far..." << std::endl;
		
		superResolutionZoomFactor = (double)outputImage.rows()/(double)originalImage.rows();
		int rows, columns;
		columns = originalImage.columns();
		rows = originalImage.rows();
		int startX, startY, endX, endY;
		
		//y = mx + B
		double m = lineFit.at(0);
		double B = lineFit.at(1);
		
		if (B >= 0 && B < rows) {
			startX = 0;
			endX = columns - 1;
			startY = B;
			endY = m*(columns - 1) + B;
		}
		else {
			startY = 0;
			endY = rows - 1;
			startX = (startY-B)/m;
			endX = (endY - B)/m;
		}
		
		startX = convertFitXToOutputX(startX);
		endX = convertFitXToOutputX(endX);
		startY = convertFitYToOutputY(startY, rows);
		endY = convertFitYToOutputY(endY, rows);
		
		std::cout	<< startX << "	"
		<< endX << "	"
		<< startY << "	"
		<< endY << "\n";
		
		outputImage.draw(Magick::DrawableLine(startX,startY,endX,endY));
		
		calculationDone = 1;
		
		outputImage.display();
	}
	
	
}
