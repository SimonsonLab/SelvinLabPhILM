/*
 *  drawingSuperResolutionImages.h
 *  ReverseSTORM_SL
 *
 *  Created by Paul Simonson on 8/14/10.
 *  Copyright 2010 University of Illinois at Urbana-Champaign. All rights reserved.
 *
 */

#ifndef drawingSuperResolutionImages_H
#define drawingSuperResolutionImages_H


#include "FreeImage.h"
#include "tnt.h"

namespace DrawingSuperResolutionImages {
	
	enum DrawingStyles {
		standard = 0, maxZProject, pixels, normalizedSpots, PhILMDrawingStyle
	};
	
	
	//Drawing functions
	double gaussian2D(double x, 
					  double y, 
					  double peakHeight, 
					  double x0, 
					  double y0, 
					  double x0Error, 
					  double y0Error);
	
	int drawGaussianSpot(TNT::Array2D<int> superResolutionImage, 
						 double peakHeight, 
						 double x0, 
						 double y0, 
						 double x0Error, 
						 double y0Error);
	

	
	///For drawingStyle, choose 0 for normal Gaussian spot drawing, 1 for max z project, and 2 for pixels.
	void quicklyDrawSpotsInSuperResolutionImage(const char *inputFileName, 
												const char *outputFileName,
												double imageZoomFactor = 10.667,//This makes a pixel size of 10 nm in the final image for 150x optical magnification and 16 um CCD camera pixel size. 
												double drawingIntensityScalingFactor = 1, 
												int drawingStyle = 0,
												double fixedSpotIntensity = 0);
	
	
	void drawSuperResolutionImageUsingNormalizedSpots(const char *inputFileName, const char *outputFileName, double imageZoomFactor, double volumeUnderSpot);

	
	
}

#endif

