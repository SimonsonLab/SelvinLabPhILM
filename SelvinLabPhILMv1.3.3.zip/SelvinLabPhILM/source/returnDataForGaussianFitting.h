/*
 *  returnDataForGaussianFitting.h
 *  PositionAndFluorescenceTracker
 *
 *  Created by Paul Simonson on 7/24/09.
 *  Copyright 2009 University of Illinois at Urbana Champaign. All rights reserved.
 *
 */

#ifndef returnDataForGaussianFitting_HEADER
#define returnDataForGaussianFitting_HEADER

#include <string>

#include "ScienceFile.h"
#include "tnt.h"
#include "FreeImage.h"

///Returns image information in 3 columns as x, y, and pixel intensity.
ScienceFile returnDataForGaussianFitting(TNT::Array2D<int> imageArray);

/*
ScienceFile returnDataForGaussianFitting(TNT::Array2D<int> imageArray, 
										 double x,
										 double y,
										 double fittingRadius);
*/


ScienceFile returnDataForGaussianFitting(std::string tiffStackFilePath, 
										 int whichFrame,
										 double x,
										 double y,
										 double fittingRadius);


ScienceFile returnDataForGaussianFitting(FIMULTIBITMAP *multibitmap, 
										 int whichFrame,
										 double x,
										 double y,
										 double fittingRadius);


template <typename T>
ScienceFile returnDataForGaussianFitting(TNT::Array2D<T> imageArray, 
										 double spotCenterX,
										 double spotCenterY,
										 double spotRadius)
{
	ScienceFile returnFile;
	
	double spotRadiusSquared = pow(spotRadius, 2);
	
	int width, height;
	width = imageArray.dim1();
	height = imageArray.dim2();
	
	//Set the x-y pixel ranges (so you do not have to scan through the whole image).
	int minXRange =  spotCenterX - (spotRadius + 1);
	if(minXRange < 0)
		minXRange = 0;
	
	int minYRange =  spotCenterY - (spotRadius + 1);
	if(minYRange < 0)
		minYRange = 0;	
	
	int maxXRange =  spotCenterX + (spotRadius + 1);
	if(maxXRange > width)
		maxXRange = width;
	
	int maxYRange =  spotCenterY + (spotRadius + 1);
	if(maxYRange > height)
		maxYRange = height;
	
	register int x, y;
	for (x = minXRange; x < maxXRange; x++)
		for (y = minYRange; y < maxYRange; y++)
		{
			double distanceFromCenterSquared = pow((x - spotCenterX), 2) + pow((y - spotCenterY), 2);
			if(distanceFromCenterSquared <= spotRadiusSquared)
			{
				std::vector<double> pixelData;
				pixelData.push_back(x);
				pixelData.push_back(y);
				pixelData.push_back(imageArray[x][y]);
				returnFile.addRow(pixelData);
			}
		}
	
	return returnFile;
}


#endif



