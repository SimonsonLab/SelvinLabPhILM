/*
 *  reversePhotobleachingSTORM.cpp
 *  ReverseSTORM
 *
 *  Created by Paul Simonson on 4/24/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

const bool verboseOutput = false;


#include <omp.h>
#include <cstring>
#include <vector>
#include <iostream>
#include <fstream>
#include <list>
#include <cmath>

#include "writeTIFFFileUsingMagick.h"
#include "PhILMCoreCode.h"
#include "return2DArrayFromMultiBitmap.h"
#include "ScienceFile.h"
#include "tiffStackOperations.h"
#include "tiffFrameOperations.h"
#include "returnSpotIntensity.h"
//#include "fitTo2DGaussianUsingGSL.h"
#include "fitTo2DEllipticalGaussian.h"
#include "tiffFrameOperations.h"
#include "FreeImage.h"
#include "SimonsonLibTIFF_IO.h"

using namespace Fitting2DEllipticalGaussianUsingGSL;

#define RESTRICTING_FRAME_RANGES

///Global variables
PhILMPreferences thePhILMPreferences("PhILMPreferences.txt");
const int newPixelOffset = 16384;
const double pixelShiftForDrawingSuperResolutionImages = 0.5;


namespace PhILM_namespace 
{	
	//Functions
	
	int checkForExitCommand(const char *cpath)
	{
		if(!strcmp(cpath, "q"))
			exit(0);
		if(!strcmp(cpath, "Q"))
			exit(0);
		if(!strcmp(cpath, "quit"))
			exit(0);
		if(!strcmp(cpath, "exit"))
			exit(0);
		if(!strcmp(cpath, "Quit"))
			exit(0);
		if(!strcmp(cpath, "Exit"))
			exit(0);
		if(!strcmp(cpath, "QUIT"))
			exit(0);
		if(!strcmp(cpath, "EXIT"))
			exit(0);
		if(!strcmp(cpath, "Get me outa here!"))
			exit(0);
		return 0;
	}
	
	
	int checkWhetherFileIsPresent(const char *cpath)
	{
		std::ifstream file; // indata is like cin
		file.open(cpath); // opens the file
		if(!file) { // file couldn't be opened
			return 0;
		}
		else
		{
			file.close();
			return 1;
		}
	}
	
	
    std::vector< TNT::Array2D< int > > returnBackwardsSubtracted(std::vector< TNT::Array2D< int > > &imageVector)
    {
        const bool verboseOutput = false;
        const unsigned short newPixelOffset = 16384;
        
        if (verboseOutput) {
            std::cout << "Now backwards-subtracting...\n";
        }
        
        int numFrames = imageVector.size();
        
        TNT::Array2D< int > originalFirstFrame = imageVector.at(0);
        
        if (verboseOutput) {
            std::cout << "Returned first frame from TIFF file...\n";
        }
        
        int width, height;
        width = originalFirstFrame.dim1();
        height = originalFirstFrame.dim2();
        TNT::Array2D< int > newPixelOffsetArray(width, height, newPixelOffset);
        
        //The new image stack:
        std::vector<TNT::Array2D<int> > newImageList(numFrames);
        
        int j;
#pragma omp parallel for
        for(j = 1;  j < numFrames; j++)
        {
            if (verboseOutput) {
#pragma omp critical
                {
                    std::cout << "Now subtracting frame " << j + 1 << " from frame " << j << "...\n";
                }
            }
            TNT::Array2D< int > imageArray = imageVector.at(j-1);//return2DIntArrayFromMultiBitmap(multibitmap, j);
            imageArray = imageArray - imageVector.at(j);
            imageArray = imageArray + newPixelOffsetArray;
            newImageList.at(j - 1) = imageArray;
        }
        
        //Set the last frame to the offset.
        newImageList.at(numFrames - 1) = newPixelOffsetArray;
        
        std::cout << "Finished creation of sequentially-subtracted image.\n";
        return newImageList;
    }
    
    
	inline double separationDistanceSquared(const double x1, const double x2, const double y1, const double y2)
	{
		return (x1-x2)*(x1-x2) + (y1-y2)*(y1-y2);
		//return pow(x1-x2,2) + pow(y1-y2,2);
	}

	
    ScienceFile removeFrameRangesMarkedAsBad(ScienceFile &spotFrameRanges, std::vector<bool> &badSpotFlags)
    {
        ScienceFile goodFrameRanges;

        if (spotFrameRanges.numRows() != badSpotFlags.size()) {
            std::cout << "Error in function removeFrameRangesMarkedAsBad\n\a";
            return goodFrameRanges;
        }
        
        int numSpots = spotFrameRanges.numRows();
        int i;
        for(i = 0; i < numSpots; i++)
        {
			if(badSpotFlags.at(i) == false)
            {
				goodFrameRanges.addRow(spotFrameRanges.returnRow(i));
            }
        }
        return goodFrameRanges;
    }
    
    void markSpotsThatAreTooCloseTogetherAsBad(ScienceFile &finalSpotFrameRanges, ScienceFile &detectedSpots, std::vector<bool> &badSpotFlags, double minimumSeparation)
    {
        ///Mark as bad those spots that are too close together.
        double minimumSeparationSquared = minimumSeparation * minimumSeparation;

        int numSpots = finalSpotFrameRanges.numRows();
        int i;

#pragma omp parallel for
        for(i = 0; i < numSpots - 1; i++)
        {
            int j;
            for (j = i + 1; j < numSpots; j++)
            {
                //if(i != j)
                {
                    if(finalSpotFrameRanges.at(j, 3) > finalSpotFrameRanges.at(i, 3))
                        break;
                    
                    if(finalSpotFrameRanges.at(i, 3) == finalSpotFrameRanges.at(j, 3))
                        if(separationDistanceSquared(finalSpotFrameRanges.returnElement(i, 0), 
                                                     finalSpotFrameRanges.returnElement(j, 0), 
                                                     finalSpotFrameRanges.returnElement(i, 1),
                                                     finalSpotFrameRanges.returnElement(j, 1))
                           < minimumSeparationSquared)
                        {
                            badSpotFlags.at(i) = true;
                            badSpotFlags.at(j) = true;
                        }
                }
            }
        }
        //End of marking close spots.
    }
    
    
	int fastCalculateOneSpotFrameRange(int i,
									   int numSpots,
									   int numAntiSpots,
									   double minimumSeparationSquared,
									   ScienceFile &detectedSpots, ScienceFile &detectedAntiSpots, 
									   std::vector<double> &xs, std::vector<double> &ys, 
									   std::vector<double> &detectedSpotsFrames, 
									   std::vector<double> &xsAntiSpots, std::vector<double> &ysAntiSpots, 
									   std::vector<double> &detectedAntiSpotsFrames, 
									   std::vector<double> &framesWhereSpotsAppear, 
									   std::vector<double> &lastFramesBeforePhotobleaching, 
                                       std::vector<double> &firstSubtractableFrames, 
									   std::vector<double> &lastSubtractableFrames)
	{
        //const int intensityColumn = 3;
        
		static int startingAntiSpot = 0;
		int j;
		
		for (j = i; j < numSpots; j++)
		{
			if(i != j)
			{
				if(lastSubtractableFrames[i] < detectedSpotsFrames[j])//then you have already found the maximum frame range.
				{
					break;
				}
				
				if(separationDistanceSquared(xs[i], 
											 xs[j], 
											 ys[i],
											 ys[j])
				   <= minimumSeparationSquared)
				{
					//std::cout << i << ", " << j << "\n";
					if(detectedSpotsFrames[i] > detectedSpotsFrames[j])
						if(framesWhereSpotsAppear[i] < detectedSpotsFrames[j])
							framesWhereSpotsAppear[i] = detectedSpotsFrames[j];
					
					if(detectedSpotsFrames[i] < detectedSpotsFrames[j])
						if(lastSubtractableFrames[i] > detectedSpotsFrames[j])
						{
							lastSubtractableFrames[i] = detectedSpotsFrames[j];
						}
				}
				
#ifdef RESTRICTING_FRAME_RANGES
				///This is for limiting how many frames after the photobleaching event it will go through.
				int currentFramesDistance = detectedSpotsFrames[j] - detectedSpotsFrames[i];
				if (currentFramesDistance > thePhILMPreferences.maxNumFramesToAverage) 
                {
					lastSubtractableFrames[i] = detectedSpotsFrames[i] + thePhILMPreferences.maxNumFramesToAverage;
					//std::cout << "Exceeded maxNumFramesToAverage in calculating spot frame ranges.  Jumping out of loop...\n";
					break;
					
				}
#endif
			}			
		}
		
		
		for (j = i; j > -1; j--)
		{
			if(i != j)
			{
				if(framesWhereSpotsAppear[i] > detectedSpotsFrames[j])//then you have already found the minimum frame range.
				{
					break;
				}
				
				if(separationDistanceSquared(xs[i], 
											 xs[j], 
											 ys[i],
											 ys[j])
				   <= minimumSeparationSquared)
				{
					//std::cout << i << ", " << j << "\n";
					if(detectedSpotsFrames[i] > detectedSpotsFrames[j])
						if(framesWhereSpotsAppear[i] < detectedSpotsFrames[j])
							framesWhereSpotsAppear[i] = detectedSpotsFrames[j];
					
					if(detectedSpotsFrames[i] < detectedSpotsFrames[j])
                    {
						if(lastSubtractableFrames[i] > detectedSpotsFrames[j])
						{
							lastSubtractableFrames[i] = detectedSpotsFrames[j];
						}
                    }
				}
			}			
		}
		
		
		if (numAntiSpots > 0) 
		{			
			int firstOfCheckedRange, lastOfCheckedRange;
			
			for (j = startingAntiSpot; j > -1; j--)
			{
				if(framesWhereSpotsAppear[i] > detectedAntiSpotsFrames[j])//then you have already found the minimum frame range.
				{
					break;
				}
				
				if(separationDistanceSquared(xs[i], 
											 xsAntiSpots[j], 
											 ys[i],
											 ysAntiSpots[j])
				   <= minimumSeparationSquared)
				{
					if(detectedSpotsFrames[i] > detectedAntiSpotsFrames[j])
						if(framesWhereSpotsAppear[i] < detectedAntiSpotsFrames[j])
							framesWhereSpotsAppear[i] = detectedAntiSpotsFrames[j];
					
					if(detectedSpotsFrames[i] < detectedAntiSpotsFrames[j])
						if(lastSubtractableFrames[i] > detectedAntiSpotsFrames[j])
							lastSubtractableFrames[i] = detectedAntiSpotsFrames[j];
				}
				
			}
			firstOfCheckedRange = j;
			
			for (j = startingAntiSpot; j < numAntiSpots; j++)
			{
				if(lastSubtractableFrames[i] < detectedAntiSpotsFrames[j])//then you have already found the maximum frame range.
				{
					break;
				}
				
				if(separationDistanceSquared(xs[i], 
											 xsAntiSpots[j], 
											 ys[i],
											 ysAntiSpots[j])
				   <= minimumSeparationSquared)
				{
					if(detectedSpotsFrames[i] > detectedAntiSpotsFrames[j])
						if(framesWhereSpotsAppear[i] < detectedAntiSpotsFrames[j])
							framesWhereSpotsAppear[i] = detectedAntiSpotsFrames[j];
					
					if(detectedSpotsFrames[i] < detectedAntiSpotsFrames[j])
						if(lastSubtractableFrames[i] > detectedAntiSpotsFrames[j])
							lastSubtractableFrames[i] = detectedAntiSpotsFrames[j];
				}
				
#ifdef RESTRICTING_FRAME_RANGES
				///This is for limiting how many frames after the photobleaching event it will go through.
				int currentFramesDistance = detectedAntiSpotsFrames[j] - detectedSpotsFrames[i];
				if (currentFramesDistance > thePhILMPreferences.maxNumFramesToAverage) 
				{
					lastSubtractableFrames[i] = detectedSpotsFrames[i] + thePhILMPreferences.maxNumFramesToAverage;
					//std::cout << "Exceeded maxNumFramesToAverage in calculating spot frame ranges.  Jumping out of loop...\n";
					break;
				}
#endif
			}
			lastOfCheckedRange = j;
			
			startingAntiSpot = 0.5*(lastOfCheckedRange - firstOfCheckedRange) + firstOfCheckedRange;
			
			if(startingAntiSpot < 0)
			{
				startingAntiSpot = 0;
			}
			if (startingAntiSpot > numAntiSpots - 1) {
				startingAntiSpot = numAntiSpots - 1;
			}
		}
		
		if (lastFramesBeforePhotobleaching[i] - framesWhereSpotsAppear[i] > thePhILMPreferences.maxNumFramesToAverage) {
			framesWhereSpotsAppear[i] = lastFramesBeforePhotobleaching[i] - thePhILMPreferences.maxNumFramesToAverage;
		}
		
		
		if (lastSubtractableFrames[i] > detectedSpotsFrames[i] + thePhILMPreferences.maxNumFramesToAverage) 
		{
			lastSubtractableFrames[i] = detectedSpotsFrames[i] + thePhILMPreferences.maxNumFramesToAverage;
		}
		
        firstSubtractableFrames[i] = lastFramesBeforePhotobleaching[i] + 1;

        if (verboseOutput) 
        {
			std::cout << "Spot " << i + 1 << ", frame averaging ranges: " << framesWhereSpotsAppear[i] << "	" << lastFramesBeforePhotobleaching[i] << "	" << firstSubtractableFrames[i] <<"\t" << lastSubtractableFrames[i] << "\n";
		}
        
		return 0;
	}
	
    
    ///This function is used to determine what frames can be averaged before and after a photobleaching event.
	int fastCalculateSpotFrameRanges(const char *tiffFileName, double minimumSeparation)
	{
		enum DetectedSpotFilesColumns {
            xColumn = 0,
            yColumn, frameColumn, intensityColumn        
        };
        
        
		TNT::Stopwatch Q;
		Q.start();
		
		ScienceFile finalSpotFrameRanges;
		
		int numFrames = SimonsonLibTIFF_IO::countFramesInTIFFStack(tiffFileName);
		
		
		if(minimumSeparation == 0)
		{
			std::cout << "Please enter minimum allowed spot separation: ";
			std::cin >> minimumSeparation;
		}
		
		if(minimumSeparation < 1)
			minimumSeparation = 1;
		
		double minimumSeparationSquared = minimumSeparation * minimumSeparation;
		
		std::cout << (thePhILMPreferences.formOutputFilePath("detectedSpots.txt").c_str()) << "\n";
		
		ScienceFile detectedSpots(thePhILMPreferences.formOutputFilePath("detectedSpots.txt").c_str());
		int numSpots = detectedSpots.numRows();
		
		if (verboseOutput) {
			detectedSpots.display();
		}	
		
		std::cout << (thePhILMPreferences.formOutputFilePath("detectedAntiSpots.txt").c_str()) << "\n";
		
		ScienceFile detectedAntiSpots(thePhILMPreferences.formOutputFilePath("detectedAntiSpots.txt").c_str());
		
		if (verboseOutput) {
			detectedAntiSpots.display();
		}
		
		int numAntiSpots = detectedAntiSpots.numRows();
		if (verboseOutput) {
			std::cout << "Number of spots: " << numSpots << ", Number of anti-spots: " << numAntiSpots << "\n";
		}
		std::cout.flush();
		
		std::vector<double> xsAntiSpots; 
		std::vector<double> ysAntiSpots; 
		std::vector<double> detectedAntiSpotsFrames;
		if (numAntiSpots > 0) 
		{
			xsAntiSpots = detectedAntiSpots.returnColumn(xColumn); 
			ysAntiSpots = detectedAntiSpots.returnColumn(yColumn); 
			detectedAntiSpotsFrames = detectedAntiSpots.returnColumn(frameColumn);
		}
		
		if(numSpots > 0)
		{
			std::vector<double> xs = detectedSpots.returnColumn(xColumn); 
			std::vector<double> ys = detectedSpots.returnColumn(yColumn); 
			std::vector<double> detectedSpotsFrames = detectedSpots.returnColumn(frameColumn);
			std::vector<double> framesWhereSpotsAppear(numSpots, 1);
			std::vector<double> lastFramesBeforePhotobleaching = detectedSpotsFrames;
            std::vector<double> firstSubtractableFrames = lastFramesBeforePhotobleaching;		
			std::vector<double> lastSubtractableFrames(numSpots, numFrames);		
            std::vector<bool> badSpotFlags(numSpots, false);
            
			int i;
#pragma omp parallel for
			for(i = 0; i < numSpots; i++)
			{
                if (verboseOutput) {
                    std::cout << "Calculating frame averaging for spot " << i + 1 << ".\n";
                }
                
                if (thePhILMPreferences.maximumDetectionThreshold && detectedSpots.at(i, intensityColumn) > thePhILMPreferences.maximumDetectionThreshold) 
                {
                        badSpotFlags[i] = true;
                }
                else
                {
                    fastCalculateOneSpotFrameRange(i,numSpots,numAntiSpots,
                                                   minimumSeparationSquared,
                                                   detectedSpots, detectedAntiSpots, 
                                                   xs, ys, 
                                                   detectedSpotsFrames, 
                                                   xsAntiSpots, ysAntiSpots, 
                                                   detectedAntiSpotsFrames, 
                                                   framesWhereSpotsAppear, 
                                                   lastFramesBeforePhotobleaching, 
                                                   firstSubtractableFrames,
                                                   lastSubtractableFrames);
                }
                
			}
			if (verboseOutput) {
				std::cout << "Now making last corrections to spot frame ranges...\n";
			}
			
#pragma omp parallel for
			for(i = 0; i < numSpots; i++)
			{
				if (lastFramesBeforePhotobleaching.at(i) > 1)
					if(framesWhereSpotsAppear.at(i) != 1)
						framesWhereSpotsAppear.at(i) += 1;
			}
			
            finalSpotFrameRanges.addColumn(xs);
			finalSpotFrameRanges.addColumn(ys);
			finalSpotFrameRanges.addColumn(framesWhereSpotsAppear);
			finalSpotFrameRanges.addColumn(lastFramesBeforePhotobleaching);
            finalSpotFrameRanges.addColumn(firstSubtractableFrames);
			finalSpotFrameRanges.addColumn(lastSubtractableFrames);
			//finalSpotFrameRanges.display();
            markSpotsThatAreTooCloseTogetherAsBad(finalSpotFrameRanges, detectedSpots, badSpotFlags, minimumSeparation);
                        
			ScienceFile finalFinalSpotFrameRanges = removeFrameRangesMarkedAsBad(finalSpotFrameRanges, badSpotFlags);
            
			finalFinalSpotFrameRanges.writeToFile(thePhILMPreferences.formOutputFilePath("finalSpotFrameRanges.txt").c_str());
		}
		
		if (verboseOutput) {
			std::cout << "Finished calculating the frame ranges for averaging for spots after " << Q.read()/60.0 << " minutes.\n";
		}
		return 0;
	}
	
	
	int fastCalculateOneAntiSpotFrameRange(int i,
										   int numSpots,
										   int numAntiSpots,
										   double minimumSeparationSquared,
										   ScienceFile &detectedSpots, ScienceFile &detectedAntiSpots, 
										   std::vector<double> &xsSpots, std::vector<double> &ysSpots, 
										   std::vector<double> &detectedSpotsFrames, 
										   std::vector<double> &xsAntiSpots, std::vector<double> &ysAntiSpots, 
										   std::vector<double> &detectedAntiSpotsFrames, 
										   std::vector<double> &earliestSubtractableFrames, 
										   std::vector<double> &lastFramesBeforeSpotsAppear, 
                                           std::vector<double> &firstFramesInWhichSpotsAppear, 
										   std::vector<double> &lastFramesBeforeSpotsDisappear)
	{
		static int startingSpot = 0;
		
		int j;
		
		for (j = i; j < numAntiSpots; j++)
		{
			if(i != j)
			{
				if(lastFramesBeforeSpotsDisappear[i] < detectedAntiSpotsFrames[j])//then you have already found the maximum frame range.
				{
					break;
				}
				
				if(separationDistanceSquared(xsAntiSpots[i], 
											 xsAntiSpots[j], 
											 ysAntiSpots[i],
											 ysAntiSpots[j])
				   <= minimumSeparationSquared)
				{
					//std::cout << i << ", " << j << "\n";
					if(detectedAntiSpotsFrames[i] > detectedAntiSpotsFrames[j])
						if(earliestSubtractableFrames[i] < detectedAntiSpotsFrames[j])
							earliestSubtractableFrames[i] = detectedAntiSpotsFrames[j];
					
					if(detectedAntiSpotsFrames[i] < detectedAntiSpots.at(j, 2))
						if(lastFramesBeforeSpotsDisappear[i] > detectedAntiSpotsFrames[j])
							lastFramesBeforeSpotsDisappear[i] = detectedAntiSpotsFrames[j];
				}
				
#ifdef RESTRICTING_FRAME_RANGES
				///This is for limiting how many frames after the photobleaching event it will go through.
				int currentFramesDistance = detectedAntiSpots.at(j, 2) - detectedAntiSpots.at(i, 2);
				if (currentFramesDistance > thePhILMPreferences.maxNumFramesToAverage) 
				{
					lastFramesBeforeSpotsDisappear[i] = detectedAntiSpots.at(i, 2) + thePhILMPreferences.maxNumFramesToAverage;
					//std::cout << "Exceeded maxNumFramesToAverage in calculating spot frame ranges.  Jumping out of loop...\n";
					break;
				}
#endif
			}
		}
		
		for (j = i; j > -1; j--)
		{
			if(i != j)
			{
				if(earliestSubtractableFrames[i] > detectedAntiSpotsFrames[j])//then you have already found the maximum frame range.
				{
					break;
				}
				
				if(separationDistanceSquared(xsAntiSpots[i], 
											 xsAntiSpots[j], 
											 ysAntiSpots[i],
											 ysAntiSpots[j])
				   <= minimumSeparationSquared)
				{
					//std::cout << i << ", " << j << "\n";
					if(detectedAntiSpotsFrames[i] > detectedAntiSpotsFrames[j])
						if(earliestSubtractableFrames[i] < detectedAntiSpotsFrames[j])
							earliestSubtractableFrames[i] = detectedAntiSpotsFrames[j];
					
					if(detectedAntiSpotsFrames[i] < detectedAntiSpots.at(j, 2))
						if(lastFramesBeforeSpotsDisappear[i] > detectedAntiSpotsFrames[j])
							lastFramesBeforeSpotsDisappear[i] = detectedAntiSpotsFrames[j];
				}
				
#ifdef RESTRICTING_FRAME_RANGES
				///This is for limiting how many frames after the photobleaching event it will go through.
				int currentFramesDistance = detectedAntiSpots.at(j, 2) - detectedAntiSpots.at(i, 2);
				if (currentFramesDistance > thePhILMPreferences.maxNumFramesToAverage) 
				{
					lastFramesBeforeSpotsDisappear[i] = thePhILMPreferences.maxNumFramesToAverage + detectedAntiSpots.at(i, 2);
					break;
				}
#endif
			}
		}
		
		
		if(numSpots)
		{			
			int firstOfCheckedRange, lastOfCheckedRange;
			
			for (j = startingSpot; j > - 1; j--)
			{
				if(earliestSubtractableFrames[i] > detectedSpotsFrames[j])//then you have already found the maximum frame range.
				{
					break;
				}
				
				if(separationDistanceSquared(xsSpots[j], 
											 xsAntiSpots[i], 
											 ysSpots[j],
											 ysAntiSpots[i])
				   <= minimumSeparationSquared)
				{
					if(detectedAntiSpotsFrames[i] > detectedSpotsFrames[j])
						if(earliestSubtractableFrames[i] < detectedSpotsFrames[j])
							earliestSubtractableFrames[i] = detectedSpotsFrames[j];
					
					if(detectedAntiSpotsFrames[i] < detectedSpotsFrames[j])
						if(lastFramesBeforeSpotsDisappear[i] > detectedSpotsFrames[j])
							lastFramesBeforeSpotsDisappear[i] = detectedSpotsFrames[j];
				}
				
				
#ifdef RESTRICTING_FRAME_RANGES
				///This is for limiting how many frames after the photobleaching event it will go through--hopefully the processing will be faster.
				int currentFramesDistance = detectedSpotsFrames[j] - detectedAntiSpotsFrames[i];
				if (currentFramesDistance > thePhILMPreferences.maxNumFramesToAverage) 
				{
					lastFramesBeforeSpotsDisappear[i] = detectedAntiSpotsFrames[i] + thePhILMPreferences.maxNumFramesToAverage;
					
					//std::cout << "Exceeded maxNumFramesToAverage in calculating spot frame ranges.  Jumping out of loop...\n";
					break;
				}
#endif
			}
			firstOfCheckedRange = j;
			
			for (j = startingSpot; j < numSpots; j++)
			{
				if(lastFramesBeforeSpotsDisappear[i] < detectedSpotsFrames[j])//then you have already found the maximum frame range.
				{
					break;
				}
				
				if(separationDistanceSquared(xsSpots[j], 
											 xsAntiSpots[i], 
											 ysSpots[j],
											 ysAntiSpots[i])
				   <= minimumSeparationSquared)
				{
					if(detectedAntiSpotsFrames[i] > detectedSpotsFrames[j])
						if(earliestSubtractableFrames[i] < detectedSpotsFrames[j])
							earliestSubtractableFrames[i] = detectedSpotsFrames[j];
					
					if(detectedAntiSpotsFrames[i] < detectedSpotsFrames[j])
						if(lastFramesBeforeSpotsDisappear[i] > detectedSpotsFrames[j])
							lastFramesBeforeSpotsDisappear[i] = detectedSpotsFrames[j];
				}
				
#ifdef RESTRICTING_FRAME_RANGES
				///This is for limiting how many frames after the photobleaching event it will go through--hopefully the processing will be faster.
				int currentFramesDistance = detectedSpotsFrames[j] - detectedAntiSpotsFrames[i];
				if (currentFramesDistance > thePhILMPreferences.maxNumFramesToAverage) {
					/*
					 if(lastFramesBeforeSpotsDisappear[i] > detectedSpotsFrames[j])
					 {
					 lastFramesBeforeSpotsDisappear[i] = detectedSpotsFrames[j];
					 }*/
					lastFramesBeforeSpotsDisappear[i] = thePhILMPreferences.maxNumFramesToAverage + detectedAntiSpotsFrames[i];
					//std::cout << "Exceeded maxNumFramesToAverage in calculating spot frame ranges.  Jumping out of loop...\n";
					break;
				}
#endif
			}
			lastOfCheckedRange = j;
			
			startingSpot = 0.5*(lastOfCheckedRange - firstOfCheckedRange) + firstOfCheckedRange;
			
			if(startingSpot < 0)
			{
				startingSpot = 0;
			}
			if (startingSpot > numSpots - 1) {
				startingSpot = numSpots - 1;
			}
			
		}
		
#ifdef RESTRICTING_FRAME_RANGES

		if (lastFramesBeforeSpotsDisappear[i] > detectedAntiSpots.at(i, 2) + thePhILMPreferences.maxNumFramesToAverage) 
		{
			lastFramesBeforeSpotsDisappear[i] = detectedAntiSpots.at(i, 2) + thePhILMPreferences.maxNumFramesToAverage;
		}
		
		if (earliestSubtractableFrames[i] < lastFramesBeforeSpotsAppear[i] - thePhILMPreferences.maxNumFramesToAverage) 
		{
			earliestSubtractableFrames[i] = lastFramesBeforeSpotsAppear[i] - thePhILMPreferences.maxNumFramesToAverage;
		}
		
#endif

        firstFramesInWhichSpotsAppear[i] = lastFramesBeforeSpotsAppear[i] + 1;
        
		if (verboseOutput) 
		{
			std::cout << "Anti-spot " << i + 1 << ", frame averaging ranges: " << earliestSubtractableFrames[i] << "	" << lastFramesBeforeSpotsAppear[i] << "	" << firstFramesInWhichSpotsAppear[i] << "\t" << lastFramesBeforeSpotsDisappear[i] << "\n";
		}
		return 0;	
	}
	
    
	///This function is used to determine what frames can be averaged before and after a photoactivation event.
	int fastCalculateAntiSpotFrameRanges(const char *tiffFileName, double minimumSeparation)
	{		
        enum DetectedSpotFilesColumns {
            xColumn = 0,
            yColumn, frameColumn, intensityColumn        
        };
        
        
		TNT::Stopwatch Q;
		Q.start();
		
		ScienceFile finalSpotFrameRanges;
		
		int numFrames = SimonsonLibTIFF_IO::countFramesInTIFFStack(tiffFileName);
		
		if(minimumSeparation == 0)
		{
			std::cout << "Please enter minimum allowed spot separation: ";
			std::cin >> minimumSeparation;
		}
		
		if(minimumSeparation < 1)
			minimumSeparation = 1;
		
		double minimumSeparationSquared = minimumSeparation * minimumSeparation;
		
		ScienceFile detectedSpots(thePhILMPreferences.formOutputFilePath("detectedSpots.txt").c_str());
		int numSpots = detectedSpots.numRows();
		ScienceFile detectedAntiSpots(thePhILMPreferences.formOutputFilePath("detectedAntiSpots.txt").c_str());
		int numAntiSpots = detectedAntiSpots.numRows();
		
		if(numAntiSpots)
		{
			std::vector<double> xsSpots; 
			std::vector<double> ysSpots; 
			std::vector<double> detectedSpotsFrames;
			
			if(numSpots)
			{
				xsSpots = detectedSpots.returnColumn(0); 
				ysSpots = detectedSpots.returnColumn(1); 
				detectedSpotsFrames = detectedSpots.returnColumn(2);
			}
			
			//std::vector<double> xs = detectedAntiSpots.returnColumn(0); 
			//std::vector<double> ys = detectedAntiSpots.returnColumn(1); 
			std::vector<double> xsAntiSpots = detectedAntiSpots.returnColumn(0); 
			std::vector<double> ysAntiSpots = detectedAntiSpots.returnColumn(1); 
			std::vector<double> detectedAntiSpotsFrames = detectedAntiSpots.returnColumn(2);
			std::vector<double> earliestSubtractableFrames(numAntiSpots, 1);
			std::vector<double> lastFramesBeforeSpotsAppear = detectedAntiSpots.returnColumn(2);
            std::vector<double> firstFramesInWhichSpotsAppear = lastFramesBeforeSpotsAppear;
			std::vector<double> lastFramesBeforeSpotsDisappear(numAntiSpots, numFrames);
            std::vector<bool> badSpotFlags(numAntiSpots, false);

			int i;
#pragma omp parallel for
			for(i = 0; i < numAntiSpots; i++)
			{
                if (thePhILMPreferences.maximumDetectionThreshold && -1.0*detectedAntiSpots.at(i, intensityColumn) > thePhILMPreferences.maximumDetectionThreshold) 
                {
                    badSpotFlags[i] = true;
                }
                else
                {
                    fastCalculateOneAntiSpotFrameRange(i,numSpots,numAntiSpots,
                                                       minimumSeparationSquared,
                                                       detectedSpots, detectedAntiSpots, 
                                                       xsSpots, ysSpots, 
                                                       detectedSpotsFrames, 
                                                       xsAntiSpots, ysAntiSpots, 
                                                       detectedAntiSpotsFrames, 
                                                       earliestSubtractableFrames, 
                                                       lastFramesBeforeSpotsAppear, 
                                                       firstFramesInWhichSpotsAppear,
                                                       lastFramesBeforeSpotsDisappear);
                }
			}
			
			if (verboseOutput) {
				std::cout << "Now making last corrections to anti-spot frame ranges...\n";
			}
			
#pragma omp parallel for
			for(i = 0; i < numAntiSpots; i++)
			{
				if (lastFramesBeforeSpotsAppear.at(i) > 1)
					if(earliestSubtractableFrames.at(i) != 1)
						earliestSubtractableFrames.at(i) += 1;
			}
			
			finalSpotFrameRanges.addColumn(xsAntiSpots);
			finalSpotFrameRanges.addColumn(ysAntiSpots);
			finalSpotFrameRanges.addColumn(earliestSubtractableFrames);
			finalSpotFrameRanges.addColumn(lastFramesBeforeSpotsAppear);
            finalSpotFrameRanges.addColumn(firstFramesInWhichSpotsAppear);
			finalSpotFrameRanges.addColumn(lastFramesBeforeSpotsDisappear);
			//finalSpotFrameRanges.display();

            
            markSpotsThatAreTooCloseTogetherAsBad(finalSpotFrameRanges, detectedAntiSpots, badSpotFlags, minimumSeparation);

            ScienceFile finalFinalSpotFrameRanges = removeFrameRangesMarkedAsBad(finalSpotFrameRanges, badSpotFlags);

			finalFinalSpotFrameRanges.writeToFile(thePhILMPreferences.formOutputFilePath("finalAntiSpotFrameRanges.txt").c_str());
		}
		
		if (verboseOutput) {
			std::cout << "Finished calculating the frame ranges for averaging for anti-spots after " << Q.read()/60.0 << " minutes.\n";
		}
		
		return 0;
	}
	
    
    
    void throwAwayIntermediateFramesUsingFrameRangesFiles(void)
    {
        ///This function opens the frame averaging range files and overwrites them with modified versions that eliminate the 

        {
            ScienceFile spotFrameRanges(thePhILMPreferences.formOutputFilePath("finalSpotFrameRanges.txt").c_str());
            ScienceFile newSpotFrameRanges;
            int numSpots = spotFrameRanges.numRows();
            int i;
            for (i = 0; i < numSpots; i++) {
                if (spotFrameRanges.at(i, 3) - spotFrameRanges.at(i, 2) > 2)
                {
                    if (spotFrameRanges.at(i, 5) - spotFrameRanges.at(i, 4) > 2)
                    {
                        std::vector<double> newRow(6);
                        newRow[0] = spotFrameRanges.at(i,0);
                        newRow[1] = spotFrameRanges.at(i,1);
                        newRow[2] = spotFrameRanges.at(i,2) + 1;
                        newRow[3] = spotFrameRanges.at(i,3) - 1;
                        newRow[4] = spotFrameRanges.at(i,4) + 1;
                        newRow[5] = spotFrameRanges.at(i,5) - 1;
                        newSpotFrameRanges.addRow(newRow);
                    }
                    
                }
            }
            newSpotFrameRanges.writeToFile(thePhILMPreferences.formOutputFilePath("finalSpotFrameRanges.txt").c_str(), "%x\ty\tf1\tf2\tf3\tf4");
        }
        
        {
            ScienceFile spotFrameRanges(thePhILMPreferences.formOutputFilePath("finalAntiSpotFrameRanges.txt").c_str());
            ScienceFile newSpotFrameRanges;
            int numSpots = spotFrameRanges.numRows();
            int i;
            for (i = 0; i < numSpots; i++) {
                if (spotFrameRanges.at(i, 3) - spotFrameRanges.at(i, 2) > 2)
                {
                    if (spotFrameRanges.at(i, 5) - spotFrameRanges.at(i, 4) > 2)
                    {
                        std::vector<double> newRow(6);
                        newRow[0] = spotFrameRanges.at(i,0);
                        newRow[1] = spotFrameRanges.at(i,1);
                        newRow[2] = spotFrameRanges.at(i,2) + 1;
                        newRow[3] = spotFrameRanges.at(i,3) - 1;
                        newRow[4] = spotFrameRanges.at(i,4) + 1;
                        newRow[5] = spotFrameRanges.at(i,5) - 1;
                        newSpotFrameRanges.addRow(newRow);
                    }
                    
                }
            }
            newSpotFrameRanges.writeToFile(thePhILMPreferences.formOutputFilePath("finalAntiSpotFrameRanges.txt").c_str(), "%x\ty\tf1\tf2\tf3\tf4");
        }
        
    }

	
	int checkWhetherSpotIsGood(TwoDGaussianFittingParametersAndErrors &spotFit, bool verboseSpotChecking)
	{
		if (!verboseOutput) {
			verboseSpotChecking = false;
		}
		
		
		if(verboseSpotChecking)
		{
			if(spotFit.peakHeight <= 0
			   || spotFit.xCenterValueError <= 0
			   || spotFit.yCenterValueError <= 0) //Of course it has to be greater than zero...
			{
				std::cout << "The peak height (" << spotFit.peakHeight << ") is less than or equal to zero.\n";
				return 0;
			}
			else if(spotFit.xCenterValueError > thePhILMPreferences.maximumLocalizationError 
					|| spotFit.yCenterValueError > thePhILMPreferences.maximumLocalizationError)
			{
				std::cout << "The spot's localization error (" << spotFit.xCenterValueError << " or " << spotFit.yCenterValueError << ") is too big.\n";
				return 0;
			}
			else if(std::isinf(spotFit.peakHeightError) || std::isnan(spotFit.peakHeightError) || spotFit.peakHeightError <= 0)
			{
				std::cout << "The peakHeightError (" << spotFit.peakHeightError << ") could not be calculated correctly.\n";
				return 0;
			}
			else if(spotFit.xCenterValue < 0 || spotFit.yCenterValue < 0)
			{
				std::cout << "The spot is outside the image area.\n";
				return 0;
			}
			else if(spotFit.xWidth < thePhILMPreferences.minimumSpotWidth
					|| spotFit.yWidth < thePhILMPreferences.minimumSpotWidth 
					|| spotFit.xWidth > thePhILMPreferences.maximumSpotWidth
					|| spotFit.yWidth > thePhILMPreferences.maximumSpotWidth)
			{
				std::cout << "The spot is too narrow or too wide.\n";
				return 0;
			}
			else if(spotFit.ellipticity() < thePhILMPreferences.minimumEllipticity
					|| spotFit.ellipticity() > thePhILMPreferences.maximumEllipticity)
			{
				std::cout << "The spot ellipticity (" << spotFit.ellipticity() << ") does not meet the ellipticity requirements.\n";
				return 0;
			}
			else {
				std::cout << "THE SPOT IS GOOD.\n";
				return 1;
			}
			
		}
		else
		{
			if(spotFit.peakHeight <= 0
			   || spotFit.xCenterValueError <= 0
			   || spotFit.yCenterValueError <= 0) //Of course it has to be greater than zero...
			{
				//std::cout << "The peak height is less than or equal to zero.\n";
				return 0;
			}
			else if(spotFit.xCenterValueError > thePhILMPreferences.maximumLocalizationError 
					|| spotFit.yCenterValueError > thePhILMPreferences.maximumLocalizationError)
			{
				//std::cout << "The spot's localization error is too big.\n";
				return 0;
			}
			else if(std::isinf(spotFit.peakHeightError) || std::isnan(spotFit.peakHeightError) || spotFit.peakHeightError <= 0)
			{
				//std::cout << "The peakHeightError could not be calculated.\n";
				return 0;
			}
			else if(spotFit.xCenterValue < 0 || spotFit.yCenterValue < 0)
			{
				//std::cout << "The spot is outside the image area.\n";
				return 0;
			}
			else if(spotFit.xWidth < thePhILMPreferences.minimumSpotWidth
					|| spotFit.yWidth < thePhILMPreferences.minimumSpotWidth 
					|| spotFit.xWidth > thePhILMPreferences.maximumSpotWidth
					|| spotFit.yWidth > thePhILMPreferences.maximumSpotWidth)
			{
				//std::cout << "The spot is too narrow or too wide.\n";
				return 0;
			}
			else if(spotFit.ellipticity() < thePhILMPreferences.minimumEllipticity
					|| spotFit.ellipticity() > thePhILMPreferences.maximumEllipticity)
			{
				//std::cout << "The spot does not meet the ellipticity requirements.\n";
				return 0;
			}
			else {
				//std::cout << "The spot is good.\n";
				return 1;
			}
			
		}
	}
    
	
    ///This function takes all the detected spots and their frame averaging ranges, and then it calculates spot fits.
	int createSpotFitsFile(const char *inputFileName, int minimumNumberOfFramesToAverage, double darkCountsNoise)
    {
        std::vector< TNT::Array2D< int > > imageVector;
		SimonsonLibTIFF_IO::readTIFFStack(inputFileName, imageVector);
        return createSpotFitsFile(imageVector, minimumNumberOfFramesToAverage, darkCountsNoise);
    }
    
    
    ///This function takes all the detected spots and their frame averaging ranges, and then it calculates spot fits.
	int createSpotFitsFile(std::vector< TNT::Array2D< int > > &imageVector, int minimumNumberOfFramesToAverage, double darkCountsNoise)
	{	
		int numGoodFitsFound = 0;
		
		if(minimumNumberOfFramesToAverage < 1)
		{
			std::cout << "minimumNumberOfFramesToAverage was entered as " << minimumNumberOfFramesToAverage << ".  Resetting to 1.\n";
			minimumNumberOfFramesToAverage = 1;
		}
		
		double spotFittingRadius = 4;
		ScienceFile spotFitsFile;			
		
		//std::cout << "Maximum number of good spot fits that can currently be contained in memory is " << spotFitsFile.data.max_size() << "\n";

		if (checkWhetherFileIsPresent(thePhILMPreferences.formOutputFilePath("finalSpotFrameRanges.txt").c_str())) 
		{
			ScienceFile spotRanges(thePhILMPreferences.formOutputFilePath("finalSpotFrameRanges.txt").c_str());
			int numSpots = spotRanges.numRows();
			int i;
#pragma omp parallel for //schedule(guided, 20)
			for(i = 0; i < numSpots; i++)
			{
				int spotRangesXPixel = spotRanges.at(i, 0);
				int spotRangesYPixel = spotRanges.at(i, 1);

				int frameWhenSpotAppears = spotRanges.at(i, 2);
				int lastFrameBeforeSpotDisappears = spotRanges.at(i, 3);
                int firstSubtractableFrame = spotRanges.at(i, 4);
				int lastSubtractableFrame = spotRanges.at(i, 5);
				
				int numFramesAveragedBeforePhotobleaching = lastFrameBeforeSpotDisappears - frameWhenSpotAppears + 1;
				int numFramesAveragedAfterPhotobleaching = lastSubtractableFrame - firstSubtractableFrame + 1;
				
				if(numFramesAveragedBeforePhotobleaching > minimumNumberOfFramesToAverage - 1)
				{
					if(numFramesAveragedAfterPhotobleaching > minimumNumberOfFramesToAverage - 1)
					{
						if (verboseOutput) {
							#pragma omp critical
							{
								std::cout << "Now fitting spot " << i + 1 << "...\n";
								std::cout << frameWhenSpotAppears << "	" << lastFrameBeforeSpotDisappears << "	"<< firstSubtractableFrame << "\t" << lastSubtractableFrame << "\n";
							}
						}
						TNT::Array2D<double> beforePhotobleachingArray;
						TNT::Array2D<double> afterPhotobleachingArray;
						TwoDGaussianFittingParametersAndErrors spotFit;

						//#pragma omp critical
						{
							//beforePhotobleachingArray = Return2DArray::returnIntArrayAverageOfFrames(multibitmap, frameWhenSpotAppears, lastFrameBeforeSpotDisappears);
							beforePhotobleachingArray = SimonsonLibTIFF_IO::returnAverageOfFramesAsDoubleArray(imageVector, frameWhenSpotAppears, lastFrameBeforeSpotDisappears);

							//afterPhotobleachingArray = Return2DArray::returnIntArrayAverageOfFrames(multibitmap, lastFrameBeforeSpotDisappears + 1, lastSubtractableFrame);
							afterPhotobleachingArray = SimonsonLibTIFF_IO::returnAverageOfFramesAsDoubleArray(imageVector, firstSubtractableFrame, lastSubtractableFrame);

						}

						spotFit = subtractRoundImageAndFitTo2DGaussian(beforePhotobleachingArray,
																	   afterPhotobleachingArray,
																	   darkCountsNoise, 
																	   spotRangesXPixel, 
																	   spotRangesYPixel, 
																	   spotFittingRadius,
																	   numFramesAveragedBeforePhotobleaching,
																	   numFramesAveragedAfterPhotobleaching);
						
						if(checkWhetherSpotIsGood(spotFit))
						{
							numGoodFitsFound++;
							std::vector<double> theFit = spotFit.returnFitAsVector();
							theFit.push_back(frameWhenSpotAppears);
							theFit.push_back(lastFrameBeforeSpotDisappears);
                            theFit.push_back(firstSubtractableFrame);
							theFit.push_back(lastSubtractableFrame);
							theFit.push_back(1);
							#pragma omp critical
							{
								if (spotFitsFile.data.max_size() == spotFitsFile.data.size()) {
									std::cout << "Already reached max size of the number of possible spot fits...\n";
								}
                                else
                                {
                                    spotFitsFile.addRow(theFit);
                                }
							}
						}	
					}
				}
			}
		}
		
		if (checkWhetherFileIsPresent(thePhILMPreferences.formOutputFilePath("finalAntiSpotFrameRanges.txt").c_str())) 
		{
			int i;
			ScienceFile antiSpotRanges(thePhILMPreferences.formOutputFilePath("finalAntiSpotFrameRanges.txt").c_str());
			int numAntiSpots = antiSpotRanges.numRows();
			//antiSpotRanges.display();
			//std::cout << "Finished reading finalAntiSpotFrameRanges.txt...\n";
			
#pragma omp parallel for //schedule(guided, 20)
			for(i = 0; i < numAntiSpots; i++)
			{
				int earliestSubtractableFrame = antiSpotRanges.at(i, 2);
				int lastFrameBeforeSpotAppears = antiSpotRanges.at(i, 3);
                int frameInWhichSpotAppears = antiSpotRanges.at(i, 4);
				int lastFrameBeforeSpotCannotBeSingledOut = antiSpotRanges.at(i, 5);
				
				if(lastFrameBeforeSpotCannotBeSingledOut - frameInWhichSpotAppears > minimumNumberOfFramesToAverage - 2)
				{
					if(lastFrameBeforeSpotAppears - earliestSubtractableFrame > minimumNumberOfFramesToAverage - 2)
					{
						if (verboseOutput) 
						{
#pragma omp critical
							{
								std::cout << "Now fitting anti-spot " << i + 1 << "...\n";
								std::cout << earliestSubtractableFrame << "	" << lastFrameBeforeSpotAppears << "	" << frameInWhichSpotAppears << "\t" << lastFrameBeforeSpotCannotBeSingledOut << "\n";
							}
							
						}
						TNT::Array2D<double> beforePhotobleachingArray;
						TNT::Array2D<double> afterPhotobleachingArray;
//#pragma omp critical
						{
							beforePhotobleachingArray = SimonsonLibTIFF_IO::returnAverageOfFramesAsDoubleArray(imageVector, frameInWhichSpotAppears, lastFrameBeforeSpotCannotBeSingledOut);
							afterPhotobleachingArray = SimonsonLibTIFF_IO::returnAverageOfFramesAsDoubleArray(imageVector, earliestSubtractableFrame, lastFrameBeforeSpotAppears);
						}
						
						TwoDGaussianFittingParametersAndErrors spotFit = subtractRoundImageAndFitTo2DGaussian(beforePhotobleachingArray,
																											  afterPhotobleachingArray,
																											  darkCountsNoise, 
																											  antiSpotRanges.at(i, 0), 
																											  antiSpotRanges.at(i, 1), 
																											  spotFittingRadius);
						
						if(checkWhetherSpotIsGood(spotFit))
						{
							numGoodFitsFound++;
							std::vector<double> theFit = spotFit.returnFitAsVector();
							theFit.push_back(earliestSubtractableFrame);
							theFit.push_back(lastFrameBeforeSpotAppears);
							theFit.push_back(frameInWhichSpotAppears);
							theFit.push_back(lastFrameBeforeSpotCannotBeSingledOut);
							theFit.push_back(0);
							#pragma omp critical
							{
								if (spotFitsFile.data.max_size() == spotFitsFile.data.size()) {
									std::cout << "Already reached max size of the number of possible spot fits...\n";
								}
								
								spotFitsFile.addRow(theFit);
							}
						}
					}
				}
			}
		}
		
		std::cout << "Finished the fitting...\n";
		std::cout << "Number of good spot fits found = " << numGoodFitsFound << ".\n";
		char shrimpFileHeader[] = "%%peakHeight	x0	y0	xWidth	yWidth	background	tiltAngle	peakHeightError	x0Error	y0Error	xWidthError	yWidthError	backgroundError	tiltAngleError	frame1\tframe2\tframe3\tframe4\tspot?";
		//shrimpFits.display();
		
		spotFitsFile.writeToFile(thePhILMPreferences.formOutputFilePath("spotFits.txt").c_str(), shrimpFileHeader);
		
		std::cout << "\a";
				
		imageVector.clear();
		
		return numGoodFitsFound;
	}
	
    
    
	///Used in FastPhILM.
	int createSpotFitsFileFromBackwardsSubtracted(const char *inputFileName, double darkCountsNoise, double minimumSeparation)
	{	
		int numGoodFitsFound = 0;
		double spotFittingRadius = 4;
		
		std::vector<Magick::Image> imageVector;
		Magick::readImages(&imageVector, inputFileName);
		
		
		ScienceFile detectedSpots(thePhILMPreferences.formOutputFilePath("detectedSpots.txt").c_str());
		
		if(minimumSeparation)
		{
			;
		}
		
		
		int numSpots = detectedSpots.numRows();
		
		const int xColumn = 0;
		const int yColumn = 1;
		const int frameColumn = 2;
		
		ScienceFile shrimpFits;
		int i;
		for(i = 0; i < numSpots; i++)
		{
			if (verboseOutput) {
				std::cout << "Now fitting spot " << i + 1 << ", which is in frame " << detectedSpots.at(i, frameColumn) << "...\n";
			}
			
			TwoDGaussianFittingParametersAndErrors spotFit = fitIndicatedSpotTo2DGaussian(imageVector, detectedSpots.at(i,frameColumn), darkCountsNoise, detectedSpots.at(i,xColumn), detectedSpots.at(i,yColumn), spotFittingRadius);
			
			if(checkWhetherSpotIsGood(spotFit))
			{
				numGoodFitsFound++;
				std::vector<double> theFit = spotFit.returnFitAsVector();
				theFit.push_back(detectedSpots.at(i, frameColumn));
				theFit.push_back(detectedSpots.at(i, frameColumn));
				theFit.push_back(detectedSpots.at(i, frameColumn));
				theFit.push_back(1);
				shrimpFits.addRow(theFit);
			}					
		}
		
		
		std::cout << "Finished the fitting...\n";
		std::cout << "Number of good spot fits found = " << numGoodFitsFound << ".\n";
		char shrimpFileHeader[] = "%%peakHeight	x0	y0	xWidth	yWidth	background	tiltAngle	peakHeightError	x0Error	y0Error	xWidthError	yWidthError	backgroundError tiltAngleError";
		//std::cout << "Header: " << shrimpFileHeader << "\n";
		//shrimpFits.display();
		
		shrimpFits.writeToFile(thePhILMPreferences.formOutputFilePath("spotFits.txt").c_str(), shrimpFileHeader);
		
		std::cout << "\a";
		return numGoodFitsFound;
	}
    
}


