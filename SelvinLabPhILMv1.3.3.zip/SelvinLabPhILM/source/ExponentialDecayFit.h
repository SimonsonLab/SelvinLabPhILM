/*
 *  ExponentialDecayFit.h
 *  ReverseSTORM_SL
 *
 *  Created by Paul Simonson on 3/22/10.
 *  Copyright 2010 University of Illinois at Urbana-Champaign. All rights reserved.
 *
 */

#ifndef ExponentialDecayFit_H
#define ExponentialDecayFit_H

#include <cmath>
#include <iostream>
#include <vector>
#include <stdlib.h>
#include <stdio.h>

#include <gsl/gsl_randist.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_multifit_nlin.h>


class ExponentialDecayFit
{
public:
	ExponentialDecayFit();
	
	double A, B, C;
	
	double A_error, B_error, C_error;
	
	double frameAcquisitionTime;
	
	double fitTolerance;
	unsigned int maxNumberOfFitIterations;



	void print_state (size_t iter, gsl_multifit_fdfsolver * s);
	
	void fit(double frameAcquisitionTime, std::vector<double> yValues, std::vector<double> sigmas, bool verboseFitting);
	
private:

	int numIterations;
	
	std::vector<double> yValues;
	std::vector<double> sigmas;
	
	static int expb_f (const gsl_vector * x, void *data, gsl_vector * f);
	
	static int expb_df (const gsl_vector * x, void *data, gsl_matrix * J);
	
	static int expb_fdf (const gsl_vector * x, void *data, gsl_vector * f, gsl_matrix * J);
	
	
};
typedef class ExponentialDecayFit ExponentialDecayFit;


#endif


