/*
 *  tiffStackOperations.cpp
 *  ReverseSTORM
 *
 *  Created by Paul Simonson on 5/17/09.
 *  Copyright 2009 University of Illinois at Urbana-Champaign. All rights reserved.
 *
 */


const bool verboseOutput = false;

#include <omp.h>

#include "tiffStackOperations.h"
#include "tiffFrameOperations.h"
#include "return2DArrayFromMultiBitmap.h"
#include "SimonsonLibTIFF_IO.h"
#include "Magick++.h"
#include <vector>
using namespace Return2DArray;

const unsigned short newPixelOffset = 16384;


///This function uses ImageMagick.
int returnNumberOfFrames(const char *inputTIFFFileName)
{
	std::list<Magick::Image> imageList;
	Magick::readImages(&imageList, inputTIFFFileName);
	int numFrames = imageList.size();
	imageList.clear();
	return numFrames;
}


///Smooth along z in the stack
int smoothAlongZ(const char *inputFileName, const char *outputFileName)
{	
	//Make a stopwatch:
	TNT::Stopwatch Q;
	Q.start();
	
	//Initial useful information:
	std::vector<Magick::Image> imageList;
	Magick::readImages(&imageList, inputFileName);
	int numFrames = imageList.size();
	
	//The new image stack:
	std::vector<Magick::Image> newImageList;

	
	TNT::Array2D< int > originalFirstFrame = returnTNTArrayFromMagickImage(imageList.at(0));
	int width, height;
	width = originalFirstFrame.dim1();
	height = originalFirstFrame.dim2();
	
	
	//Handle the first frame.
	if(numFrames > 1)
	{
		TNT::Array2D< int > imageArray0 = returnTNTArrayFromMagickImage(imageList.at(0));//Return2DArray::return2DIntArrayFromMultiBitmap(multibitmap, 1);
		TNT::Array2D< int > imageArray1 = returnTNTArrayFromMagickImage(imageList.at(1));//Return2DArray::return2DIntArrayFromMultiBitmap(multibitmap, 2);
		multiplyByAConstant(imageArray0, 0.75);
		multiplyByAConstant(imageArray1, 0.25);
		imageArray0 = imageArray0 + imageArray1;
		newImageList.push_back(returnMagickImageFromTNTArray(imageArray0));

	}
	else//there was only one frame in the stack.
	{
		newImageList.push_back(imageList.at(0));
		
		//Close up shop and exit the function.	
		writeImages(newImageList.begin(), newImageList.end(), outputFileName, 1);
		std::cout << "Ending creation of smoothed image.\n";
		std::cout << "Time to do smoothing: " << Q.read() << " s, or " << Q.read()/60.0L << " minutes\n";
		
		return 0;
	}
	
	//If there are only two frames, smooth the second frame and exit.
	if(numFrames == 2)
	{
		TNT::Array2D< int > imageArray1 = returnTNTArrayFromMagickImage(imageList.at(0));//Return2DArray::return2DIntArrayFromMultiBitmap(multibitmap, 1);
		TNT::Array2D< int > imageArray2 = returnTNTArrayFromMagickImage(imageList.at(1));//Return2DArray::return2DIntArrayFromMultiBitmap(multibitmap, 2);
		multiplyByAConstant(imageArray2, 0.75);
		multiplyByAConstant(imageArray1, 0.25);
		imageArray2 = imageArray2 + imageArray1;

		newImageList.push_back(returnMagickImageFromTNTArray(imageArray2));
		
		//Close up shop and exit the function.	
		writeImages(newImageList.begin(), newImageList.end(), outputFileName, 1);
		std::cout << "Ending creation of smoothed image.\n";
		std::cout << "Time to do smoothing: " << Q.read() << " s, or " << Q.read()/60.0L << " minutes\n";
		
		return 0;
	}
	
	//If you made it this far, there were more than two frames.
	int i;
	for(i = 1; i < numFrames - 1; i++)
	{
		TNT::Array2D< int > imageArray0 = returnTNTArrayFromMagickImage(imageList.at(i-1));//Return2DArray::return2DIntArrayFromMultiBitmap(multibitmap, i);
		TNT::Array2D< int > imageArray1 = returnTNTArrayFromMagickImage(imageList.at(i));//Return2DArray::return2DIntArrayFromMultiBitmap(multibitmap, i+1);
		TNT::Array2D< int > imageArray2 = returnTNTArrayFromMagickImage(imageList.at(i+1));//Return2DArray::return2DIntArrayFromMultiBitmap(multibitmap, i + 2);
		multiplyByAConstant(imageArray0, 0.25);
		multiplyByAConstant(imageArray1, 0.5);
		multiplyByAConstant(imageArray2, 0.25);
		imageArray1 = imageArray1 + imageArray0;
		imageArray1 = imageArray1 + imageArray2;				
		newImageList.push_back(returnMagickImageFromTNTArray(imageArray1));
	}
	
	//Finish off the last frame.
	{
		TNT::Array2D< int > imageArray1 = returnTNTArrayFromMagickImage(imageList.at(numFrames - 2));//Return2DArray::return2DIntArrayFromMultiBitmap(multibitmap, numFrames - 1);
		TNT::Array2D< int > imageArray2 = returnTNTArrayFromMagickImage(imageList.at(numFrames - 1));//Return2DArray::return2DIntArrayFromMultiBitmap(multibitmap, numFrames);
		multiplyByAConstant(imageArray2, 0.75);
		multiplyByAConstant(imageArray1, 0.25);
		imageArray2 = imageArray2 + imageArray1;
		newImageList.push_back(returnMagickImageFromTNTArray(imageArray2));
	}
	
	//Close up shop and exit the function.	
	writeImages(newImageList.begin(), newImageList.end(), outputFileName, 1);
	std::cout << "Ending creation of smoothed image.\n";
	std::cout << "Time to do smoothing: " << Q.read() << " s, or " << Q.read()/60.0L << " minutes\n";
	
	return 0;
}


///This just reverses the order of the tiff frames.
int reverseFrames(const char *inputFileName, const char *outputFileName)
{
	//std::cout << "This program was written by:\nPaul D. Simonson\nSelvin Lab\nDepartment of Physics\nUniversity of Illinois at Urbana-Champaign\nCopyright 2009\n";

	std::list<Magick::Image> imageList;
	Magick::readImages(&imageList, inputFileName);
	imageList.reverse();
	writeImages(imageList.begin(), imageList.end(), outputFileName, 1);

	return 0;
}


///This is only used by QuickPhILM.
int quicklySequentiallySubtractFramesUsingFreeImage(const char *inputFileName, const char *outputFileName)
{
	//Make a stopwatch:
	TNT::Stopwatch Q;
	Q.start();
	

	FIMULTIBITMAP *multibitmap = FreeImage_OpenMultiBitmap(FIF_TIFF, inputFileName, 0, 1, 0, 0);
	int numFrames = FreeImage_GetPageCount(multibitmap);

	
	//The new image stack:
	std::vector<Magick::Image> newImageList;
	
	//TNT::Array2D< int > originalFirstFrame = returnTNTArrayFromMagickImage(imageList.at(0));
	TNT::Array2D< int > originalFirstFrame = return2DIntArrayFromMultiBitmap(multibitmap, 1);
	
	int width, height;
	width = originalFirstFrame.dim1();
	height = originalFirstFrame.dim2();
	TNT::Array2D< int > newPixelOffsetArray(width, height, newPixelOffset);
	
	//Set the first frame to the offset.
	newImageList.push_back(returnMagickImageFromTNTArray(newPixelOffsetArray));
	
	int j;
	for(j = 0;  j < numFrames - 1; j++)
	{
		int i = j + 1;
		TNT::Array2D< int > imageToSubtract = return2DIntArrayFromMultiBitmap(multibitmap, j+1);
		TNT::Array2D< int > imageArray = return2DIntArrayFromMultiBitmap(multibitmap, i+1);
		
		std::cout << "Now subtracting frame " << i << " from the stack...  Stopwatch says " << Q.read()/60.0L << " minutes.\n";
		imageArray = imageArray - imageToSubtract;
		imageArray = imageArray + newPixelOffsetArray;
		newImageList.push_back(returnMagickImageFromTNTArray(imageArray));
	}
	
	FreeImage_CloseMultiBitmap(multibitmap, TIFF_NONE);

	std::cout << "Ending creation of sequentially-subtracted image.\n";
	writeImages(newImageList.begin(), newImageList.end(), outputFileName, 1);
	std::cout << "Time to do backwards-subtraction: " << Q.read() << " s, or " << Q.read()/60.0L << " minutes\n";
	return 0;
}

/*

///This is the function used in PhILM.
int quicklySequentiallyBackwardsSubtractFramesUsingFreeImage(const char *inputFileName, const char *outputFileName)
{
	//Make a stopwatch:
	TNT::Stopwatch Q;
	Q.start();
	
    if (verboseOutput) {
        std::cout << "Now backwards-subtracting...\n";
    }
	
	FIMULTIBITMAP *multibitmap = FreeImage_OpenMultiBitmap(FIF_TIFF, inputFileName, 0, 1, 0, 0);
    
    if (verboseOutput) {
        std::cout << "Finished opening TIFF file...\n";
    }
    
	int numFrames = FreeImage_GetPageCount(multibitmap);
	
	

	TNT::Array2D< int > originalFirstFrame = return2DIntArrayFromMultiBitmap(multibitmap, 1);
	
    if (verboseOutput) {
        std::cout << "Returned first frame from TIFF file...\n";
    }
    
	int width, height;
	width = originalFirstFrame.dim1();
	height = originalFirstFrame.dim2();
	TNT::Array2D< int > newPixelOffsetArray(width, height, newPixelOffset);
	
    //The new image stack:
	std::vector<TNT::Array2D<int> > newImageList(numFrames);
        
	int j;
	for(j = 1;  j < numFrames; j++)
	{
		//int i = j - 1;
		TNT::Array2D< int > imageToSubtract = return2DIntArrayFromMultiBitmap(multibitmap, j+1);
		TNT::Array2D< int > imageArray = return2DIntArrayFromMultiBitmap(multibitmap, j);
		
        if (verboseOutput) {
            std::cout << "Now subtracting frame " << j + 1 << " from frame " << j << "...  Stopwatch says " << Q.read()/60.0L << " minutes.\n";
        }

		imageArray = imageArray - imageToSubtract;
		imageArray = imageArray + newPixelOffsetArray;
		newImageList.at(j - 1) = imageArray;
	}
	
	//Set the last frame to the offset.
	newImageList.at(numFrames - 1) = newPixelOffsetArray;
	FreeImage_CloseMultiBitmap(multibitmap, TIFF_NONE);
	
    if (verboseOutput) {
        std::cout << "Closed reading TIFF file...\n";
    }
    
	std::cout.flush();

    if (verboseOutput) {
        std::cout << "Now writing backwards-subtracted tiff stack to disk...\n";
    }
	//SimonsonLibTIFF_IO::writeTIFFStack(outputFileName, newImageList);//This one should be faster than using ImageMagick, but I am getting errors when I try running it on the physics network (but not on my laptop).
    writeTIFFStackUsingMagick(outputFileName, newImageList);

    std::cout << "Ending creation of sequentially-subtracted image.\n";
	std::cout << "Time to do backwards-subtraction: " << Q.read() << " s, or " << Q.read()/60.0L << " minutes\n";
	return 0;
}
*/

///This is the function I WANT to use in PhILM.  I believe there are errors when I try running it on the physics network using Condor.
int quicklySequentiallyBackwardsSubtractFramesUsingLibTIFF(const char *inputFileName, const char *outputFileName)
{
	//Make a stopwatch:
	TNT::Stopwatch Q;
	Q.start();
	
    if (verboseOutput) {
        std::cout << "Now backwards-subtracting...\n";
    }
	    
	std::vector< TNT::Array2D< int > > imageVector;
	SimonsonLibTIFF_IO::readTIFFStack<int>(inputFileName, imageVector);
	
    if (verboseOutput) {
        std::cout << "Finished opening TIFF file...  It has " << imageVector.size() << " frames.\n";
    }
    
	int numFrames = imageVector.size();
	
	TNT::Array2D< int > originalFirstFrame = imageVector.at(0);
	
    if (verboseOutput) {
        std::cout << "Returned first frame from TIFF file...\n";
    }
    
	int width, height;
	width = originalFirstFrame.dim1();
	height = originalFirstFrame.dim2();
	TNT::Array2D< int > newPixelOffsetArray(width, height, newPixelOffset);
	
    //The new image stack:
	std::vector<TNT::Array2D<int> > newImageList(numFrames);
	
	int j;
	#pragma omp parallel for
	for(j = 1;  j < numFrames; j++)
	{
        if (verboseOutput) {
#pragma omp critical
{
            std::cout << "Now subtracting frame " << j + 1 << " from frame " << j << "...  Stopwatch says " << Q.read()/60.0L << " minutes.\n";
}
        }
		TNT::Array2D< int > imageArray = imageVector.at(j-1);//return2DIntArrayFromMultiBitmap(multibitmap, j);
		imageArray = imageArray - imageVector.at(j);
		imageArray = imageArray + newPixelOffsetArray;
		newImageList.at(j - 1) = imageArray;
	}
	
	//Set the last frame to the offset.
	newImageList.at(numFrames - 1) = newPixelOffsetArray;
	imageVector.clear();
	
    if (verboseOutput) {
        std::cout << "Closed reading TIFF file...\n";
    }
    
	std::cout.flush();
	
    if (verboseOutput) {
        std::cout << "Now writing backwards-subtracted tiff stack to disk...\n";
    }

	//This one should be faster than using ImageMagick, but I am getting errors when I try running it on the physics network (but not on my laptop).
	SimonsonLibTIFF_IO::writeTIFFStack(outputFileName, newImageList);

    //writeTIFFStackUsingMagick(outputFileName, newImageList);
	
	std::cout << "Finished creation of sequentially-subtracted image.\n";

	if (verboseOutput) {
		std::cout << "Time to do backwards-subtraction: " << Q.read() << " s, or " << Q.read()/60.0L << " minutes\n";
	}

	return 0;
}




namespace UsingFreeImageIO {
	
	std::vector<double> returnAveragePixelIntensities(const char *inputFileName)
	{
		std::vector<double> averageIntensities;
		
		//Make a stopwatch:
		//TNT::Stopwatch Q;
		//Q.start();
		
		FIMULTIBITMAP *multibitmap = FreeImage_OpenMultiBitmap(FIF_TIFF, inputFileName, 0, 1, 0, 0);
		int numFrames = FreeImage_GetPageCount(multibitmap);
		
		TNT::Array2D< int > originalFirstFrame = return2DIntArrayFromMultiBitmap(multibitmap, 1);
		int width, height;
		width = originalFirstFrame.dim1();
		height = originalFirstFrame.dim2();
		long int numPixels = width * height;
		double inverse_numPixels = (double)1.0/(double)numPixels;
		
		int i, j, k;
		for (k = 0; k < numFrames; k++) {
			double averageIntensity = 0;
			
			TNT::Array2D< int > imageArray = return2DIntArrayFromMultiBitmap(multibitmap, k+1);
			
			for (i = 0; i < width; i++) {
				for (j = 0; j < height; j++) {
					averageIntensity += (double)(imageArray[i][j]) * inverse_numPixels;
				}
			}
			averageIntensities.push_back(averageIntensity);
		}
		FreeImage_CloseMultiBitmap(multibitmap, TIFF_NONE);	
		return averageIntensities;
	}
	
	
	TNT::Array2D< int > returnStandardDeviationOfFrames(const char *inputFileName, int startFrame, int endFrame)
	{
		///The start frame is ONE.
		
		TNT::Stopwatch Q;
		std::cout << "Calculating standard deviation image...\n";
		Q.start();
		FIMULTIBITMAP *multibitmap = FreeImage_OpenMultiBitmap(FIF_TIFF, inputFileName, 0, 1, 0, 0);
		std::cout << "Finished reading frames at " << Q.read() << ".\n";
		
		int numFrames = FreeImage_GetPageCount(multibitmap);

		if (endFrame < 1) {
			endFrame = numFrames;
		}
		
		int numToAverage = endFrame - startFrame + 1;
		
		std::cout << "Averaging frames...\n";
		Q.start();
		TNT::Array2D< double > averagedImage = returnDoubleArrayAverageOfFrames(multibitmap, startFrame, endFrame);
		std::cout << "Finished averaging frames... " << Q.read() << ".\n";;
		
		
		Q.start();
		int width, height;
		width = averagedImage.dim1();
		height = averagedImage.dim2();	
		TNT::Array2D< int > standardDeviationImage(width,height,0);

		TNT::Array2D< double > intermediateStandardDeviationImage(width,height, 0.0);
		
		if (numFrames < 2) {
			std::cout << "Sorry, this stack has less than 2 frames, so a standard deviation cannot be calculated!\n";
			return standardDeviationImage;
		}
				
		double multiplicationFactor = 1.0L/(double)(numToAverage-1);
		int i;
		for(i = startFrame; i < endFrame + 1; i++)
		{
			//std::cout << "i = " << i << ", startFrame = " << startFrame << ", endFrame = " << endFrame <<  "\n";
			TNT::Array2D< double > nextFrame = Return2DArray::return2DDoubleArrayFromMultiBitmap(multibitmap, i);
			int x,y;
			for (x = 0; x< width; x++) {
				for (y = 0; y<height; y++) {
					intermediateStandardDeviationImage[x][y] += multiplicationFactor * (double)((nextFrame[x][y] - averagedImage[x][y])*(nextFrame[x][y] - averagedImage[x][y]));
				}
			}
		}

		int x,y;
		for (x = 0; x< width; x++) {
			for (y = 0; y<height; y++) {
				standardDeviationImage[x][y] = sqrt(intermediateStandardDeviationImage[x][y]);
			}
		}
		
		std::cout << "Finished calculating standard deviation image..." << Q.read() << std::endl;
		
		return standardDeviationImage;
	}
	
	
	TNT::Array2D< int > returnAverageOfFrames(const char *inputFileName, int startFrame, int endFrame)
	{
		///The start frame is ONE.
		
		TNT::Stopwatch Q;
		std::cout << "Calculating standard deviation image...\n";
		Q.start();
		FIMULTIBITMAP *multibitmap = FreeImage_OpenMultiBitmap(FIF_TIFF, inputFileName, 0, 1, 0, 0);
		std::cout << "Finished reading frames at " << Q.read() << ".\n";
		
		int numFrames = FreeImage_GetPageCount(multibitmap);
		
		if (endFrame < 1) {
			endFrame = numFrames;
		}
				
		std::cout << "Averaging frames...\n";
		Q.start();
		TNT::Array2D< double > averagedImage = returnDoubleArrayAverageOfFrames(multibitmap, startFrame, endFrame);
		
		int width = averagedImage.dim1();
		int height = averagedImage.dim2();
		TNT::Array2D< int > resultImage(width, height);
		int x,y;
		for (x = 0; x< width; x++) {
			for (y = 0; y<height; y++) {
				resultImage[x][y] = averagedImage[x][y];
			}
		}
		
		std::cout << "Finished averaging frames... " << Q.read() << ".\n";
		
		return resultImage;
	}

	
}
