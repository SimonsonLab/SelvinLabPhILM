/*
 *  writeTIFFFileUsingMagick.cpp
 *  PositionAndFluorescenceTracker
 *
 *  Created by Paul Simonson on 7/14/09.
 *  Copyright 2009 Champaign Illinois Stake. All rights reserved.
 *
 */

#include "writeTIFFFileUsingMagick.h"
#include "Magick++.h"
#include "ScienceFile.h"
#include "return2DArrayFromMultiBitmap.h"

#include <iostream>


Magick::Image createNewMagick16BitImage(int columns, int rows)
{
	Magick::Image newImage(Magick::Geometry(columns, rows), "black");
	newImage.depth(16);
	newImage.magick("TIFF");
	newImage.type(Magick::GrayscaleType);
	newImage.endian(MagickCore::MSBEndian);
	
	return newImage;
}


Magick::ColorGray returnMagickColorUsingGrayScaleIntensity(int intensity)
{
	Magick::Color colorValue;
	colorValue.redQuantum(intensity);
	colorValue.greenQuantum(intensity);
	colorValue.blueQuantum(intensity);
	colorValue.alphaQuantum(0);
	
	//Magick::ColorGray colorValue2(intensity);

	
	return colorValue;
}


int writeTIFFFileUsingMagick(const char *fileName, TNT::Array2D< int > imageArray)
{
	int rows, columns;
	columns = imageArray.dim1();
	rows = imageArray.dim2();
	
	/*
	std::cout << "Number of rows: " << rows << "\n";
	std::cout << "Number of columns: " << columns << "\n";
	
	//Magick::Image newImage = createNewMagick16BitImage(columns, rows);
	
	Magick::Image newImage2("12.tif");
	 std::cout << "Number of rows: " << newImage2.rows() << "\n";
	 std::cout << "Number of columns: " << newImage2.columns() << "\n";
	 std::cout << "Image format: " << newImage2.magick() << "\n";
	 std::cout << "Image type: " << newImage2.type() << "\n";
	std::cout << "depth: " << newImage2.depth() << "\n";
	std::cout << "Endian type: " << newImage2.endian() << "\n";
	std::cout << "filename: " << newImage2.fileName() << "\n";
	std::cout << "quantize colors: " << newImage2.quantizeColors() << "\n";
	std::cout << "quantize color space: " << newImage2.quantizeColorSpace() << "\n";
	std::cout << "total colors: " << newImage2.totalColors() << "\n";
*/
	
	Magick::Image newImage = createNewMagick16BitImage(columns, rows);

	/*
	std::cout << "\n";
	std::cout << "Number of rows: " << newImage.rows() << "\n";
	std::cout << "Number of columns: " << newImage.columns() << "\n";
	std::cout << "Image format: " << newImage.magick() << "\n";
	std::cout << "Image type: " << newImage.type() << "\n";
	std::cout << "depth: " << newImage.depth() << "\n";
	std::cout << "Endian type: " << newImage.endian() << "\n";
	std::cout << "filename: " << newImage.fileName() << "\n";
	std::cout << "quantize colors: " << newImage.quantizeColors() << "\n";
	std::cout << "quantize color space: " << newImage.quantizeColorSpace() << "\n";
	std::cout << "total colors: " << newImage.totalColors() << "\n";*/
	
	//newImage.debug(1);
	newImage.depth(16);
	newImage.magick("TIFF");
	newImage.type(Magick::GrayscaleType);
	newImage.endian(MagickCore::MSBEndian);
	
	/*
	std::cout << "\n";
	std::cout << "Number of rows: " << newImage.rows() << "\n";
	std::cout << "Number of columns: " << newImage.columns() << "\n";
	std::cout << "Image format: " << newImage.magick() << "\n";
	std::cout << "Image type: " << newImage.type() << "\n";
	std::cout << "depth: " << newImage.depth() << "\n";
	std::cout << "Endian type: " << newImage.endian() << "\n";
	std::cout << "filename: " << newImage.fileName() << "\n";
	std::cout << "quantize colors: " << newImage.quantizeColors() << "\n";
	std::cout << "quantize color space: " << newImage.quantizeColorSpace() << "\n";
	std::cout << "total colors: " << newImage.totalColors() << "\n";
*/	

	//Magick::Pixels view(newImage);
	//Magick::PixelPacket *pixels = view.get(0,0,columns,rows); 

	int i, j;
	for(i = 0; i < columns; i++)
		for(j = 0; j < rows; j++)
			newImage.pixelColor( i, j, returnMagickColorUsingGrayScaleIntensity(imageArray[i][rows - j - 1]));
			//*pixels++ = returnMagickColorUsingGrayScaleIntensity(imageArray[i][rows - j - 1]); 
	
	//view.sync();

	newImage.write(fileName);
	return 0;
}


int writeTIFFFileUsingMagickUsingListOfSpotCenters(const char *listFileName, const char *baseTIFFFileName, const char *outputTIFFName, double spotRadius)
{
	if(spotRadius == 0)
	{
		std::cout << "Drawing spots in new tiff file.  What should the spot radius be (in pixels)?: ";
		std::cin >> spotRadius;
	}
	if(spotRadius < 1)
	{
		std::cout << "The spot radius was " << spotRadius << " and is being set to one.\n";
		spotRadius = 1;
	}
	
	class ScienceFile spotsList(listFileName);
	TNT::Array2D< int > imageArray = Return2DArray::return2DIntArrayFromMultiBitmap(baseTIFFFileName, 1);
	int width, height;
	width = imageArray.dim1();
	height = imageArray.dim2();
	TNT::Array2D< int > newImage(width, height, 0);
	
	int numSpots = spotsList.numRows();
	std::cout << "Number of columns: " << spotsList.numColumns() << "\n";
	//spotsList.display();
	std::cout << "Number of spots to draw: " << numSpots << "\n";
	int i;
	for(i = 0; i < numSpots; i++)
	{
		int xMaximum = spotsList.at(i, 1);
		int yMaximum = spotsList.at(i, 2);
		
		int minXRange =  xMaximum - (2.0 * spotRadius);
		if(minXRange < 0)
			minXRange = 0;
		
		int minYRange =  yMaximum - (2.0 * spotRadius);
		if(minYRange < 0)
			minYRange = 0;	
		
		int maxXRange =  xMaximum + (2.0 * spotRadius);
		if(maxXRange > width)
			maxXRange = width;
		
		int maxYRange =  yMaximum + (2.0 * spotRadius);
		if(maxYRange > height)
			maxYRange = height;
		
		int x, y;
		for (x = minXRange; x < maxXRange; x++)
			for (y = minYRange; y < maxYRange; y++)
			{
				//Intensity
				if(	pow((x - xMaximum), 2) + pow((y - yMaximum), 2) <= spotRadius * spotRadius &&
				   x >= 0 &&
				   y >= 0 &&
				   x < width &&
				   y < height)
				{
					newImage[x][y] = imageArray[x][y];
				}
			}
		std::cout << "Drew spot " << spotsList.at(i, 0) << "\n";
	}
	
	writeTIFFFileUsingMagick(outputTIFFName, newImage);
	return 0;
}


int writeTIFFFileUsingMagickUsingListOfSpotCentersAndIntensities(const char *listFileName, const char *baseTIFFFileName, const char *outputTIFFName, double spotRadius)
{
	const int spotIDColumn = 0;
	const int xColumn = 1;
	const int yColumn = 2;
	const int intensityColumn = 3;
	
	if(spotRadius == 0)
	{
		std::cout << "Drawing spots in new tiff file.  What should the spot radius be (in pixels)?: ";
		std::cin >> spotRadius;
	}
	if(spotRadius < 1)
	{
		std::cout << "The spot radius was " << spotRadius << " and is being set to one.\n";
		spotRadius = 1;
	}
	
	class ScienceFile spotsList(listFileName);
	TNT::Array2D< int > imageArray = Return2DArray::return2DIntArrayFromMultiBitmap(baseTIFFFileName, 1);
	int width, height;
	width = imageArray.dim1();
	height = imageArray.dim2();
	TNT::Array2D< int > newImage(width, height, 0);
	
	int numSpots = spotsList.numRows();
	std::cout << "Number of columns: " << spotsList.numColumns() << "\n";
	//spotsList.display();
	std::cout << "Number of spots to draw: " << numSpots << "\n";
	int i;
	for(i = 0; i < numSpots; i++)
	{
		int xMaximum = spotsList.at(i, xColumn);
		int yMaximum = spotsList.at(i, yColumn);
		
		int minXRange =  xMaximum - (2.0 * spotRadius);
		if(minXRange < 0)
			minXRange = 0;
		
		int minYRange =  yMaximum - (2.0 * spotRadius);
		if(minYRange < 0)
			minYRange = 0;	
		
		int maxXRange =  xMaximum + (2.0 * spotRadius);
		if(maxXRange > width)
			maxXRange = width;
		
		int maxYRange =  yMaximum + (2.0 * spotRadius);
		if(maxYRange > height)
			maxYRange = height;
		
		int x, y;
		for (x = minXRange; x < maxXRange; x++)
			for (y = minYRange; y < maxYRange; y++)
			{
				//Intensity
				if(	pow((x - xMaximum), 2) + pow((y - yMaximum), 2) <= spotRadius * spotRadius &&
				   x >= 0 &&
				   y >= 0 &&
				   x < width &&
				   y < height)
				{
					newImage[x][y] = spotsList.at(i, intensityColumn);
				}
			}
		std::cout << "Drew spot " << spotsList.at(i, spotIDColumn) << " with intensity " << spotsList.at(i, intensityColumn) << "\n";
	}
	
	writeTIFFFileUsingMagick(outputTIFFName, newImage);
	return 0;
}


int writeDuplicateTIFFUsingMagick(const char *inputFileName, const char *outputFileName)
{
	//std::cout << "This program was written by:\nPaul D. Simonson\nSelvin Lab\nDepartment of Physics\nUniversity of Illinois at Urbana-Champaign\nCopyright 2009\n";
	std::list<Magick::Image> imageList;
	Magick::readImages(&imageList, inputFileName);
	writeImages(imageList.begin(), imageList.end(), outputFileName, 1);	
	return 0;
}

