/*
 *  FastPhILM.cpp
 *  ReverseSTORM_SL
 *
 *  Created by Paul Simonson on 2/11/10.
 *  Copyright 2010 University of Illinois at Urbana-Champaign. All rights reserved.
 *
 */

#include "FastPhILM.h"

#include "PhILMCoreCode.h"

#include <vector>
#include <iostream>
#include <fstream>
#include <list>
#include <cmath>
#include <string>

#include "PhILMMicrotubuleExtras.h"
#include "writeTIFFFileUsingMagick.h"
#include "return2DArrayFromMultiBitmap.h"
#include "ScienceFile.h"
#include "tiffStackOperations.h"
#include "tiffFrameOperations.h"
#include "returnSpotIntensity.h"
//#include "fitTo2DGaussianUsingGSL.h"
#include "fitTo2DEllipticalGaussian.h"
#include "tiffFrameOperations.h"
#include "basicStatistics.h"
#include "FreeImage.h"

#include "detectParticlesClass.h"
#include "tiffStackOperations.h"
#include "Magick++.h"
#include "return2DArrayFromMultiBitmap.h"
#include "tiffFrameOperations.h"
#include "writeTIFFFileUsingMagick.h"
#include "returnDataForGaussianFitting.h"
#include "fitTo2DEllipticalGaussian.h"


using namespace Fitting2DEllipticalGaussianUsingGSL;
using namespace PhILM_namespace;

#define RESTRICTING_FRAME_RANGES

extern class PhILMPreferences thePhILMPreferences;



FastPhILM::FastPhILM()
{
	dilationSteps = 2;
	detectionThreshold = 50;
	minimumSpotSeparation = 6;
	zoomFactor = 10.667;
	
	darkCountsNoise = 20;
	drawingIntensityScalingFactor = 1;
	
	stepsCompleted = 0;
}


FastPhILM::~FastPhILM()
{
	std::cout << "Steps completed: " << stepsCompleted << ".\n";
	std::cout << "Thanks for using FastPhILM.\n";
}


int FastPhILM::startToFinish(void)
{
	if (thePhILMPreferences.usingBatchMode) {
		inputFileName = thePhILMPreferences.tiffFileName;
		minimumSpotSeparation = thePhILMPreferences.minimumSpotSeparation;
		detectionThreshold = thePhILMPreferences.detectionThreshold;
		zoomFactor = thePhILMPreferences.zoomFactor;
	}
	else {
		askForInputParameters();
	}

	
	TNT::Stopwatch Q;
	Q.start();
	
	createBackwardsSubtracted();
	createForwardsSubtracted();
	detectSpots();
	detectAntiSpots();
	createSpotFitsFile();
	createAntiSpotFitsFile();
	createSuperResolutionImages();
	
	std::cout << "\a\a\a\a\a";
	std::cout << "Total time to process " << inputFileName << " was " << Q.read()/60.0 << " minutes after starting algorithm.\n";
	std::cout << "Note that if your superResolution.tif file is blank, you probably need to choose option 'l' or 'g' and choose a smaller drawingIntensityScalingFactor value.\n";
	
	return 0;
}


//Individual steps
int FastPhILM::askForInputParameters(void)
{
	std::cout << "Please enter tiff file name: ";
	std::cin >> inputFileName;
	
	thePhILMPreferences.setTIFFFileName(inputFileName.c_str());
	thePhILMPreferences.chooseOutputDirectoryUsingTIFFName();

	std::cout << "Please enter minimum allowed spot separation: ";
	std::cin >> minimumSpotSeparation;
	thePhILMPreferences.minimumSpotSeparation = minimumSpotSeparation;
	
	std::cout << "Please enter detectionThreshold: ";
	std::cin >> detectionThreshold;
	thePhILMPreferences.detectionThreshold = detectionThreshold;
	
	std::cout << "Please enter zoomFactor: ";
	std::cin >> zoomFactor;
	thePhILMPreferences.zoomFactor = thePhILMPreferences.zoomFactor;
	
	stepsCompleted = 1;
	
	return 0;
}

int FastPhILM::createBackwardsSubtracted(void)
{
	quicklySequentiallyBackwardsSubtractFramesUsingLibTIFF(inputFileName.c_str(), thePhILMPreferences.formOutputFilePath("backwardsSubtracted.tif").c_str());
	stepsCompleted++;

	return 0;
}

int FastPhILM::createForwardsSubtracted(void)
{
	quicklySequentiallySubtractFramesUsingFreeImage(inputFileName.c_str(), thePhILMPreferences.formOutputFilePath("forwardsSubtracted.tif").c_str());

	stepsCompleted++;

	return 0;
}

int FastPhILM::detectSpots(void)
{
	DetectParticlesClass spotDetector;
	
	std::cout << "I made it this far.\n";
	
	spotDetector.detectParticlesUsingFreeImage(thePhILMPreferences.formOutputFilePath("backwardsSubtracted.tif").c_str(), 
											   thePhILMPreferences.formOutputFilePath("detectedSpots.txt").c_str(), 
											   1, -1, 0, dilationSteps, 3, detectionThreshold, minimumSpotSeparation, 0, 0, darkCountsNoise, 1, 16384);

	stepsCompleted++;

	return 0;
}

int FastPhILM::detectAntiSpots(void)
{
	DetectParticlesClass spotDetector;
	spotDetector.detectParticlesUsingFreeImage(thePhILMPreferences.formOutputFilePath("forwardsSubtracted.tif").c_str(), 
											   thePhILMPreferences.formOutputFilePath("detectedAntiSpots.txt").c_str(), 
											   1, -1, 0, dilationSteps, 3, detectionThreshold, minimumSpotSeparation, 0, 0, darkCountsNoise, 1, 16384);

	stepsCompleted++;

	return 0;
}

int FastPhILM::createSpotFitsFile(void)
{
	int numGoodFitsFound = 0;
	double spotFittingRadius = 4;
	
	FIMULTIBITMAP *multibitmap = FreeImage_OpenMultiBitmap(FIF_TIFF, thePhILMPreferences.formOutputFilePath("backwardsSubtracted.tif").c_str(), 0, 1, 0, 0);
	
	ScienceFile detectedSpots(thePhILMPreferences.formOutputFilePath("detectedSpots.txt").c_str());
	
	//detectedSpots.display();
	
	int numSpots = detectedSpots.numRows();
	
	const int xColumn = 0;
	const int yColumn = 1;
	const int frameColumn = 2;
	
	ScienceFile shrimpFits;
	int i;
	for(i = 0; i < numSpots; i++)
	{
		std::cout << "Now fitting spot " << i + 1 << ", which is in frame " << detectedSpots.at(i, frameColumn) << "...\n";
		
		TwoDGaussianFittingParametersAndErrors spotFit = fitIndicatedSpotTo2DGaussian(multibitmap, detectedSpots.at(i,frameColumn), darkCountsNoise, detectedSpots.at(i,xColumn), detectedSpots.at(i,yColumn), spotFittingRadius);
		
		if(checkWhetherSpotIsGood(spotFit), 1)
		{
			numGoodFitsFound++;
			std::vector<double> theFit = spotFit.returnFitAsVector();
			theFit.push_back(detectedSpots.at(i, frameColumn));
			theFit.push_back(detectedSpots.at(i, frameColumn));
			theFit.push_back(detectedSpots.at(i, frameColumn));
			theFit.push_back(1);
			shrimpFits.addRow(theFit);
		}					
	}
	
	std::cout << "Finished the fitting...\n";
	std::cout << "Number of good spot fits found = " << numGoodFitsFound << ".\n";
	char shrimpFileHeader[] = "%%peakHeight	x0	y0	xWidth	yWidth	background	tiltAngle	peakHeightError	x0Error	y0Error	xWidthError	yWidthError	backgroundError tiltAngleError";
	
	shrimpFits.writeToFile(thePhILMPreferences.formOutputFilePath("spotFits.txt").c_str(), shrimpFileHeader);
	
	std::cout << "\a";
	
	stepsCompleted++;

	return 0;
}

int FastPhILM::createAntiSpotFitsFile(void)
{
	int numGoodFitsFound = 0;
	double spotFittingRadius = 4;
	
	FIMULTIBITMAP *multibitmap = FreeImage_OpenMultiBitmap(FIF_TIFF, thePhILMPreferences.formOutputFilePath("forwardsSubtracted.tif").c_str(), 0, 1, 0, 0);
	
	ScienceFile detectedSpots(thePhILMPreferences.formOutputFilePath( "detectedAntiSpots.txt").c_str());
	
	int numSpots = detectedSpots.numRows();
	
	const int xColumn = 0;
	const int yColumn = 1;
	const int frameColumn = 2;
	
	ScienceFile shrimpFits;
	int i;
	for(i = 0; i < numSpots; i++)
	{
		std::cout << "Now fitting anti-spot " << i + 1 << ", which is in frame " << detectedSpots.at(i, frameColumn) << "...\n";
		
		TwoDGaussianFittingParametersAndErrors spotFit = fitIndicatedSpotTo2DGaussian(multibitmap, detectedSpots.at(i,frameColumn), darkCountsNoise, detectedSpots.at(i,xColumn), detectedSpots.at(i,yColumn), spotFittingRadius);
		
		if(checkWhetherSpotIsGood(spotFit, 1))
		{
			numGoodFitsFound++;
			std::vector<double> theFit = spotFit.returnFitAsVector();
			theFit.push_back(detectedSpots.at(i, frameColumn));
			theFit.push_back(detectedSpots.at(i, frameColumn));
			theFit.push_back(detectedSpots.at(i, frameColumn));
			theFit.push_back(1);
			shrimpFits.addRow(theFit);
		}					
	}
	
	std::cout << "Finished the fitting...\n";
	std::cout << "Number of good spot fits found = " << numGoodFitsFound << ".\n";
	char shrimpFileHeader[] = "%%peakHeight	x0	y0	xWidth	yWidth	background	tiltAngle	peakHeightError	x0Error	y0Error	xWidthError	yWidthError	backgroundError tiltAngleError";
	//std::cout << "Header: " << shrimpFileHeader << "\n";
	//shrimpFits.display();
	
	shrimpFits.writeToFile(thePhILMPreferences.formOutputFilePath("antiSpotFits.txt").c_str(), shrimpFileHeader);
	
	std::cout << "\a";
	
	stepsCompleted++;
	
	return 0;
}

int FastPhILM::createSuperResolutionImages(void)
{
	concatenateShrimpFitsFiles(thePhILMPreferences.formOutputFilePath("spotFits.txt").c_str(), 
							   thePhILMPreferences.formOutputFilePath("antiSpotFits.txt").c_str(), 
							   thePhILMPreferences.formOutputFilePath("spotFits.txt").c_str());

	quicklyDrawSpotsInSuperResolutionImage(inputFileName.c_str(), 
										   thePhILMPreferences.formOutputFilePath("superResolutionImage.tif").c_str(), 
										   zoomFactor, drawingIntensityScalingFactor, 0);
	quicklyDrawSpotsInSuperResolutionImage(inputFileName.c_str(), 
										   thePhILMPreferences.formOutputFilePath("superResolutionImage.maxZProject.tif").c_str(), 
										   zoomFactor, drawingIntensityScalingFactor, 1);
	quicklyDrawSpotsInSuperResolutionImage(inputFileName.c_str(), 
										   thePhILMPreferences.formOutputFilePath("superResolutionImage.pixels.tif").c_str(), 
										   zoomFactor, 1, 2);
	
	
	stepsCompleted++;

	return 0;
}
