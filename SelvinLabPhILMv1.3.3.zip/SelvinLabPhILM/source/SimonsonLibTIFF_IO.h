/*
 *  SimonsonLibTIFF_IO.h
 *  
 *
 *  Created by Paul Simonson on 1/1/11.
 *  Copyright 2011 Champaign Illinois Stake. All rights reserved.
 *
 */


#ifndef SimonsonLibTIFF_IO_H
#define SimonsonLibTIFF_IO_H

#include <string>
#include <vector>

#include <iostream>
#include <tiffio.h>

#include "tnt.h"

///My first real foray into templates...
namespace SimonsonLibTIFF_IO {
    
    
	
	int countFramesInTIFFStack(std::string tiffFileName);
	
	template <typename T>
	TNT::Array2D< T > return2DArrayFromTIFF(std::string tiffFileName, int frameNumber)
	{
		///For use with 16 bit gray scale TIFFs.
		
		TIFF* tif;
		
		tif = TIFFOpen(tiffFileName.c_str(), "r");
		
		if (tif) {
			
			TIFFSetDirectory(tif, frameNumber - 1);
			//std::cout << "TIFFSetDirectory(tif, frameNumber - 1) = " << TIFFSetDirectory(tif, frameNumber - 1) << "\n";
			
			//std::cout << "Frame number " << TIFFCurrentDirectory(tif) + 1 << ":\n";
			
			uint32 imageLength;
			uint16 config;
			tdata_t buf;
			
			TIFFGetField(tif, TIFFTAG_IMAGELENGTH, &imageLength);
			//std::cout << "imageLength = " << imageLength << "\n";
			
			uint32 imageWidth;
			TIFFGetField(tif, TIFFTAG_IMAGEWIDTH, &imageWidth);
			//std::cout << "imageWidth = " << imageWidth << "\n";
			
			TNT::Array2D< T > imageArray(imageWidth, imageLength);
			
			//std::cout << "TIFFScanlineSize(tif) = " << TIFFScanlineSize(tif) << "\n";
			
			TIFFGetField(tif, TIFFTAG_PLANARCONFIG, &config);
			
			//std::cout << "config = " << config << "\n";
			//std::cout << "PLANARCONFIG_CONTIG = " << PLANARCONFIG_CONTIG << "\n";
			//std::cout << "PLANARCONFIG_SEPARATE = " << PLANARCONFIG_SEPARATE << "\n";
			
			buf = _TIFFmalloc(TIFFScanlineSize(tif));
			if (config == PLANARCONFIG_CONTIG) {
				uint32 row;
				for (row = 0; row < imageLength; row++)
				{
					TIFFReadScanline(tif, buf, row);
					uint32 i;
					for (i = 0; i < imageWidth; i++) {
						//std::cout << ((uint16 *)buf)[i] << "	";
						imageArray[i][imageLength - row - 1] = (T)((uint16 *)buf)[i];
					}
					//std::cout << "\n";
				}
			} 
			else if (config == PLANARCONFIG_SEPARATE) 
			{
				uint16 s, nsamples;
				
				TIFFGetField(tif, TIFFTAG_SAMPLESPERPIXEL, &nsamples);
				for (s = 0; s < nsamples; s++)
				{
					uint32 row;
					for (row = 0; row < imageLength; row++)
					{
						TIFFReadScanline(tif, buf, row, s);
						uint32 i;
						for (i = 0; i < imageWidth; i++) {
							//std::cout << ((uint16 *)buf)[i] << "	";
							imageArray[i][imageLength - row - 1] = (T)((uint16 *)buf)[i];
						}
						//std::cout << "\n";
					}	
				}
		
			}
			_TIFFfree(buf);
			TIFFClose(tif);
			return imageArray;
		}
		else {
			TNT::Array2D< T > imageArray;
			std::cout << "The TIFF file could not be opened.\n";
			return imageArray;
		}
	}

	template <typename T>
	int writeTIFFFile(std::string outputTIFFFileName, TNT::Array2D< T > imageArray)
	{
		///Writes a new 16 bit, gray scale TIFF with one frame.
		
		TIFF* flatTiff = TIFFOpen(outputTIFFFileName.c_str(), "w");
		
		int width = imageArray.dim1();
		int height = imageArray.dim2();
		int bps = 16;
		int spp = 1;
		
		TIFFSetDirectory(flatTiff, 0);
		
		TIFFSetField(flatTiff, TIFFTAG_IMAGEWIDTH, width); 
		TIFFSetField(flatTiff, TIFFTAG_IMAGELENGTH, height); 
		TIFFSetField(flatTiff, TIFFTAG_COMPRESSION, COMPRESSION_NONE); 
		TIFFSetField(flatTiff, TIFFTAG_PLANARCONFIG, PLANARCONFIG_CONTIG); 
		TIFFSetField(flatTiff, TIFFTAG_BITSPERSAMPLE, bps); //bps=16 
		TIFFSetField(flatTiff, TIFFTAG_SAMPLESPERPIXEL, spp); //spp=1 
		TIFFSetField(flatTiff, TIFFTAG_ROWSPERSTRIP, height);    // put all rows(==height no of rows) in one strip 
		TIFFSetField(flatTiff, TIFFTAG_PHOTOMETRIC, PHOTOMETRIC_MINISBLACK); 
		TIFFSetField(flatTiff, TIFFTAG_FILLORDER, FILLORDER_MSB2LSB); 
		
		tdata_t buf = _TIFFmalloc(imageArray.dim1() * sizeof(uint16));
		
		int i;
		for (i = 0; i < height; i++) {
			int j;
			for (j = 0; j < width; j++) {
				((uint16 *)buf)[j] = imageArray[j][height - i - 1];
			}
			TIFFWriteScanline(flatTiff, buf, i);
		}
		
		_TIFFfree(buf);
		
		//TIFFWriteDirectory(flatTiff);
		
		TIFFClose(flatTiff);
		return 0;
	}
	
	template <typename T>
	int appendFrame(std::string outputTIFFFileName, TNT::Array2D< T > imageArray)
	{
		///Appends a 16 bit, gray scale TIFF.
		
		int numFrames = countFramesInTIFFStack(outputTIFFFileName);
		
		
		TIFF* flatTiff = TIFFOpen(outputTIFFFileName.c_str(), "a");
		
		int width = imageArray.dim1();
		int height = imageArray.dim2();
		int bps = 16;
		int spp = 1;
		
		TIFFSetDirectory(flatTiff, numFrames);
		
		TIFFSetField(flatTiff, TIFFTAG_IMAGEWIDTH, width); 
		TIFFSetField(flatTiff, TIFFTAG_IMAGELENGTH, height); 
		TIFFSetField(flatTiff, TIFFTAG_COMPRESSION, COMPRESSION_NONE); 
		TIFFSetField(flatTiff, TIFFTAG_PLANARCONFIG, PLANARCONFIG_CONTIG); 
		TIFFSetField(flatTiff, TIFFTAG_BITSPERSAMPLE, bps); //bps=16 
		TIFFSetField(flatTiff, TIFFTAG_SAMPLESPERPIXEL, spp); //spp=1 
		TIFFSetField(flatTiff, TIFFTAG_ROWSPERSTRIP, height);    // put all rows(==height no of rows) in one strip 
		TIFFSetField(flatTiff, TIFFTAG_PHOTOMETRIC, PHOTOMETRIC_MINISBLACK); 
		TIFFSetField(flatTiff, TIFFTAG_FILLORDER, FILLORDER_MSB2LSB); 
		
		tdata_t buf = _TIFFmalloc(imageArray.dim1() * sizeof(uint16));
		
		int i;
		for (i = 0; i < height; i++) {
			int j;
			for (j = 0; j < width; j++) {
				((uint16 *)buf)[j] = imageArray[j][height - i - 1];
			}
			TIFFWriteScanline(flatTiff, buf, i);
		}
		
		_TIFFfree(buf);
		
		//TIFFWriteDirectory(flatTiff);
		
		
		TIFFClose(flatTiff);
		return 0;
	}
	
	
	///This seems to write pretty fast--way faster than ImageMagick for sure.
	template <typename T>
	int writeTIFFStack(std::string outputTIFFFileName, std::vector< TNT::Array2D< T > > &imageArrayVector)
	{
		const bool verboseOutput = false;

		///Writes a new 16 bit, gray scale TIFF with one frame.
		
		if (verboseOutput) {
			std::cout	<< "Now writing TIFF file, " 
			<< outputTIFFFileName.c_str() 
			<< ", using int writeTIFFStack(std::string outputTIFFFileName, std::vector< TNT::Array2D< T > > imageArrayVector)...\n";
		}

		TIFF* flatTiff = TIFFOpen(outputTIFFFileName.c_str(), "w");

		if (!flatTiff) {
			std::cout << "The TIFF file " << outputTIFFFileName.c_str() << " could not be opened for writing.  Its value is " << flatTiff << ".\n";
			std::cout.flush();
		}
		else if (verboseOutput) {
			std::cout << "The TIFF was opened for writing.  Its value is " << flatTiff << ".\n";
			std::cout.flush();
		}

		
		int bps = 16;
		int spp = 1;
		
		int numFrames = imageArrayVector.size();
		int k;
		
		//failed: #pragma omp parallel for
		for (k = 0; k<numFrames; k++) 
		{
			if (verboseOutput) {
				std::cout << "Now writing frame " << k + 1 << ".\n";
				std::cout.flush();
			}
			
			TIFFSetDirectory(flatTiff, k);
			
			/*
			if (verboseOutput) {
				std::cout << "Set directory.\n";
				std::cout.flush();
			}
			 */
			
			int width = imageArrayVector.at(k).dim1();
			int height = imageArrayVector.at(k).dim2();
			
			TIFFSetField(flatTiff, TIFFTAG_IMAGEWIDTH, width); 
			TIFFSetField(flatTiff, TIFFTAG_IMAGELENGTH, height); 
			TIFFSetField(flatTiff, TIFFTAG_COMPRESSION, COMPRESSION_NONE); 
			TIFFSetField(flatTiff, TIFFTAG_PLANARCONFIG, PLANARCONFIG_CONTIG); 
			TIFFSetField(flatTiff, TIFFTAG_BITSPERSAMPLE, bps); //bps=16 
			TIFFSetField(flatTiff, TIFFTAG_SAMPLESPERPIXEL, spp); //spp=1 
			TIFFSetField(flatTiff, TIFFTAG_ROWSPERSTRIP, height);    // put all rows(==height no of rows) in one strip 
			TIFFSetField(flatTiff, TIFFTAG_PHOTOMETRIC, PHOTOMETRIC_MINISBLACK); 
			TIFFSetField(flatTiff, TIFFTAG_FILLORDER, FILLORDER_MSB2LSB); 
			
			/*
			if (verboseOutput) {
				std::cout << "Finished setting fields.\n";
				std::cout.flush();
			}
			*/
			
			tdata_t buf = _TIFFmalloc(imageArrayVector.at(k).dim1() * sizeof(uint16));
			
			int i;
			for (i = 0; i < height; i++) {
				int j;
				for (j = 0; j < width; j++) {
					((uint16 *)buf)[j] = imageArrayVector.at(k)[j][height - i - 1];
				}
				TIFFWriteScanline(flatTiff, buf, i);
			}
			
			_TIFFfree(buf);
			
			/*
			if (verboseOutput) {
				std::cout << "Wrote scanline.\n";
				std::cout.flush();
			}
			 */
			
			TIFFFlush(flatTiff);
		}
		
		
		TIFFClose(flatTiff);
		if (verboseOutput) {
			std::cout << "Finished writing " << outputTIFFFileName << ".\n";
		}
		return 0;
	}
	
	
    template <typename T>
	int writePartialTIFFStack(std::string outputTIFFFileName, std::vector< TNT::Array2D< T > > &imageArrayVector, unsigned int frameStart, unsigned int frameEnd)
	{
        const bool verboseOutput = false;
        
        //std::cout << frameStart << ", " << frameEnd << "\n";

        if (frameStart > imageArrayVector.size() || frameEnd > imageArrayVector.size() || frameStart > frameEnd) {
            std::cout << "Error: bad frame range.\n";
            return -1;
        }

        int numFramesToWrite = frameEnd - frameStart + 1;
        
		///Writes a new 16 bit, gray scale TIFF with one frame.
		
		if (verboseOutput) {
			std::cout	<< "Now writing TIFF file, " 
			<< outputTIFFFileName.c_str() 
			<< ", using int writeTIFFStack(std::string outputTIFFFileName, std::vector< TNT::Array2D< T > > imageArrayVector)...\n";
		}
        
		TIFF* flatTiff = TIFFOpen(outputTIFFFileName.c_str(), "w");
        
		if (!flatTiff) {
			std::cout << "The TIFF file " << outputTIFFFileName.c_str() << " could not be opened for writing.  Its value is " << flatTiff << ".\n";
			std::cout.flush();
		}
		else if (verboseOutput) {
			std::cout << "The TIFF was opened for writing.  Its value is " << flatTiff << ".\n";
			std::cout.flush();
		}
        
		
		int bps = 16;
		int spp = 1;
		
		//int numFrames = imageArrayVector.size();
		int k;
		
		//failed: #pragma omp parallel for
		for (k = 0; k < numFramesToWrite; k++) 
		{
			if (verboseOutput) {
				std::cout << "Now constructing frame " << k + 1 << ".\n";
				std::cout.flush();
			}
            
            unsigned int frameToWrite = frameStart + k - 1;
			
			TIFFSetDirectory(flatTiff, k);
			
			if (verboseOutput) {
				std::cout << "Set directory.\n";
				std::cout.flush();
			}
			
			int width = imageArrayVector.at(frameToWrite).dim1();
			int height = imageArrayVector.at(frameToWrite).dim2();
			
			TIFFSetField(flatTiff, TIFFTAG_IMAGEWIDTH, width); 
			TIFFSetField(flatTiff, TIFFTAG_IMAGELENGTH, height); 
			TIFFSetField(flatTiff, TIFFTAG_COMPRESSION, COMPRESSION_NONE); 
			TIFFSetField(flatTiff, TIFFTAG_PLANARCONFIG, PLANARCONFIG_CONTIG); 
			TIFFSetField(flatTiff, TIFFTAG_BITSPERSAMPLE, bps); //bps=16 
			TIFFSetField(flatTiff, TIFFTAG_SAMPLESPERPIXEL, spp); //spp=1 
			TIFFSetField(flatTiff, TIFFTAG_ROWSPERSTRIP, height);    // put all rows(==height no of rows) in one strip 
			TIFFSetField(flatTiff, TIFFTAG_PHOTOMETRIC, PHOTOMETRIC_MINISBLACK); 
			TIFFSetField(flatTiff, TIFFTAG_FILLORDER, FILLORDER_MSB2LSB); 
			
			if (verboseOutput) {
				std::cout << "Finished setting fields.\n";
				std::cout.flush();
			}
			
			
			tdata_t buf = _TIFFmalloc(imageArrayVector.at(frameToWrite).dim1() * sizeof(uint16));
			
			int i;
			for (i = 0; i < height; i++) {
				int j;
				for (j = 0; j < width; j++) {
					((uint16 *)buf)[j] = imageArrayVector.at(frameToWrite)[j][height - i - 1];
				}
				TIFFWriteScanline(flatTiff, buf, i);
			}
			
			_TIFFfree(buf);
			
			if (verboseOutput) {
				std::cout << "Wrote scanline.\n";
				std::cout.flush();
			}
			
			TIFFFlush(flatTiff);
		}
		
		
		TIFFClose(flatTiff);
		return 0;
	}
    
    
	template <typename T>
	std::vector< TNT::Array2D< T > > readTIFFStack(std::string tiffFileName)
	{
		///For use with 16 bit gray scale TIFFs.
		
		const bool usingDebuggingOutput = false;
		
        std::vector< TNT::Array2D< T > > imageVector;

		TIFF* tif;
		
		tif = TIFFOpen(tiffFileName.c_str(), "r");
		
		if (tif) {
            unsigned int numFrames = countFramesInTIFFStack(tiffFileName);
            imageVector.resize(numFrames);
            
            int k;
            for (k = 0; k< numFrames; k++) 
			{
                TIFFSetDirectory(tif,  k);
                                
                uint32 imageLength;
                uint16 config;
                tdata_t buf;
                
                TIFFGetField(tif, TIFFTAG_IMAGELENGTH, &imageLength);
                
                uint32 imageWidth;
                TIFFGetField(tif, TIFFTAG_IMAGEWIDTH, &imageWidth);
                
                TNT::Array2D< T > imageArray(imageWidth, imageLength);
                                
                TIFFGetField(tif, TIFFTAG_PLANARCONFIG, &config);
                
                buf = _TIFFmalloc(TIFFScanlineSize(tif));
                if (config == PLANARCONFIG_CONTIG) {
                    uint32 row;
                    for (row = 0; row < imageLength; row++)
                    {
                        TIFFReadScanline(tif, buf, row);
                        uint32 i;
                        for (i = 0; i < imageWidth; i++) {
                            //std::cout << ((uint16 *)buf)[i] << "	";
                            imageArray[i][imageLength - row - 1] = (T)((uint16 *)buf)[i];
                        }
                        //std::cout << "\n";
                    }
                } 
                else if (config == PLANARCONFIG_SEPARATE) 
                {
                    uint16 s, nsamples;
                    
                    TIFFGetField(tif, TIFFTAG_SAMPLESPERPIXEL, &nsamples);
                    for (s = 0; s < nsamples; s++)
                    {
                        uint32 row;
                        for (row = 0; row < imageLength; row++)
                        {
                            TIFFReadScanline(tif, buf, row, s);
                            uint32 i;
                            for (i = 0; i < imageWidth; i++) {
                                //std::cout << ((uint16 *)buf)[i] << "	";
                                imageArray[i][imageLength - row - 1] = (T)((uint16 *)buf)[i];
                            }
                            //std::cout << "\n";
                        }	
                    }
                    
                }
                _TIFFfree(buf);
                imageVector.at(k) = imageArray;
				if (usingDebuggingOutput) 
				{
					std::cout << "Finished reading frame " << k + 1 << "\n";
				}
            }
            TIFFClose(tif);
			if (usingDebuggingOutput) 
			{
				std::cout << "Finished closing reading tiff file.\n";
			}
			return imageVector;
		}
		else {
			std::cout << "The TIFF file " << tiffFileName << " could not be opened.\n";
			return imageVector;
		}
	}
    
	
	template <typename T>
	int readTIFFStack(std::string tiffFileName, std::vector< TNT::Array2D< T > > &imageVector)
	{
		///This should allow me to avoid copying back the whole tiff, I think...
		///For use with 16 bit gray scale TIFFs.
		
		const bool usingDebuggingOutput = false;

		imageVector.clear();
				
        //std::vector< TNT::Array2D< T > > imageVector;
		
		TIFF* tif;
		
		tif = TIFFOpen(tiffFileName.c_str(), "r");
		
		if (tif) {
			int numFrames = countFramesInTIFFStack(tiffFileName);
            imageVector.resize(numFrames);
            
            int k;
            for (k = 0; k< numFrames; k++) 
			{
                TIFFSetDirectory(tif,  k);
				
                uint32 imageLength;
                tdata_t buf;
                
                TIFFGetField(tif, TIFFTAG_IMAGELENGTH, &imageLength);
                
                uint32 imageWidth;
                TIFFGetField(tif, TIFFTAG_IMAGEWIDTH, &imageWidth);
                
                TNT::Array2D< T > imageArray(imageWidth, imageLength);
				uint16 config;
                TIFFGetField(tif, TIFFTAG_PLANARCONFIG, &config);
                
                buf = _TIFFmalloc(TIFFScanlineSize(tif));
                if (config == PLANARCONFIG_CONTIG) {
                    uint32 row;
                    for (row = 0; row < imageLength; row++)
                    {
                        TIFFReadScanline(tif, buf, row);
                        uint32 i;
                        for (i = 0; i < imageWidth; i++) {
							if (usingDebuggingOutput) {
								std::cout << ((uint16 *)buf)[i] << "	";
							}
                            imageArray[i][imageLength - row - 1] = (T)((uint16 *)buf)[i];
                        }
                        //std::cout << "\n";
                    }
                } 
                else if (config == PLANARCONFIG_SEPARATE) 
                {
                    uint16 s, nsamples;
                    
                    TIFFGetField(tif, TIFFTAG_SAMPLESPERPIXEL, &nsamples);
                    for (s = 0; s < nsamples; s++)
                    {
                        uint32 row;
                        for (row = 0; row < imageLength; row++)
                        {
                            TIFFReadScanline(tif, buf, row, s);
                            uint32 i;
                            for (i = 0; i < imageWidth; i++) {
                                //std::cout << ((uint16 *)buf)[i] << "	";
								if (usingDebuggingOutput) {
									std::cout << ((uint16 *)buf)[i] << "	";
								}
                                imageArray[i][imageLength - row - 1] = (T)((uint16 *)buf)[i];
                            }
                            //std::cout << "\n";
                        }	
                    }
                    
                }
				else {
					std::cout << "readTIFFStack error: config = " << config << ".  Now assuming it is PLANARCONFIG_CONTIG\a\n";
					{
						uint32 row;
						for (row = 0; row < imageLength; row++)
						{
							TIFFReadScanline(tif, buf, row);
							uint32 i;
							for (i = 0; i < imageWidth; i++) {
								if (usingDebuggingOutput) {
									std::cout << ((uint16 *)buf)[i] << "	";
								}
								imageArray[i][imageLength - row - 1] = (T)((uint16 *)buf)[i];
							}
							//std::cout << "\n";
						}
					}
				}

                _TIFFfree(buf);
                imageVector.at(k) = imageArray;
				if (usingDebuggingOutput) 
				{
					std::cout << "Finished reading frame " << k + 1 << "\n";
				}
            }
            TIFFClose(tif);
			if (usingDebuggingOutput) 
			{
				std::cout << "Finished closing reading tiff file.\n";
			}
			return 0;
		}
		else {
			std::cout << "The TIFF file " << tiffFileName << " could not be opened.\n";
			return -1;
		}
	}
	
    
	template <typename T>
	TNT::Array2D< double > returnAverageOfFramesAsDoubleArray(std::vector< TNT::Array2D< T > > &imageVector, int startFrame, int endFrame)
	{
		startFrame--;
		endFrame--;
		
		int width, height;
		int x, y;
		int numFrames = imageVector.size();
		if(startFrame > numFrames - 1)
		{
			startFrame = numFrames - 1;
			std::cout << "Start frame in averaging passes end of tiff stack--setting to last frame.\n";
		}
		if(endFrame > numFrames - 1)
		{
			endFrame = numFrames - 1;
			std::cout << "End frame in averaging passes end of tiff stack--setting to last frame.\n";
		}
		if(startFrame < 0)
		{
			std::cout << "Start frame was " << startFrame << "--setting to one.\n";
			startFrame = 0;
		}
		if(endFrame < 0)
		{
			std::cout << "End frame was " << endFrame << "--setting to one.\n";
			endFrame = 0;
		}
		int numToAverage = endFrame - startFrame;
		if(numToAverage < 0)
		{
			numToAverage = -numToAverage;
			int temp = startFrame;
			startFrame = endFrame;
			endFrame = temp;
			std::cout << "startFrame was greater than endFrame, so the two were swapped.\n";
		}
		numToAverage++;//to include the start frame.
		if(numToAverage == 0)//This should not be possible.
		{
			numToAverage = 1;
			std::cout << "Number of frames to average was zero--resetting to one (this should not be possible).\n";
		}
		//std::cout << "Number of frames to averge is " << numToAverage << ".\n";
		double multiplicationFactor = 1.0L/(double)numToAverage;
		
		//Get the necessary info to create the averaged frame.
		width = imageVector.at(0).dim1(); 
		height = imageVector.at(0).dim2(); 
		
		TNT::Array2D< double > averagedFrame(width,height,0.0L);
		int i;
		for(i = startFrame; i < endFrame + 1; i++)
		{
			for(y = 0; y < height; y++) 
			{ 
				for(x = 0; x < width; x++) 
				{ 
					averagedFrame[(int)x][(int)y] = averagedFrame[(int)x][(int)y] + multiplicationFactor * (double)(imageVector.at(i)[x][y]);
				}
			}
		}
		return averagedFrame;
	}
    
    
    template <typename T>
	TNT::Array2D< int > returnAverageOfFramesAsInt(std::vector< TNT::Array2D< T > > &imageVector, int startFrame, int endFrame)
	{
		startFrame--;
		endFrame--;
		
		int width, height;
		int x, y;
		int numFrames = imageVector.size();
		if(startFrame > numFrames - 1)
		{
			startFrame = numFrames - 1;
			std::cout << "Start frame in averaging passes end of tiff stack--setting to last frame.\n";
		}
		if(endFrame > numFrames - 1)
		{
			endFrame = numFrames - 1;
			std::cout << "End frame in averaging passes end of tiff stack--setting to last frame.\n";
		}
		if(startFrame < 0)
		{
			std::cout << "Start frame was " << startFrame << "--setting to one.\n";
			startFrame = 0;
		}
		if(endFrame < 0)
		{
			std::cout << "End frame was " << endFrame << "--setting to one.\n";
			endFrame = 0;
		}
		int numToAverage = endFrame - startFrame;
		if(numToAverage < 0)
		{
			numToAverage = -numToAverage;
			int temp = startFrame;
			startFrame = endFrame;
			endFrame = temp;
			std::cout << "startFrame was greater than endFrame, so the two were swapped.\n";
		}
		numToAverage++;//to include the start frame.
		if(numToAverage == 0)//This should not be possible.
		{
			numToAverage = 1;
			std::cout << "Number of frames to average was zero--resetting to one (this should not be possible).\n";
		}
		//std::cout << "Number of frames to averge is " << numToAverage << ".\n";
		double multiplicationFactor = 1.0L/(double)numToAverage;
		
		//Get the necessary info to create the averaged frame.
		width = imageVector.at(0).dim1(); 
		height = imageVector.at(0).dim2(); 
		
		TNT::Array2D< double > averagedFrame(width,height,0.0L);
		int i;
		for(i = startFrame; i < endFrame + 1; i++)
		{
			for(y = 0; y < height; y++) 
			{ 
				for(x = 0; x < width; x++) 
				{ 
					averagedFrame[(int)x][(int)y] = averagedFrame[(int)x][(int)y] + multiplicationFactor * (double)(imageVector.at(i)[x][y]);
				}
			}
		}
        
        TNT::Array2D< int > intAveragedFrame(width,height,0.0L);
		for(i = startFrame; i < endFrame + 1; i++)
		{
			for(y = 0; y < height; y++) 
			{ 
				for(x = 0; x < width; x++) 
				{ 
					intAveragedFrame[(int)x][(int)y] = (int)(averagedFrame[(int)x][(int)y]);
				}
			}
		}
		return intAveragedFrame;
	}
    
	
	template <typename T>
	T returnMaximumPixelIntensity(TNT::Array2D< T > &imageArray)
	{		
		unsigned int width, height;
		unsigned int x, y;
		T maximumPixelIntensity = 0;
		width = imageArray.dim1();
		height = imageArray.dim2();
		for (x = 0; x < width; x++) {
			for (y = 0; y < height; y++) {
				if (imageArray[x][y] > maximumPixelIntensity) {
					maximumPixelIntensity = imageArray[x][y];
				}
			}
		}
		return maximumPixelIntensity;
	}
	
	template <typename T>
	T returnMinimumPixelIntensity(TNT::Array2D< T > &imageArray)
	{		
		unsigned int width, height;
		unsigned int x, y;
		T minimumPixelIntensity = imageArray[0][0];
		width = imageArray.dim1();
		height = imageArray.dim2();
		for (x = 0; x < width; x++) {
			for (y = 0; y < height; y++) {
				if (imageArray[x][y] < minimumPixelIntensity) {
					minimumPixelIntensity = imageArray[x][y];
				}
			}
		}
		return minimumPixelIntensity;
	}
}

#endif
