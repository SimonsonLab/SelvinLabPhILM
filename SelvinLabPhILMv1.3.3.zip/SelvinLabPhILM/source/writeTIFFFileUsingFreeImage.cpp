/*
 *  writeTIFFFileUsingFreeImage.cpp
 *  PositionAndFluorescenceTracker
 *
 *  Created by Paul Simonson on 5/11/09.
 *  Copyright 2009 University of Illinois at Urbana-Champaign. All rights reserved.
 *
 */

#include "writeTIFFFileUsingFreeImage.h"
#include <iostream>
#include "FreeImage.h"
#include "ScienceFile.h"
#include "return2DArrayFromMultiBitmap.h"

FIBITMAP * returnFIBITMAPFromTNTArray(TNT::Array2D< int > imageArray)
{
	int width = imageArray.dim1();
	int height = imageArray.dim2();
	FIBITMAP *newFrame = FreeImage_AllocateT(FIT_UINT16, width, height, 16);
	int x, y;
	for(y = 0; y < height; y++) 
	{ 
		unsigned short *bits = (unsigned short *)FreeImage_GetScanLine(newFrame, y); 
		for(x = 0; x < width; x++) 
		{ 
			bits[(int)x] = imageArray[(int)x][(int)y];
		}
	}
	return newFrame;
}

int writeTIFFFileUsingFreeImage(const char *fileName, TNT::Array2D< unsigned short > imageArray)
{
	int width, height;
	width = imageArray.dim1();
	height = imageArray.dim2();
	int x, y;

	FIMULTIBITMAP *newTIFFFile;
	newTIFFFile = FreeImage_OpenMultiBitmap(FIF_TIFF, fileName, TRUE, FALSE, TRUE, 0);
	if(newTIFFFile)
	{
		FIBITMAP *newFrame = FreeImage_AllocateT(FIT_UINT16, width, height, 16); 
		for (y = 0; y < height; y++){
			unsigned short *bits = (unsigned short *)FreeImage_GetScanLine(newFrame, y); 
			for (x = 0; x < width; x++){
				bits[x] = imageArray[x][y];
			}
		}
		FreeImage_AppendPage(newTIFFFile, newFrame); 		
		FreeImage_CloseMultiBitmap(newTIFFFile, TIFF_NONE);
		FreeImage_Unload(newFrame);
		return 0;
	}
	std::cout << "A new TIFF file could not be created for writing.\n";
	return -1;
}

int writeTIFFFileUsingFreeImage(const char *fileName, TNT::Array2D< int > imageArray)
{
	int width, height;
	width = imageArray.dim1();
	height = imageArray.dim2();
	int x, y;
	
	FIMULTIBITMAP *newTIFFFile;
	newTIFFFile = FreeImage_OpenMultiBitmap(FIF_TIFF, fileName, TRUE, FALSE, TRUE, 0);
	if(newTIFFFile)
	{
		FIBITMAP *newFrame = FreeImage_AllocateT(FIT_UINT16, width, height, 16); 
		for (y = 0; y < height; y++){
			unsigned short *bits = (unsigned short *)FreeImage_GetScanLine(newFrame, y); 
			for (x = 0; x < width; x++){
				bits[x] = imageArray[x][y];
			}
		}
		FreeImage_AppendPage(newTIFFFile, newFrame); 
		FreeImage_CloseMultiBitmap(newTIFFFile, TIFF_NONE);
		FreeImage_Unload(newFrame);
		return 0;
	}
	std::cout << "A new TIFF file could not be created for writing.\n";
	return -1;
}

int appendToTIFFFileUsingFreeImage(const char *fileName, TNT::Array2D< unsigned short > imageArray)
{
	int width, height;
	width = imageArray.dim1();
	height = imageArray.dim2();
	int x, y;
	
	FIMULTIBITMAP *newTIFFFile;
	newTIFFFile = FreeImage_OpenMultiBitmap(FIF_TIFF, fileName, FALSE, FALSE, TRUE, 0);
	if(newTIFFFile)
	{
		FIBITMAP *newFrame = FreeImage_AllocateT(FIT_UINT16, width, height, 16); 
		for (y = 0; y < height; y++){
			unsigned short *bits = (unsigned short *)FreeImage_GetScanLine(newFrame, y); 
			for (x = 0; x < width; x++){
				bits[x] = imageArray[x][y];
			}
		}
		FreeImage_AppendPage(newTIFFFile, newFrame); 
		FreeImage_CloseMultiBitmap(newTIFFFile, TIFF_NONE);
		FreeImage_Unload(newFrame);
		return 0;
	}
	std::cout << "The TIFF file could not be opened for appending.\n";
	return -1;
}

int appendToTIFFFileUsingFreeImage(const char *fileName, TNT::Array2D< int > imageArray)
{
	int width, height;
	width = imageArray.dim1();
	height = imageArray.dim2();
	int x, y;
	
	FIMULTIBITMAP *newTIFFFile;
	newTIFFFile = FreeImage_OpenMultiBitmap(FIF_TIFF, fileName, FALSE, FALSE, TRUE, 0);
	if(newTIFFFile)
	{
		FIBITMAP *newFrame = FreeImage_AllocateT(FIT_UINT16, width, height, 16); 
		for (y = 0; y < height; y++){
			unsigned short *bits = (unsigned short *)FreeImage_GetScanLine(newFrame, y); 
			for (x = 0; x < width; x++){
				bits[x] = imageArray[x][y];
			}
		}
		FreeImage_AppendPage(newTIFFFile, newFrame); 
		FreeImage_CloseMultiBitmap(newTIFFFile, TIFF_NONE);
		FreeImage_Unload(newFrame);
		return 0;
	}
	std::cout << "The TIFF file could not be opened for appending.\n";
	return -1;
}

int writeTIFFFileUsingFreeImageUsingListOfSpotCenters(const char *listFileName, const char *baseTIFFFileName, const char *outputTIFFName, double spotRadius)
{
	if(spotRadius == 0)
	{
		std::cout << "Drawing spots in new tiff file.  What should the spot radius be (in pixels)?: ";
		std::cin >> spotRadius;
	}
	if(spotRadius < 1)
	{
		std::cout << "The spot radius was " << spotRadius << " and is being set to one.\n";
		spotRadius = 1;
	}
	
	class ScienceFile spotsList(listFileName);
	TNT::Array2D< int > imageArray = Return2DArray::return2DIntArrayFromMultiBitmap(baseTIFFFileName, 1);
	int width, height;
	width = imageArray.dim1();
	height = imageArray.dim2();
	TNT::Array2D< int > newImage(width, height, 0);
	
	int numSpots = spotsList.numRows();
	std::cout << "Number of columns: " << spotsList.numColumns() << "\n";
	//spotsList.display();
	std::cout << "Number of spots to draw: " << numSpots << "\n";
	int i;
	for(i = 0; i < numSpots; i++)
	{
		int xMaximum = spotsList.at(i, 1);
		int yMaximum = spotsList.at(i, 2);
		
		int minXRange =  xMaximum - (2.0 * spotRadius);
		if(minXRange < 0)
			minXRange = 0;
		
		int minYRange =  yMaximum - (2.0 * spotRadius);
		if(minYRange < 0)
			minYRange = 0;	
		
		int maxXRange =  xMaximum + (2.0 * spotRadius);
		if(maxXRange > width)
			maxXRange = width;
		
		int maxYRange =  yMaximum + (2.0 * spotRadius);
		if(maxYRange > height)
			maxYRange = height;
		
		int x, y;
		for (x = minXRange; x < maxXRange; x++)
			for (y = minYRange; y < maxYRange; y++)
			{
				//Intensity
				if(	pow((x - xMaximum), 2) + pow((y - yMaximum), 2) <= spotRadius * spotRadius &&
				   x >= 0 &&
				   y >= 0 &&
				   x < width &&
				   y < height)
				{
					newImage[x][y] = imageArray[x][y];
				}
			}
		std::cout << "Drew spot " << spotsList.at(i, 0) << "\n";
	}
	
	writeTIFFFileUsingFreeImage(outputTIFFName, newImage);
	return 0;
}


int writeTIFFFileUsingFreeImageUsingListOfSpotCentersAndIntensities(const char *listFileName, const char *baseTIFFFileName, const char *outputTIFFName, double spotRadius)
{
	const int spotIDColumn = 0;
	const int xColumn = 1;
	const int yColumn = 2;
	const int intensityColumn = 3;
	
	if(spotRadius == 0)
	{
		std::cout << "Drawing spots in new tiff file.  What should the spot radius be (in pixels)?: ";
		std::cin >> spotRadius;
	}
	if(spotRadius < 1)
	{
		std::cout << "The spot radius was " << spotRadius << " and is being set to one.\n";
		spotRadius = 1;
	}
	
	class ScienceFile spotsList(listFileName);
	TNT::Array2D< int > imageArray = Return2DArray::return2DIntArrayFromMultiBitmap(baseTIFFFileName, 1);
	int width, height;
	width = imageArray.dim1();
	height = imageArray.dim2();
	TNT::Array2D< int > newImage(width, height, 0);
	
	int numSpots = spotsList.numRows();
	std::cout << "Number of columns: " << spotsList.numColumns() << "\n";
	//spotsList.display();
	std::cout << "Number of spots to draw: " << numSpots << "\n";
	int i;
	for(i = 0; i < numSpots; i++)
	{
		int xMaximum = spotsList.at(i, xColumn);
		int yMaximum = spotsList.at(i, yColumn);
		
		int minXRange =  xMaximum - (2.0 * spotRadius);
		if(minXRange < 0)
			minXRange = 0;
		
		int minYRange =  yMaximum - (2.0 * spotRadius);
		if(minYRange < 0)
			minYRange = 0;	
		
		int maxXRange =  xMaximum + (2.0 * spotRadius);
		if(maxXRange > width)
			maxXRange = width;
		
		int maxYRange =  yMaximum + (2.0 * spotRadius);
		if(maxYRange > height)
			maxYRange = height;
		
		int x, y;
		for (x = minXRange; x < maxXRange; x++)
			for (y = minYRange; y < maxYRange; y++)
			{
				//Intensity
				if(	pow((x - xMaximum), 2) + pow((y - yMaximum), 2) <= spotRadius * spotRadius &&
				   x >= 0 &&
				   y >= 0 &&
				   x < width &&
				   y < height)
				{
					newImage[x][y] = spotsList.at(i, intensityColumn);
				}
			}
		std::cout << "Drew spot " << spotsList.at(i, spotIDColumn) << " with intensity " << spotsList.at(i, intensityColumn) << "\n";
	}
	
	writeTIFFFileUsingFreeImage(outputTIFFName, newImage);
	return 0;
}








int writeDuplicateTIFFUsingFreeImage(const char *inputFileName, const char *outputFileName)
{
	FIMULTIBITMAP *existingTIFFFile = FreeImage_OpenMultiBitmap(FIF_TIFF, inputFileName, 0, 1, 0, 0);
	int numFrames = FreeImage_GetPageCount(existingTIFFFile);
	FIMULTIBITMAP *newTIFFFile = FreeImage_OpenMultiBitmap(FIF_TIFF, outputFileName, TRUE, FALSE, TRUE, 0);
	if(newTIFFFile)
	{
		int i;
		for(i = 0; i < numFrames; i++)
		{
			FIBITMAP *lockedPage = FreeImage_LockPage(existingTIFFFile, i);
			FIBITMAP *newFrame = FreeImage_Clone(lockedPage);
			FreeImage_UnlockPage(existingTIFFFile, lockedPage, FALSE);
			FreeImage_AppendPage(newTIFFFile, newFrame); 
			FreeImage_Unload(newFrame);
		}
		FreeImage_CloseMultiBitmap(existingTIFFFile, TIFF_NONE);
		FreeImage_CloseMultiBitmap(newTIFFFile, TIFF_NONE);
		std::cout << "Done duplicating " << inputFileName << " as " << outputFileName << ".\n";
		return 0;
	}
	std::cout << "A new TIFF file could not be created for writing.\n";
	return -1;
}

