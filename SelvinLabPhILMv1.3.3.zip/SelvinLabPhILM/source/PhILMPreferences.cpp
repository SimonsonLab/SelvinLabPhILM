/*
 *  PhILMPreferences.cpp
 *  ReverseSTORM_SL
 *
 *  Created by Paul Simonson on 8/14/10.
 *  Copyright 2010 University of Illinois at Urbana-Champaign. All rights reserved.
 *
 */

#include <iostream>
#include <fstream>

#include "PhILMPreferences.h"
#include "ScienceFile.h"




int PhILMPreferences::generateDefaultPreferencesFile(const char *fileName)
{
	std::string preferencesHeader;
	std::vector<double> newPreferences;
	
	preferencesHeader = ("%darkCountsNoise");
	newPreferences.push_back(20);//counts
	
	preferencesHeader.append(", maximumLocalizationError");
	newPreferences.push_back(0.5);
	
	preferencesHeader.append(", minEllipticity");
	newPreferences.push_back(1);
	preferencesHeader.append(", maxEllipticity");
	newPreferences.push_back(1.5);
	
	preferencesHeader.append(", minSpotWidth");
	newPreferences.push_back(0.5);
	preferencesHeader.append(", maxSpotWidth");
	newPreferences.push_back(2.5);
	
	preferencesHeader.append(", minimumNumberOfFramesToAverage");
	newPreferences.push_back(1);
	preferencesHeader.append(", maxNumFramesToAverage");
	newPreferences.push_back(20);//frames
	
	preferencesHeader.append(", writeDetectedSpotsTIFFFiles");
	newPreferences.push_back(0);
	
	preferencesHeader.append(", minimumSpotWidthForStillDrawingGaussian");
	newPreferences.push_back(0.5);//zoomed pixels...
	
  	preferencesHeader.append(", maximumDetectionThreshold");
	newPreferences.push_back(0);//zoomed pixels...  
    
    preferencesHeader.append(", throwAwayIntermediateFrames");
	newPreferences.push_back(0);//zoomed pixels...
    
	ScienceFile defaultPreferences;
	defaultPreferences.addColumn(newPreferences);
	defaultPreferences.writeToFile(fileName, preferencesHeader.c_str());
	
	return 0;
}


int PhILMPreferences::loadPreferencesFile(const char *fileName)
{
	const int numPreferencesToLoad = 12;
	std::cout << "Now loading the preferences from file " << fileName << "...\n";
	ScienceFile PhILMPreferencesFile(fileName);
    
    PhILMPreferencesFile.display();
    
	if(PhILMPreferencesFile.numRows() != numPreferencesToLoad)
	{
		std::cout << "The preferences file, " << fileName << ", appears corrupted.  Please delete it and restart the program.\n";
		return(-1);
	}
	
	int i = 0;
    
	darkCountsNoise = PhILMPreferencesFile.at(i++,0);
	maximumLocalizationError = PhILMPreferencesFile.at(i++,0);
	minimumEllipticity = PhILMPreferencesFile.at(i++,0);
	maximumEllipticity = PhILMPreferencesFile.at(i++,0);
	minimumSpotWidth = PhILMPreferencesFile.at(i++,0);
	maximumSpotWidth = PhILMPreferencesFile.at(i++,0);
	minimumNumberOfFramesToAverage = PhILMPreferencesFile.at(i++,0);
	maxNumFramesToAverage = PhILMPreferencesFile.at(i++,0);
	writeDetectedSpotsTIFFFiles = PhILMPreferencesFile.at(i++,0);
	minimumSpotWidthForStillDrawingGaussian = PhILMPreferencesFile.at(i++,0);
    maximumDetectionThreshold = PhILMPreferencesFile.at(i++,0);
    throwAwayIntermediateFrames = PhILMPreferencesFile.at(i++,0);

	return 0;
}



int PhILMPreferences::setTIFFFileName(const char *fileName)
{
	tiffFileName = fileName;
	chooseOutputDirectoryUsingTIFFName();
	return 0;
}


int PhILMPreferences::chooseOutputDirectoryUsingTIFFName(void)
{
	size_t found;
	
	found = tiffFileName.find("/");
	if(found != std::string::npos)
	{
		
		std::cout << "Splitting: " << tiffFileName << std::endl;
		found = tiffFileName.find_last_of("/\\");
		
		outputDirectory = tiffFileName.substr(0,found) + "/";
		
		std::cout << " output folder: " << outputDirectory << std::endl;
		std::cout << " tiff file: " << tiffFileName.substr(found+1) << std::endl;
	}
	else {
		outputDirectory = "./";
		std::cout << " output folder: " << outputDirectory << std::endl;
		std::cout << " tiff file: " << tiffFileName.substr(found+1) << std::endl;
	}
	return 0;
}


std::string PhILMPreferences::returnOutputDirectory(void)
{
	return outputDirectory;
}


std::string PhILMPreferences::prefixWithOutputDirectory(const char *theString)
{
	std::string newString = outputDirectory + theString;
	return newString;
}


std::string PhILMPreferences::formOutputFilePath(std::string simpleFileName)
{
	std::string newFilePath;
	newFilePath = outputDirectory + outputFilePrefix + simpleFileName;
	return newFilePath;
}

int PhILMPreferences::checkWhetherFileIsPresent(const char *cpath)
{
	std::ifstream file; // indata is like cin
	file.open(cpath); // opens the file
	if(!file) { // file couldn't be opened
		return 0;
	}
	else
	{
		file.close();
		return 1;
	}
}



