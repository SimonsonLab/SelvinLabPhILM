/*
 *  returnSpotIntensity.h
 *  PositionAndFluorescenceTracker
 *
 *  Created by Paul Simonson on 5/6/09.
 *  Copyright 2009 University of Illinois at Urbana-Champaign. All rights reserved.
 *
 */

#ifndef returnSpotIntensity_H
#define returnSpotIntensity_H

#include "FreeImage.h"
#include "tnt.h"

double oneSpotAverageIntensity(TNT::Array2D< int > imageArray, 
							   double xMaximum, 
							   double yMaximum, 
							   double spotRadius, 
							   double backgroundRingWidth, 
							   int *pixelsCounted);

///Frame number counting system starts with ZERO.
double oneSpotAverageIntensity(FIMULTIBITMAP *multibitmap, 
							   int frameNumber, 
							   double xMaximum, 
							   double yMaximum, 
							   double spotRadius, 
							   double backgroundRingWidth, 
							   int *pixelsCounted);

///Frame number counting system starts with ZERO.
double oneSpotAverageIntensityNoBackgroundSubtraction(FIMULTIBITMAP *multibitmap, 
													  int frameNumber, 
													  double xMaximum, 
													  double yMaximum, 
													  double spotRadius, 
													  int *pixelsCounted);

///Frame number counting system starts with ONE.
double oneSpotAverageIntensityMethod2(TNT::Array2D< int > imageArray, 
							   double xMaximum, 
							   double yMaximum, 
							   double spotRadius, 
							   double backgroundRingWidth, 
							   int *pixelsCounted);

///Frame number counting system starts with ONE.
double oneSpotAverageIntensityMethod2(FIMULTIBITMAP *multibitmap, 
							   int frameNumber, 
							   double xMaximum, 
							   double yMaximum, 
							   double spotRadius, 
							   double backgroundRingWidth, 
							   int *pixelsCounted);


#endif

