/*
 *  writeTIFFFileUsingMagick.h
 *  PositionAndFluorescenceTracker
 *
 *  Created by Paul Simonson on 7/14/09.
 *  Copyright 2009 Champaign Illinois Stake. All rights reserved.
 *
 */



#ifndef writeTIFFFileUsingMagick_H
#define writeTIFFFileUsingMagick_H

#include "tnt.h"
#include <vector>
#include <string>
#include "Magick++.h"

int writeTIFFFileUsingMagick(const char *fileName, TNT::Array2D< int > imageArray);
int writeTIFFFileUsingMagickUsingListOfSpotCenters(const char *listFileName, const char *baseTIFFFileName, const char *outputTIFFName, double spotRadius);
int writeTIFFFileUsingMagickUsingListOfSpotCentersAndIntensities(const char *listFileName, const char *baseTIFFFileName, const char *outputTIFFName, double spotRadius);

int writeDuplicateTIFFUsingMagick(const char *inputFileName, const char *outputFileName);

Magick::Image createNewMagick16BitImage(int columns, int rows);


template <typename T>
Magick::Image returnMagickImageFromTNTArray(TNT::Array2D< T > imageArray)
{
	int rows, columns;
	columns = imageArray.dim1();
	rows = imageArray.dim2();
	
	Magick::Image newImage = createNewMagick16BitImage(columns, rows);

	int i;
	for(i = 0; i < columns; i++)
    { 
        int j;
		for(j = 0; j < rows; j++)
        {
			newImage.pixelColor( i, j, returnMagickColorUsingGrayScaleIntensity(imageArray[i][rows - j - 1]));
        }
    }
	
	return newImage;
}

template <typename T>
int writeTIFFStackUsingMagick(std::string outputFilePath, std::vector< TNT::Array2D<T> > imageVector)
{
    unsigned long i;
    unsigned long numFrames = imageVector.size();
    std::vector<Magick::Image> magickImageVector(numFrames);
    
    for (i = 0; i < numFrames; i++) {
        magickImageVector.at(i) = returnMagickImageFromTNTArray(imageVector.at(i));
    }
    
    writeImages(magickImageVector.begin(), magickImageVector.end(), outputFilePath, 1);	

    return 0;
}


#endif


