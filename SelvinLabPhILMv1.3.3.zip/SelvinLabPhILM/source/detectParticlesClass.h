/*
 *  detectParticlesClass.h
 *  ReverseSTORM_SL
 *
 *  Created by Paul Simonson on 1/23/10.
 *  Copyright 2010 University of Illinois at Urbana-Champaign. All rights reserved.
 *
 */

///I basically converted the detectParticles function into a class so that it would be more manageable and so that I don't mess up my original function with changes I am applying.

#ifndef detectParticlesClass_H
#define detectParticlesClass_H

#include "ScienceFile.h"
#include "tnt.h"
#include "twoDGaussianFit.h"
#include "FreeImage.h"
#include <vector>

///This class was introduced March 17 by Paul Simonson.
class DetectedSpot
{
public:
	bool markedForElimination;
	double xPosition;
	double yPosition;
	unsigned int frame;
	double averagePixelIntensity;
	unsigned int numPixelsAveraged;
	double spotWidth;
	TwoDGaussianFittingParametersAndErrors gaussianFit;
	
	DetectedSpot()
	{
		markedForElimination = false;
		xPosition = 0;
		yPosition = 0;
		frame = 0;
		averagePixelIntensity = 0;
		numPixelsAveraged = 0;
		spotWidth = 0;
	}
};




class DetectParticlesClass 
{
public:

	
	//Variables

	std::vector<class DetectedSpot> detectedSpots;
	
	std::string inputFileName;
	std::string outputFileName;
	std::string outputDirectory;
	std::string outputFilePrefix;
	std::string spotsPerFrameFileName;
	
	int numFramesToAverage;
	int startFrame;
	int endFrame;
	int dilationSteps;
	int spotRadius;
	int threshold;
	double minimumSeparation;
	double minimumSpotWidth;
	double maximumSpotWidth;
	double backgroundNoise;
	int positiveParticles;
	double pixelIntensityCutoff;
	int numFrames;
    
    bool writeOutputTIFFsFlag;
	
	double backgroundRingWidth;
	double maximumSpotEllipticity;
	

	//Methods
	
    
	static int copyrightInformation(void);
    
	DetectParticlesClass()
	{
		backgroundRingWidth = 1;
		maximumSpotEllipticity = 1.5;
		writeOutputTIFFsFlag = false;
		spotsPerFrameFileName = "spotsPerFrame.txt";
	}
	
    
	void setWriteOutputTIFFsFlag(bool choice)
	{
		writeOutputTIFFsFlag = choice;
	}
    
    
	//Enter -1 for the startFrame to apply it to every frame.
	//Use positiveParticles to determine whether you search for hills or holes.	
	int detectParticlesUsingFreeImage(const char *inputTIFFFileName, //FIMULTIBITMAP *multibitmap, 
									  const char *outputFileName, 
									  int numFramesToAverage, 
									  int startFrame = -1, 
									  int endFrame = -1, 
									  int dilationSteps = 1, 
									  double spotRadius = 3, 
									  int threshold = 50, 
									  double minimumSeparation = 7,
									  double minimumSpotWidth = 0,
									  double maximumSpotWidth = 2,
									  double backgroundNoise = 20,
									  int positiveParticles = 1,
									  int pixelIntensityCutoff = 0);
    
    
    
    
    
    //Enter -1 for the startFrame to apply it to every frame.
	//Use positiveParticles to determine whether you search for hills or holes.	
	int detectParticles(std::vector< TNT::Array2D< int > > &imageVector, 
                        const char *outputFileName, 
                        int numFramesToAverage, 
                        int startFrame = -1, 
                        int endFrame = -1, 
                        int dilationSteps = 1, 
                        double spotRadius = 3, 
                        int threshold = 50, 
                        double minimumSeparation = 7,
                        double minimumSpotWidth = 0,
                        double maximumSpotWidth = 2,
                        double backgroundNoise = 20,
                        int positiveParticles = 1,
                        int pixelIntensityCutoff = 0);
    
    int detectParticles(std::vector< TNT::Array2D< int > > &imageVector);
    
	
	int updateDetectionSettings(const char *inputTIFFFileName, //FIMULTIBITMAP *multibitmap, 
								const char *outputFileName, 
								int numFramesToAverage, 
								int startFrame = -1, 
								int endFrame = -1, 
								int dilationSteps = 1, 
								double spotRadius = 3, 
								int threshold = 50, 
								double minimumSeparation = 7,
								double minimumSpotWidth = 0,
								double maximumSpotWidth = 2,
								double backgroundNoise = 20,
								int positiveParticles = 1,
								int pixelIntensityCutoff = 0);
	
	std::string formOutputFilePath(std::string simpleFileName);

	int writeDetectionSettings(void);
	
	void writeDetectedSpotsFile(void);
	
	int askForDetectionSettings(void);

	//void createDetectedSpotsTIFF(FIMULTIBITMAP *multibitmap);
    void createDetectedSpotsTIFF(std::vector< TNT::Array2D< int > > &imageVector);

	void writeSpotsPerFrameFile(unsigned int numFrames);

	
private:
	
	void updateListsOfAllGoodSpotsWithThoseFoundInCurrentFrame(int currentFrame);
	
	void clearVariablesForNewDetection(void);
	
	
	int width, height;

	int applyPixelIntensityCutoff(TNT::Array2D< int > &imageArray);

	int chooseOutputDirectoryUsingOutputFileName(void);
		
	int calculateSpotFits(TNT::Array2D<int> imageArray);

	int findLocalMaximaUsingImageAndDilatedImage(int frameNumber, TNT::Array2D<int> imageArray, TNT::Array2D<int> dilatedImageArray);
	
	
	double separationDistanceSquared(double x1, double x2, double y1, double y2);
	
	/*
	class ScienceFile thinSpotsNearImageEdge(std::vector<double> &xPositions, std::vector<double> &yPositions, double minimumDistanceFromEdge, int width, int height);
	
	class ScienceFile thinSpotsNearEachOther(std::vector<double> xPositions, std::vector<double> yPositions, double minimumSeparationDistance);
	
	class ScienceFile eliminateWideSpots(std::vector<double> &xPositions, 
										 std::vector<double> &yPositions, 
										 std::vector<double> &spotWidths,
										 double maximumSpotWidth);
	
	class ScienceFile eliminateNarrowSpots(std::vector<double> &xPositions, 
										   std::vector<double> &yPositions, 
										   std::vector<double> &spotWidths,
										   double minimumSpotWidth);
	
	ScienceFile calculateSpotWidths(TNT::Array2D<int> imageArray, 
									double backgroundNoise, 
									std::vector<double> &xPositions, 
									std::vector<double> &yPositions, 
									double spotFittingRadius);
	*/
	
	int correctFrameRanges(void);
};


#endif

