/*
 *  SimonsonLibTIFF_IO.cpp
 *  
 *
 *  Created by Paul Simonson on 1/1/11.
 *  Copyright 2011 Champaign Illinois Stake. All rights reserved.
 *
 */

#include "SimonsonLibTIFF_IO.h"

#include <iostream>
#include <tiffio.h>


namespace SimonsonLibTIFF_IO {
	
	int countFramesInTIFFStack(std::string tiffFileName)
	{
		TIFF* tif = TIFFOpen(tiffFileName.c_str(), "r");
		int dircount = 0;
		if (tif) {
			do {
				dircount++;
			} while (TIFFReadDirectory(tif));
			//printf("%d frames in %s\n", dircount, tiffFileName.c_str());
		}
		TIFFClose(tif);
		return dircount;
	}
    
}
