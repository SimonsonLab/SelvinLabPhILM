/*
 *  fitTo1DGaussian.cpp
 *  TwoPhotonMicroscopy
 *
 *  Created by Paul Simonson on 11/10/07.
 *  Copyright 2007 __MyCompanyName__. All rights reserved.
 *
 */

#include "fitTo1DGaussian.h"
#include "dataFileReader.h"

#include <stdio.h>
#include <iostream>
#include <fstream>
#include <stdlib.h>

#include <gsl/gsl_blas.h>
#include <gsl/gsl_multifit_nlin.h>

//void print_state (size_t iter, gsl_multifit_fdfsolver * s);

void
print_state (int iter, gsl_multifit_fdfsolver * s)
{
	printf ("iter: %3d, fit parameters = % 15.8f % 15.8f % 15.8f % 15.8f"
			"|f(x)| = %g\n",
			iter,
			gsl_vector_get (s->x, 0), 
			gsl_vector_get (s->x, 1),
			gsl_vector_get (s->x, 2),
			gsl_vector_get (s->x, 3),
			
			gsl_blas_dnrm2 (s->f));
}


struct data {
	size_t n;
	double * x;
	double * intensity;
	double * sigma;
};

int expb_f (const gsl_vector * guessParameters, void *data, gsl_vector * f)
{
	size_t n = ((struct data *)data)->n;
	double *x = ((struct data *)data)->x;
	double *intensity = ((struct data *)data)->intensity;
	double *sigma = ((struct data *) data)->sigma;
	
	double A = gsl_vector_get (guessParameters, 0);
	double lambda = gsl_vector_get (guessParameters, 1);
	double b = gsl_vector_get (guessParameters, 2);
	double mu_x = gsl_vector_get (guessParameters, 3);
	
	size_t i;
	
	for (i = 0; i < n; i++)
	{
		/* Not Model Yi = A * exp(-lambda * i) + b */
		double Yi = A * exp(-lambda * pow((x[i]-mu_x),2)) + b;
		gsl_vector_set (f, i, (Yi - intensity[i])/sigma[i]);
	}
	
	return GSL_SUCCESS;
}

int
expb_df (const gsl_vector * guessParameters, void *data, 
		 gsl_matrix * J)
{
	size_t n = ((struct data *)data)->n;
	double *x = ((struct data *) data)->x;
	double *sigma = ((struct data *) data)->sigma;
	
	double A = gsl_vector_get (guessParameters, 0);
	double lambda = gsl_vector_get (guessParameters, 1);
	double mu_x = gsl_vector_get (guessParameters, 3);
	
	size_t i;
	
	for (i = 0; i < n; i++)
	{
		/* Jacobian matrix J(i,j) = dfi / dxj, */
		/* where fi = (Yi - yi)/sigma[i],      */
		/*       Yi = A * exp(-lambda * i) + b  */
		/* and the xj are the parameters (A,lambda,b) */
		double s = sigma[i];
		double e = exp(-lambda * pow((x[i]-mu_x),2));
		gsl_matrix_set (J, i, 0, e/s); 
		gsl_matrix_set (J, i, 1, -(x[i]-mu_x)*(x[i]-mu_x)*A*e/s);
		gsl_matrix_set (J, i, 2, 1/s);
		gsl_matrix_set (J, i, 3, 2.0L*(x[i]-mu_x)*lambda*A*e/s);
	}
	return GSL_SUCCESS;
}

int expb_fdf (const gsl_vector * guessParameters, void *data, gsl_vector * f, gsl_matrix * J)
{
	expb_f (guessParameters, data, f);
	expb_df (guessParameters, data, J);
	return GSL_SUCCESS;
}

int fitTo1DGaussian(std::vector< std::vector<double> > inputData)
{
	const gsl_multifit_fdfsolver_type *T;
	gsl_multifit_fdfsolver *s;
	int status;
	unsigned int i, iter = 0;
	const size_t n = inputData[0].size();
	const size_t p = 4;
	
	gsl_matrix *covar = gsl_matrix_alloc (p, p);
	double x[n], intensity[n], sigma[n];
	struct data d = { n, x, intensity, sigma};
	gsl_multifit_function_fdf f;
	double guessParameters_init[p] = { 3000.0, 1.0, 1.0, 8.0 };
	gsl_vector_view guessParameters = gsl_vector_view_array (guessParameters_init, p);
	
	f.f = &expb_f;
	f.df = &expb_df;
	f.fdf = &expb_fdf;
	f.n = n;
	f.p = p;
	f.params = &d;
	
	/* This is the data to be fitted */
	for (i = 0; i < n; i++)
	{
		x[i] = inputData[0][i];
		intensity[i] =	inputData[1][i];		//234.5* t + 7.89 * t * t + 313.13131 
												//+ gsl_ran_gaussian (r, 0.1);
		sigma[i] = 0.1;
		printf ("data: %f %g %g\n", x[i], intensity[i], sigma[i]);
	};
	
	T = gsl_multifit_fdfsolver_lmsder;
	s = gsl_multifit_fdfsolver_alloc (T, n, p);
	gsl_multifit_fdfsolver_set (s, &f, &guessParameters.vector);
	
	print_state (iter, s);
	
	do
	{
		iter++;
		status = gsl_multifit_fdfsolver_iterate (s);
		
		printf ("status = %s\n", gsl_strerror (status));
		
		print_state (iter, s);
		
		if (status)
			break;
		
		status = gsl_multifit_test_delta (s->dx, s->x,
										  1e-5, 1e-5);
	}
	while (status == GSL_CONTINUE && iter < 500);
	
	gsl_multifit_covar (s->J, 0.0, covar);
	
#define FIT(i) gsl_vector_get(s->x, i)
#define ERR(i) sqrt(gsl_matrix_get(covar,i,i))
	
	{ 
		double chi = gsl_blas_dnrm2(s->f);
		double dof = n - p;
		double c = GSL_MAX_DBL(1, chi / sqrt(dof)); 
		
		printf("chisq/dof = %g\n",  pow(chi, 2.0) / dof);
		
		printf ("A      = %.5f +/- %.5f\n", FIT(0), c*ERR(0));
		printf ("lambda = %.5f +/- %.5f\n", FIT(1), c*ERR(1));
		printf ("b      = %.5f +/- %.5f\n", FIT(2), c*ERR(2));
		printf ("mu_x      = %.5f +/- %.5f\n", FIT(3), c*ERR(3));
		
	}
	
	printf ("status = %s\n", gsl_strerror (status));
	
	gsl_multifit_fdfsolver_free (s);
	gsl_matrix_free (covar);
	return 0;
}





void generate1DGaussianDataFile(void)
{
	std::ofstream file; // indata is like cin

	file.open("1DGaussianData.txt"); // opens the file
	
	/* This is the data to be fitted */
	double A = 4000.0L;
	double mu_x = 10.0L;
	double inv_var_x = 0.0075L;
	double B = 0.0L;

	int n = 21;
	double stepSize = 5.0;
	
	double x;
	double intensity;
	for (x = 0.0L; x < n; x++)
	{
		intensity =	A 
					* exp(-pow((stepSize*x-mu_x), 2)*inv_var_x) 
					+ B;
		file << stepSize*x << "	" << intensity << "\n";
	};
	file.close();
}
