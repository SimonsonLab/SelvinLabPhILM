/*
 *  returnDataForGaussianFitting.cpp
 *  PositionAndFluorescenceTracker
 *
 *  Created by Paul Simonson on 7/24/09.
 *  Copyright 2009 University of Illinois at Urbana Champaign. All rights reserved.
 *
 */

#include "returnDataForGaussianFitting.h"
#include "return2DArrayFromMultiBitmap.h"

ScienceFile returnDataForGaussianFitting(TNT::Array2D<int> imageArray)
{
	ScienceFile returnFile;
		
	int width, height;
	width = imageArray.dim1();
	height = imageArray.dim2();
	
	register int x, y;
	for (x = 0; x < width; x++)
		for (y = 0; y < height; y++)
		{
			std::vector<double> pixelData;
			pixelData.push_back(x);
			pixelData.push_back(y);
			pixelData.push_back(imageArray[x][y]);
			returnFile.addRow(pixelData);
		}
	
	return returnFile;
}

/*
ScienceFile returnDataForGaussianFitting(TNT::Array2D<int> imageArray, 
										 double spotCenterX,
										 double spotCenterY,
										 double spotRadius)
{
	ScienceFile returnFile;
	
	double spotRadiusSquared = pow(spotRadius, 2);
	
	int width, height;
	width = imageArray.dim1();
	height = imageArray.dim2();
	
	//Set the x-y pixel ranges (so you do not have to scan through the whole image).
	int minXRange =  spotCenterX - (spotRadius + 1);
	if(minXRange < 0)
		minXRange = 0;
	
	int minYRange =  spotCenterY - (spotRadius + 1);
	if(minYRange < 0)
		minYRange = 0;	
	
	int maxXRange =  spotCenterX + (spotRadius + 1);
	if(maxXRange > width)
		maxXRange = width;
	
	int maxYRange =  spotCenterY + (spotRadius + 1);
	if(maxYRange > height)
		maxYRange = height;
	
	register int x, y;
	for (x = minXRange; x < maxXRange; x++)
		for (y = minYRange; y < maxYRange; y++)
		{
			double distanceFromCenterSquared = pow((x - spotCenterX), 2) + pow((y - spotCenterY), 2);
			if(distanceFromCenterSquared <= spotRadiusSquared)
			{
				std::vector<double> pixelData;
				pixelData.push_back(x);
				pixelData.push_back(y);
				pixelData.push_back(imageArray[x][y]);
				returnFile.addRow(pixelData);
			}
		}

	return returnFile;
}
*/

ScienceFile returnDataForGaussianFitting(std::string tiffStackFilePath, 
										 int whichFrame,
										 double x,
										 double y,
										 double fittingRadius)
{
	TNT::Array2D<int> image = Return2DArray::return2DIntArrayFromMultiBitmap(tiffStackFilePath.c_str(), whichFrame);
	return returnDataForGaussianFitting(image, x, y, fittingRadius);
}

ScienceFile returnDataForGaussianFitting(FIMULTIBITMAP *multibitmap, 
										 int whichFrame,
										 double x,
										 double y,
										 double fittingRadius)
{
	TNT::Array2D<int> image = Return2DArray::return2DIntArrayFromMultiBitmap(multibitmap, whichFrame);
	return returnDataForGaussianFitting(image, x, y, fittingRadius);
}



