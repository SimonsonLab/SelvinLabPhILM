/*
 *  FastPhILM.h
 *  ReverseSTORM_SL
 *
 *  Created by Paul Simonson on 2/11/10.
 *  Copyright 2010 University of Illinois at Urbana-Champaign. All rights reserved.
 *
 */


#ifndef FastPhILM_H
#define FastPhILM_H

#include <string>


class FastPhILM {
public:
	FastPhILM();
	~FastPhILM();

	std::string inputFileName;
	double minimumSpotSeparation;
	double zoomFactor;
	double detectionThreshold;
	int dilationSteps;
	
	double darkCountsNoise;
	double drawingIntensityScalingFactor;

	int startToFinish(void);
	//Individual steps
	int askForInputParameters(void);
	int createBackwardsSubtracted(void);
	int createForwardsSubtracted(void);
	int detectSpots(void);
	int detectAntiSpots(void);
	int createSpotFitsFile(void);
	int createAntiSpotFitsFile(void);
	int createSuperResolutionImages(void);
	
private:
	int stepsCompleted;
	
};

typedef class FastPhILM FastPhILM;


#endif

