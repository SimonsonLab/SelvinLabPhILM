/*
 *  tiffStackOperations.h
 *  ReverseSTORM
 *
 *  Created by Paul Simonson on 5/17/09.
 *  Copyright 2009 University of Illinois at Urbana-Champaign. All rights reserved.
 *
 */

#ifndef tiffStackOperations_H
#define tiffStackOperations_H

#include "tnt.h"
#include <vector>

int returnNumberOfFrames(const char *inputTIFFFileName);
int smoothAlongZ(const char *inputTIFFFileName, const char *outputTIFFFileName);
int reverseFrames(const char *inputFileName, const char *outputFileName);
//int sequentiallySubtractFrames(const char *inputFileName, const char *outputFileName);
//int createBackwardsSubtractedTIFFs(const char *inputFileName, int smooth = 0);
//int subtractOneFrameFromFollowingFrames(const char * inputFileName, int frameToSubtract, const char *outputFileName);

//int quicklySequentiallySubtractFramesUsingMagick(const char *inputFileName, const char *outputFileName);
int quicklySequentiallySubtractFramesUsingFreeImage(const char *inputFileName, const char *outputFileName);

//int quicklySequentiallyBackwardsSubtractFramesUsingFreeImage(const char *inputFileName, const char *outputFileName);
int quicklySequentiallyBackwardsSubtractFramesUsingLibTIFF(const char *inputFileName, const char *outputFileName);



namespace UsingFreeImageIO {

	std::vector<double> returnAveragePixelIntensities(const char *inputFileName);
	TNT::Array2D< int > returnStandardDeviationOfFrames(const char *inputFileName, int startFrame, int endFrame);
	TNT::Array2D< int > returnAverageOfFrames(const char *inputFileName, int startFrame, int endFrame);

}







#endif


