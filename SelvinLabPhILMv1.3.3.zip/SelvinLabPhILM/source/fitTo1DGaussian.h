/*
 *  fitTo1DGaussian.h
 *  TwoPhotonMicroscopy
 *
 *  Created by Paul Simonson on 11/10/07.
 *  Copyright 2007 __MyCompanyName__. All rights reserved.
 *
 */

//Version 0.0.1

#ifndef FITTO1DGAUSSIAN_H
#define FITTO1DGAUSSIAN_H

#include <vector> //using vectors...
int fitTo1DGaussian(std::vector< std::vector<double> > inputData);
void generate1DGaussianDataFile(void);

#endif


