/*
 *  PhILMPreferences.h
 *  ReverseSTORM_SL
 *
 *  Created by Paul Simonson on 8/14/10.
 *  Copyright 2011 University of Illinois at Urbana-Champaign. All rights reserved.
 *
 */

#ifndef PhILMPreferences_H
#define PhILMPreferences_H

#include <string>

class PhILMPreferences 
{
    ///This class stores all of the preferences and parameters that might be needed globally by the program.
    
public:
	
    ///Variables loaded from file:
	double minimumEllipticity, maximumEllipticity;
	double minimumSpotWidth, maximumSpotWidth;
	double maximumLocalizationError;
	double minimumSpotWidthForStillDrawingGaussian;
	int maxNumFramesToAverage;
	bool writeDetectedSpotsTIFFFiles;
	int minimumNumberOfFramesToAverage;	
	float darkCountsNoise;
    double maximumDetectionThreshold;
    bool throwAwayIntermediateFrames;
	
	///Variables not loaded from preferences text file:
	double minimumSpotSeparation;
	double detectionThreshold;
	double zoomFactor;
	int drawingIntensityScalingFactor;
	bool usingBatchMode;
    std::string tiffFileName;
	std::string outputDirectory;
	std::string outputFilePrefix;
    int dilationSteps;
    int backwardsSubtractedImageZeroPoint;
    
    PhILMPreferences(std::string fileName)
    {
        dilationSteps = 2;
        backwardsSubtractedImageZeroPoint = 16384;
        usingBatchMode = 0;
        outputDirectory = "./";
        
        minimumSpotSeparation = 6;
        detectionThreshold = 50;
        zoomFactor = 10.667;
        drawingIntensityScalingFactor = 1;
        minimumNumberOfFramesToAverage = 1;	
        drawingIntensityScalingFactor = 1;
        
        maximumDetectionThreshold = 0.0; //A value of 0.0 means that the program will not use a maximum detection threshold value.
        throwAwayIntermediateFrames = false;
        
        if(checkWhetherFileIsPresent(fileName.c_str()))
        {
            loadPreferencesFile(fileName.c_str());
        }
        else {
            std::cout << "The file " << fileName << " was not found.  Now creating file " << fileName << " using default preferences.\n";
            generateDefaultPreferencesFile(fileName.c_str());
            loadPreferencesFile(fileName.c_str());
        }
    }
    
    int checkWhetherFileIsPresent(const char *cpath);
	int loadPreferencesFile(const char *);
	int generateDefaultPreferencesFile(const char *fileName);
	int setTIFFFileName(const char *fileName);
	int chooseOutputDirectoryUsingTIFFName(void);
	std::string returnOutputDirectory(void);
	std::string prefixWithOutputDirectory(const char *);
	std::string formOutputFilePath(std::string simpleFileName);
};	

#endif

