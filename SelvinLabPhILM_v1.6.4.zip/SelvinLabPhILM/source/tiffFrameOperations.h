/*
 *  tiffFrameOperations.h
 *  ReverseSTORM
 *
 *  Created by Paul Simonson on 5/18/09.
 *  Copyright 2009 University of Illinois at Urbana-Champaign. All rights reserved.
 *
 */

#ifndef tiffFrameOperations_H
#define tiffFrameOperations_H


#include <cstring>
#include <iostream>

#include "tnt.h"

#include "Magick++.h"


int returnMinimumPixelIntensity(TNT::Array2D< int > imageArray);
int returnMaximumPixelIntensity(TNT::Array2D< int > imageArray);
double returnMeanPixelIntensity(TNT::Array2D< int > imageArray);

void multiplyByAConstant(TNT::Array2D< int > imageArray, const double A);
void subtractAConstant(TNT::Array2D< int > imageArray, const double A);


void multiplyByAConstant(TNT::Array2D< double > imageArray, const double A);


void subtractAConstant(TNT::Array2D< double > imageArray, const double A);



TNT::Array2D<int>  scaleImageMinToMax(TNT::Array2D< int > imageArray);

TNT::Array2D<int>  scaleImageMinToMax(TNT::Array2D< int > imageArray, int newMin, int newMax);


TNT::Array2D< unsigned short > applyGammaFilter(TNT::Array2D< unsigned short > imageArray, const double gammaExponent);

TNT::Array2D<int>  dilateMaximaReturnTNTArray(TNT::Array2D< int > imageArray, int dilationSteps);
TNT::Array2D<int>  dilateMinimaReturnTNTArray(TNT::Array2D< int > imageArray, int dilationSteps);

TNT::Array2D<int> cropImageCenteringOnSpot(TNT::Array2D<int> imageArray, double xMaximum, double yMaximum, double spotRadius);

TNT::Array2D<int> changeNegativePixelsToZero(TNT::Array2D< int > imageArray);



Magick::Image returnMagickImageFromTNTArray(TNT::Array2D< int > imageArray);
TNT::Array2D< int > returnTNTArrayFromMagickImage(Magick::Image &inputImage);

#endif

