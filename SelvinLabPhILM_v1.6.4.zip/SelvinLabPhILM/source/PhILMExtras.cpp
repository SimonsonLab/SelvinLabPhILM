//
//  PhILMExtras.cpp
//  SelvinLabPhILM_XCode
//
//  Created by Paul Simonson on 3/28/11.
//  Copyright 2011 University of Illinois at Urbana-Champaign. All rights reserved.
//

#include "PhILMExtras.h"


#include <cstring>
#include <vector>
#include <iostream>
#include <fstream>
#include <list>
#include <cmath>

#include "writeTIFFFileUsingMagick.h"
#include "PhILMCoreCode.h"
#include "return2DArrayFromMultiBitmap.h"
#include "ScienceFile.h"
#include "tiffStackOperations.h"
#include "tiffFrameOperations.h"
#include "returnSpotIntensity.h"
//#include "fitTo2DGaussianUsingGSL.h"
#include "fitTo2DEllipticalGaussian.h"
#include "tiffFrameOperations.h"
#include "basicStatistics.h"
#include "FreeImage.h"

using namespace Fitting2DEllipticalGaussianUsingGSL;

#define RESTRICTING_FRAME_RANGES

//Global variables
extern PhILMPreferences thePhILMPreferences;
const int newPixelOffset = 32767;
const double pixelShiftForDrawingSuperResolutionImages = 0.5;

const bool verboseOutput = false;

namespace PhILM_namespace 
{
    
    void PhotobleachingLifetimeEstimate::calculatePhotobleachingLifetime(void)
    {			
        finishedCalculatingLifetime = 0;
        
        if(!thePhILMPreferences.usingBatchMode)
        {
            std::cout << "\nPlease enter the original tiff file path (use Unix style, i.e., forward slashes): ";
            std::cin >> thePhILMPreferences.tiffFileName;
            thePhILMPreferences.chooseOutputDirectoryUsingTIFFName();
            checkForExitCommand(thePhILMPreferences.tiffFileName.c_str());
        }
        
        averageIntensities.clear();
        averageIntensities = UsingFreeImageIO::returnAveragePixelIntensities(thePhILMPreferences.tiffFileName.c_str());
        sigmas.clear();
        sigmas.resize(averageIntensities.size(), 1);
        
        photobleachingDecayFit.fit(frameAcquisitionTime, averageIntensities, sigmas, verboseOutput);
        printPhotobleachingDecayFit();
        
        fluorescencePerFluorophorePerFrameInCounts = estimateFluorescencePerFluorophore();
        
        estimatedTotalCountsCollectedDuringLifetime = fluorescencePerFluorophorePerFrameInCounts * photobleachingDecayFit.B;
        
        std::cout << "The estimated photons (in terms of camera counts) collected during fluorophore photobleaching lifetime is " 
        << estimatedTotalCountsCollectedDuringLifetime
        << ".\n";
        
        finishedCalculatingLifetime = 1;
    }
    
    
    
    
    int plotOnsAndOffs(const char* inputTIFFFileName)
    {
        std::cout << "Note that this function only works with 16 bit TIFF files.\n";
        std::cout << "This function was written by:\nPaul D. Simonson\nSelvin Lab\nDepartment of Physics\nUniversity of Illinois at Urbana-Champaign\nCopyright 2009\n";
        
        //Get the dimensions for the output TIFF.
        TNT::Array2D< int > imageToSubtract = Return2DArray::return2DIntArrayFromMultiBitmap(inputTIFFFileName, 1);
        int width, height;
        width = imageToSubtract.dim1();
        height = imageToSubtract.dim2();
        
        //Create imageArray and fill it with on/offs...
        TNT::Array2D< int > imageArray(width, height, newPixelOffset);
        class ScienceFile positiveSpots(thePhILMPreferences.prefixWithOutputDirectory("detectedSpots.txt").c_str());
        class ScienceFile negativeSpots(thePhILMPreferences.prefixWithOutputDirectory("detectedAntiSpots.txt").c_str());
        int i;
        int numPositives = positiveSpots.numRows();
        for(i = 0; i < numPositives; i++)
        {
            int x = positiveSpots.returnElement(i, 0);
            int y = positiveSpots.returnElement(i, 1);
            imageArray[x][y] = imageArray[x][y] + 1;
        }
        int numNegativeSpots = negativeSpots.numRows();
        for(i = 0; i < numNegativeSpots; i++)
        {
            int x = negativeSpots.returnElement(i, 0);
            int y = negativeSpots.returnElement(i, 1);
            imageArray[x][y] = imageArray[x][y] - 1;
        }
        writeTIFFFileUsingMagick(thePhILMPreferences.prefixWithOutputDirectory("on_offs.tif").c_str(), imageArray);
        return 0;
    }
    
    
    double estimateFluorescencePerFluorophore(void)
    {
        if (checkWhetherFileIsPresent(thePhILMPreferences.formOutputFilePath("spotFits.txt").c_str())) {
            ScienceFile shrimpFits(thePhILMPreferences.formOutputFilePath("spotFits.txt").c_str());
            const int peakHeightColumn = 0;
            const int xWidthColumn = 3;
            const int yWidthColumn = 4;
            
            double medianPeakHeight = BasicStatistics::returnMedian(shrimpFits.returnColumn(peakHeightColumn));
            double medianXWidth = BasicStatistics::returnMedian(shrimpFits.returnColumn(xWidthColumn));
            double medianYWidth = BasicStatistics::returnMedian(shrimpFits.returnColumn(yWidthColumn));
            double fluorescencePerFluorophore = medianPeakHeight * 2.0L * M_PI * medianXWidth * medianYWidth;
            return fluorescencePerFluorophore;
        }
        else {
            std::cout << "Error: the file " << thePhILMPreferences.formOutputFilePath("spotFits.txt") << " could not be found for estimating fluorescencePerFluorophore.\n";
            return 0;
        }
        
    }
    
    
    double estimatePortionOfFluorophoresLocalized(int numberOfSpotsLocalized, const char *tiffFileName)
    {
        double fluorescencePerFluorophore = estimateFluorescencePerFluorophore();
        
        if(fluorescencePerFluorophore)
        {
            Magick::Image inputImage(tiffFileName);
            TNT::Array2D< int > imageArray = returnTNTArrayFromMagickImage(inputImage);
            
            double meanPixelIntensity = returnMeanPixelIntensity(imageArray);
            double minimumPixelIntensity = returnMinimumPixelIntensity(imageArray);
            double totalNumberOfFluorophores = (meanPixelIntensity - minimumPixelIntensity) * (double)(imageArray.dim1() * imageArray.dim2())/fluorescencePerFluorophore;
            return numberOfSpotsLocalized/totalNumberOfFluorophores;
        }
        else {
            std::cout << "Error: fluorescencePerFluorophore could not be calculated.\n";
            return -1;
        }
    }
}

