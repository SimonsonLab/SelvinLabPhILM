#ifndef fitTo2DEllipticalGaussianUsingGSL_HEADER
#define fitTo2DEllipticalGaussianUsingGSL_HEADER

#include <vector>
#include "tnt.h"
#include "twoDGaussianFit.h"
#include "Magick++.h"
#include "FreeImage.h"

namespace Fitting2DEllipticalGaussianUsingGSL {
	
	
	TwoDGaussianFittingParametersAndErrors fitTo2DGaussianUsingGSL(std::vector<double> xPositions, 
																		  std::vector<double> yPositions, 
																		  std::vector<double> pixelIntensities);
	
	TwoDGaussianFittingParametersAndErrors
	weightedFitTo2DGaussianUsingGSL(std::vector<double> xPositions, 
									std::vector<double> yPositions, 
									std::vector<double> pixelIntensities, 
									std::vector<double> sigmas,
									int verboseFitting = 0);
	
	
	TwoDGaussianFittingParametersAndErrors
	weightedFitTo2DGaussian(std::vector<double> xPositions, 
							std::vector<double> yPositions, 
							std::vector<double> pixelIntensities, 
							double cameraBaseline, 
							double backgroundNoise);
	
	TwoDGaussianFittingParametersAndErrors
	weightedFitTo2DGaussian(std::vector<double> xPositions, 
							std::vector<double> yPositions, 
							std::vector<double> pixelIntensities, 
							double backgroundNoise);
	
	TwoDGaussianFittingParametersAndErrors
	weightedFitTo2DGaussian(std::vector<double> xPositions, 
							std::vector<double> yPositions, 
							std::vector<double> pixelIntensities, 
							std::vector<double> presubtractedPixelIntensities, 
							double cameraBaseline, 
							double backgroundNoise,
							int numFramesToBeAveragedBeforePhotobleaching = 1,
							int numFramesToBeAveragedAfterPhotobleaching = 1);
	
	TwoDGaussianFittingParametersAndErrors 
	weightedFitTo2DGaussian(std::vector<double> xPositions, 
							std::vector<double> yPositions, 
							std::vector<double> pixelIntensities, 
							std::vector<double> preSubtractedPixelIntensities, 
							double backgroundNoise,
							int numFramesToBeAveragedBeforePhotobleaching = 1,
							int numFramesToBeAveragedAfterPhotobleaching = 1);
	
	double returnSpotWidth(std::vector<double> xPositions, 
						   std::vector<double> yPositions, 
						   std::vector<double> pixelIntensities);
	
	TwoDGaussianFittingParametersAndErrors 
	subtractRectangularImageAndFitTo2DGaussian(char *inputFileName, 
											   int frameNumberToAnalyze, 
											   int frameNumberToSubtract, 
											   double backgroundNoise);
	

	/*
	TwoDGaussianFittingParametersAndErrors 
	subtractRoundImageAndFitTo2DGaussian(TNT::Array2D<int> beforePhotobleachingArray,
										 TNT::Array2D<int> afterPhotobleachingArray,
										 double backgroundNoise, 
										 double x, 
										 double y, 
										 double spotRadius,
										 int numFramesToBeAveragedBeforePhotobleaching = 1,
										 int numFramesToBeAveragedAfterPhotobleaching = 1);
	*/
	
	///This function is now to be used in the PhILM core code.  April 11, 2011.
	TwoDGaussianFittingParametersAndErrors 
	subtractRoundImageAndFitTo2DGaussian(TNT::Array2D<double> beforePhotobleachingArray,
										 TNT::Array2D<double> afterPhotobleachingArray,
										 double backgroundNoise, 
										 double x, 
										 double y, 
										 double spotRadius,
										 int numFramesToBeAveragedBeforePhotobleaching = 1,
										 int numFramesToBeAveragedAfterPhotobleaching = 1);
	

		
	TwoDGaussianFittingParametersAndErrors 
	fitIndicatedSpotTo2DGaussian(const char *inputFileName, 
								 int frameNumberToAnalyze, 
								 double backgroundNoise, 
								 double x, 
								 double y, 
								 double spotRadius);
	
	TwoDGaussianFittingParametersAndErrors 
	fitIndicatedSpotTo2DGaussianTNT(TNT::Array2D<int> imageArray, 
									double backgroundNoise, 
									double x, 
									double y, 
									double spotRadius);
	
	TwoDGaussianFittingParametersAndErrors 
	fitIndicatedSpotTo2DGaussian(std::vector<Magick::Image> imageVector, 
								 int frameNumberToAnalyze, 
								 double backgroundNoise, 
								 double x, 
								 double y, 
								 double spotRadius);
	
	TwoDGaussianFittingParametersAndErrors 
	fitIndicatedSpotTo2DGaussian(FIMULTIBITMAP *multibitmap, 
								 int frameNumberToAnalyze, 
								 double backgroundNoise, 
								 double x, 
								 double y, 
								 double spotRadius);
}

#endif


