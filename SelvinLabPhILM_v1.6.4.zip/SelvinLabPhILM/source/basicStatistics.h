/*
 *  basicStatistics.h
 *  RotationTracker
 *
 *  Created by Paul Simonson on 2/22/08.
 *  Copyright 2008 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef basicStatistics_h
#define basicStatistics_h

#include <vector>



namespace BasicStatistics{
	
	inline int factorial(int number) {
		int temp;
		
		if(number <= 1) return 1;
		
		temp = number * factorial(number - 1);
		return temp;
	}
	
	double returnMean(const std::vector<double> &x);
	double returnMedian(const std::vector<double> &x);
	double returnStandardDeviation(const std::vector<double> &x);
	double returnStandardDeviation(const std::vector<double> &x, const double mean);
	double returnSampleStandardDeviation(const std::vector<double> &x);
	double returnSampleStandardErrorOfTheMean(const std::vector<double> &x);

	std::vector<double> calculateStandardDeviationAsAFuntionOfTime(const std::vector<double> &x);

};

#endif
