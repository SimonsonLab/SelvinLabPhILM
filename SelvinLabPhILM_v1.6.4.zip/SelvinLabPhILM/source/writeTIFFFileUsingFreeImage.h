/*
 *  writeTIFFFileUsingFreeImage.h
 *  PositionAndFluorescenceTracker
 *
 *  Created by Paul Simonson on 5/11/09.
 *  Copyright 2009 University of Illinois at Urbana-Champaign. All rights reserved.
 *
 */


#ifndef writeTIFFFileUsingFreeImage_H
#define writeTIFFFileUsingFreeImage_H

#include "FreeImage.h"
#include "tnt.h"

FIBITMAP * returnFIBITMAPFromTNTArray(TNT::Array2D< int > imageArray);

int writeTIFFFileUsingFreeImage(const char *fileName, TNT::Array2D< int > imageArray);
int writeTIFFFileUsingFreeImage(const char *fileName, TNT::Array2D< unsigned short > imageArray);
int appendToTIFFFileUsingFreeImage(const char *fileName, TNT::Array2D< unsigned short > imageArray);
int appendToTIFFFileUsingFreeImage(const char *fileName, TNT::Array2D< int > imageArray);
int writeTIFFFileUsingFreeImageUsingListOfSpotCenters(const char *listFileName, const char *baseTIFFFileName, const char *outputTIFFName, double spotRadius);
int writeTIFFFileUsingFreeImageUsingListOfSpotCentersAndIntensities(const char *listFileName, const char *baseTIFFFileName, const char *outputTIFFName, double spotRadius);
int writeDuplicateTIFFUsingFreeImage(const char *inputFileName, const char *outputFileName);

#endif


