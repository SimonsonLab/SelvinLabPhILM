/*
 *  PhILMMicrotubuleExtras.h
 *  
 *
 *  Created by Paul Simonson on 2/7/11.
 *  Copyright 2011 Champaign Illinois Stake. All rights reserved.
 *
 */


#ifndef PhILMMicrotubuleExtras_H
#define PhILMMicrotubuleExtras_H

#include <iostream>
#include <fstream>

#include "FreeImage.h"
#include "tnt.h"
#include "Magick++.h"


#include "ScienceFile.h"
#include "twoDGaussianFit.h"
#include "ExponentialDecayFit.h"
#include "drawingSuperResolutionImages.h"
#include "PhILMPreferences.h"

using namespace DrawingSuperResolutionImages;

namespace PhILM_namespace
{

	//Finding microtubule widths
	int concatenateShrimpFitsFiles(const char* firstFile, const char * secondFile, const char * outputFile);
	
	std::vector<double> fitDataToStraightLine(std::vector<double> x0s, std::vector<double> y0s);
	std::vector<double> rotateCoordinates(double x, double y, double rotationAngle);
	int rotateShrimpFitsFile(const char *inputFileName, const char *outputFileName, double rotationAngle, double yIntercept);
	
	
	class MicrotubuleLineFit {
	public:
		MicrotubuleLineFit()
		{
			superResolutionZoomFactor = 10.667;
			calculationDone = 0;
		}
		
		Magick::Image outputImage;
		std::vector<double> lineFit;
		double superResolutionZoomFactor;
		
		std::string tiffFileName;
		std::string outputDirectory;
		std::string outputFilePrefix;
		
		int setTIFFFileName(const char *fileName)
		{
			tiffFileName = fileName;
			chooseOutputDirectoryUsingTIFFName();
			return 0;
		}
		
		std::string formOutputFilePath(std::string simpleFileName)
		{
			std::string newFilePath;
			newFilePath = outputDirectory + outputFilePrefix + simpleFileName;
			return newFilePath;
		}
		
		
		void drawLineFitInSuperResolutionImage();
		
		
		void drawLineFitInSuperResolutionImage(const std::string outputFileName)
		{
			drawLineFitInSuperResolutionImage();
			outputImage.write(formOutputFilePath(outputFileName));
		}
		
		
	private:
		bool calculationDone;
		int chooseOutputDirectoryUsingTIFFName(void)
		{
			size_t found;
			
			found = tiffFileName.find("/");
			if(found != std::string::npos)
			{
				
				std::cout << "Splitting: " << tiffFileName << std::endl;
				found = tiffFileName.find_last_of("/\\");
				
				outputDirectory = tiffFileName.substr(0,found) + "/";
				
				std::cout << " output folder: " << outputDirectory << std::endl;
				std::cout << " tiff file: " << tiffFileName.substr(found+1) << std::endl;
			}
			else {
				outputDirectory = "./";
				std::cout << " output folder: " << outputDirectory << std::endl;
				std::cout << " tiff file: " << tiffFileName.substr(found+1) << std::endl;
			}
			return 0;
		}
		
		int convertFitXToOutputX(int fitX);
		int convertFitYToOutputY(int fitY, int height);
		
	};
	
    
    
    
    
#include <vector>
#include <iostream>
    
#include "Magick++.h"
#include <gsl/gsl_multifit_nlin.h>
    
    
    class MicrotubuleFit {
        
    public:
        
        ///Constructor
        MicrotubuleFit()
        {
            ///This is where the default values are set for fitting the microtubule.
            numIterations = 0;
            maxNumberOfFitIterations = 1000;
            fitTolerance = 1e-10;
            verboseFitting = 0;
            doneFitting = 0;
            m = 0;
            b = 0;
            
            ///This is where the default values are set for drawing the image with the fit line running along the length of the microtubule.
            superResolutionZoomFactor = 10.667;
            calculationDone = 0;
            pixelShiftForDrawingSuperResolutionImages = 0;
            lineColor = "red";
            doneDrawing = 0;
        }
        
        std::string tiffFileName;
        std::string outputDirectory;
        std::string outputFilePrefix;
        
        Magick::Image outputImage;
        double superResolutionZoomFactor;
        double pixelShiftForDrawingSuperResolutionImages; 
        
        std::string lineColor;
        
        int setTIFFFileName(const char *fileName)
        {
            tiffFileName = fileName;
            chooseOutputDirectoryUsingTIFFName();
            return 0;
        }
        
        
        std::string formOutputFilePath(std::string simpleFileName)
        {
            std::string newFilePath;
            newFilePath = outputDirectory + outputFilePrefix + simpleFileName;
            return newFilePath;
        }
        
        
        int drawLineFitInImage();
        
        
        int drawLineFitInImage(const std::string outputFileName)
        {
            if (!doneDrawing) {
                drawLineFitInImage();
            }
            outputImage.write(formOutputFilePath(outputFileName));
            return 0;
        }
        
        bool verboseFitting;
        void fit(void);
        void printFit(void);
        
        std::vector<double> returnLineFit(void)
        {
            if (doneFitting) {
                return lineFit;
            }
            else {
                std::cout << "Fitting was not finished.  Returning lineFit anyway...\n";
                return lineFit;
            }
        }
        
        double rotationAngle(void)
        {
            return atan(lineFit.at(0));//in radians
        }
        
        void displayOutputImage(void)
        {
            if (!doneDrawing) {
                drawLineFitInImage();
            }
            outputImage.display();
        }
        
        void calculatePreliminaryFitUsingSpotFitsFile(void);
        
        
    private:
        
        std::vector<double> lineFit;
        
        
        std::vector<double> fitDataToStraightLine(std::vector<double> x0s, std::vector<double> y0s);
        int createDriftCorrectedSpotFitsFile(const char *driftCorrectionFileName, const char *spotFitsFileName, const char *outputFileName);
        double determineScalingFactorFromNormalAndSuperResolutionImages(std::string normalImageName, std::string superResolutionImageName);
        
        
        int checkWhetherFileIsPresent(const char *cpath);
        
        int chooseOutputDirectoryUsingTIFFName(void)
        {
            size_t found;
            
            found = tiffFileName.find("/");
            if(found != std::string::npos)
            {
                
                std::cout << "Splitting: " << tiffFileName << std::endl;
                found = tiffFileName.find_last_of("/\\");
                
                outputDirectory = tiffFileName.substr(0,found) + "/";
                
                std::cout << " output folder: " << outputDirectory << std::endl;
                std::cout << " tiff file: " << tiffFileName.substr(found+1) << std::endl;
            }
            else {
                outputDirectory = "./";
                std::cout << " output folder: " << outputDirectory << std::endl;
                std::cout << " tiff file: " << tiffFileName.substr(found+1) << std::endl;
            }
            return 0;
        }
        
        int convertFitXToOutputX(int fitX);
        int convertFitYToOutputY(int fitY, int height);
        
        bool calculationDone;
        
        ///The following deals with the curve fitting.
        double fitTolerance;
        int numIterations;
        unsigned int maxNumberOfFitIterations;
        
        std::vector<double> xValues;
        std::vector<double> yValues;
        std::vector<double> sigmas;
        
        void print_state (size_t iter, gsl_multifit_fdfsolver * s);
        static int expb_f (const gsl_vector * x, void *data, gsl_vector * f);
        static int expb_df (const gsl_vector * x, void *data, gsl_matrix * J);
        static int expb_fdf (const gsl_vector * x, void *data, gsl_vector * f, gsl_matrix * J);
        
        double m, b, A, B, C;
        double m_Error, b_Error, A_Error, B_Error, C_Error;
        bool doneFitting;
        bool doneDrawing;
        
    };

	
}

#endif
