/*
 *  dataFileReader.h
 *  RotationTracker
 *
 *  Created by Paul Simonson on 10/3/07.
 *  Copyright 2007 __MyCompanyName__. All rights reserved.
 *
 */

//Version 0.1

#ifndef DATAFILEREADER_H
#define DATAFILEREADER_H

#include <vector> //using vectors...
std::vector< std::vector<double> > dataFileReader(const char *cpath);
void displayParsedFile(std::vector< std::vector<double> > parsedFile);

#endif
