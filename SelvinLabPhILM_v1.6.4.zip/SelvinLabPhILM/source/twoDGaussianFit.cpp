/*
 *  twoDGaussianFit.cpp
 *  ReverseSTORM_SL
 *
 *  Created by Paul Simonson on 12/21/09.
 *  Copyright 2009 University of Illinois at Urbana-Champaign. All rights reserved.
 *
 */

#include "twoDGaussianFit.h"

#include <cmath>
#include <iostream>


TwoDGaussianFittingParametersAndErrors::TwoDGaussianFittingParametersAndErrors()
{
	;//place holder...
}

TwoDGaussianFittingParametersAndErrors::TwoDGaussianFittingParametersAndErrors(double ph,
									   double x0,
									   double y0,
									   double xw,
									   double yw,
									   double bg,
									   double ta,
									   double phe,
									   double x0Error,
									   double y0Error,
									   double xwe,
									   double ywe,
									   double bge,
									   double tae)
{
	peakHeight  = ph;
	xCenterValue  = x0;
	yCenterValue  = y0;
	xWidth  = xw;
	yWidth  = yw;
	background  = bg;
	tiltAngle  = ta;
	peakHeightError  = phe;
	xCenterValueError  = x0Error;
	yCenterValueError  = y0Error;
	xWidthError  = xwe;
	yWidthError  = ywe;
	backgroundError  = bge;
	tiltAngleError  = tae;
}




std::string TwoDGaussianFittingParametersAndErrors::returnFitVectorHeader(void)
{
	std::string sequenceOfFitParameters = "I0	x0	y0	s_x	s_y	theta	B	I0E	x0E	y0E	s_xE	s_yE	thetaE	BE";
	return sequenceOfFitParameters;
}


double TwoDGaussianFittingParametersAndErrors::averageOfXWidthAndYWidth(void)
{
	return 0.5L * (xWidth + yWidth);
}

double TwoDGaussianFittingParametersAndErrors::estimateTotalCountsUsingFittingParameters()
{
	double A =   peakHeight;//in terms of counts.
	double sx =   xWidth;//in terms of pixels.
	double sy =   yWidth;
	double N =  A * 2.0L * (double)M_PI * sy * sx;//in terms of photons.
	//std::cout << "Total number of counts: " << N << ", A = " << A << "\n";
	return N;
}


double TwoDGaussianFittingParametersAndErrors::estimateTotalPhotonsUsingFittingParameters(double countsToPhotonsConversionFactor)
{		
	return estimateTotalCountsUsingFittingParameters() * countsToPhotonsConversionFactor;
}


double TwoDGaussianFittingParametersAndErrors::STORMEllipticity(void)
{
	return fabs(2.0L*(xWidth - yWidth)/(xWidth + yWidth));
}

double TwoDGaussianFittingParametersAndErrors::ellipticity(void)
{
	if(xWidth > yWidth)
		return xWidth/yWidth;
	if (yWidth > xWidth) {
		return yWidth/xWidth;
	}
	if(xWidth == yWidth)
		return 1;
	return -1;//if it made it this far, there was an error...
}

std::vector<double> TwoDGaussianFittingParametersAndErrors::returnFitAsVector(void)
{
	std::vector<double> vectorOfFit;
	vectorOfFit.push_back(peakHeight);
	vectorOfFit.push_back(xCenterValue);
	vectorOfFit.push_back(yCenterValue);
	vectorOfFit.push_back(xWidth);
	vectorOfFit.push_back(yWidth);
	vectorOfFit.push_back(tiltAngle);
	vectorOfFit.push_back(background);
	
	vectorOfFit.push_back(peakHeightError);
	vectorOfFit.push_back(xCenterValueError);
	vectorOfFit.push_back(yCenterValueError);
	vectorOfFit.push_back(xWidthError);
	vectorOfFit.push_back(yWidthError);
	vectorOfFit.push_back(tiltAngleError);
	vectorOfFit.push_back(backgroundError);
	
	return vectorOfFit;
}



int TwoDGaussianFittingParametersAndErrors::printFit(void)
{
	std::cout	<< "peakHeight	x0	y0	xWidth	yWidth	background\n"
	<<  peakHeight << "	"
	<<  xCenterValue << "	"
	<<  yCenterValue << "	"
	<<  xWidth << "	"
	<<  yWidth << "	"
	<<  tiltAngle << "	"
	<<  background << "\n";
	
	std::cout << "Estimated fit errors:\n"
	<<  peakHeightError << "	"
	<<  xCenterValueError << "	"
	<<  yCenterValueError << "	"
	<<  xWidthError << "	"
	<<  yWidthError << "	"
	<<  tiltAngleError << "	"
	<<  backgroundError << "\n";
	
	return 0;
}


//I am fitting the equation on page 4 of the supplemental information to 
//	Authors:	Rust,Michael J.; Bates,Mark; Zhuang,Xiaowei
//	Title:	Sub-diffraction-limit imaging by stochastic optical reconstruction microscopy (STORM)
//	Periodical, Abbrev:	Nat Meth
//	Pub Year:	2006
double TwoDGaussianFittingParametersAndErrors::returnFitValue(double x, double y)
{
	double xP = (x - xCenterValue) * cos(tiltAngle) - (y - yCenterValue) * sin(tiltAngle);
	double yP = (x - xCenterValue) * sin(tiltAngle) + (y - yCenterValue) * cos(tiltAngle);
	return peakHeight * exp(-0.5L * (pow(xP/xWidth, 2) + pow(yP/yWidth, 2))) + background;	
}

double TwoDGaussianFittingParametersAndErrors::returnFitValueOfLocalization(double x, double y)
{
	double xP = (x - xCenterValue) * cos(tiltAngle) - (y - yCenterValue) * sin(tiltAngle);
	double yP = (x - xCenterValue) * sin(tiltAngle) + (y - yCenterValue) * cos(tiltAngle);
	return peakHeight * exp(-0.5L * (pow(xP/xCenterValueError, 2) + pow(yP/yCenterValueError, 2))) + background;	
}
