//
//  PhILMExtras.h
//  SelvinLabPhILM_XCode
//
//  Created by Paul Simonson on 3/28/11.
//  Copyright 2011 University of Illinois at Urbana-Champaign. All rights reserved.
//


#ifndef PhILMExtras_H
#define PhILMExtras_H

#include <iostream>
#include <fstream>

#include "FreeImage.h"
#include "tnt.h"
#include "Magick++.h"


#include "ScienceFile.h"
#include "twoDGaussianFit.h"
#include "ExponentialDecayFit.h"
#include "drawingSuperResolutionImages.h"
#include "PhILMPreferences.h"


namespace PhILM_namespace 
{
    class  PhotobleachingLifetimeEstimate 
    {
    public:
        PhotobleachingLifetimeEstimate()
        {
            finishedCalculatingLifetime = 0;
            verboseOutput = 0;
            frameAcquisitionTime = 1;
        }
        
        double frameAcquisitionTime;
        double fluorescencePerFluorophorePerFrameInCounts;
        double estimatedTotalCountsCollectedDuringLifetime;
        
        std::vector<double> timeSteps;
        std::vector<double> averageIntensities;
        std::vector<double> sigmas;		
        std::vector<double> fitValues;
        
        void printPhotobleachingDecayFit(void)
        {
            std::cout << photobleachingDecayFit.A << "	" << photobleachingDecayFit.B << "	" << photobleachingDecayFit.C << "	" 
            << photobleachingDecayFit.A_error << "	" << photobleachingDecayFit.B_error << "	" << photobleachingDecayFit.C_error << "\n";
        }
        
        void calculatePhotobleachingLifetime(void);
        
        double returnPhotobleachingLifetimeInCounts(void)
        {
            if (!finishedCalculatingLifetime) {
                calculatePhotobleachingLifetime();
            }
            return estimatedTotalCountsCollectedDuringLifetime;
        }
        
        void writeXYFitData(const char *fileName)
        {
            if (timeSteps.size() != averageIntensities.size()) {
                populateTimeSteps();
            }
            if (!finishedCalculatingLifetime) {
                calculatePhotobleachingLifetime();
            }
            if (fitValues.size() != averageIntensities.size()) {
                populateFitValues();
            }
            
            std::ofstream outputFile;
            outputFile.open(fileName);
            outputFile << "%x	y	fit\n";
            
            int numDataPoints = averageIntensities.size();
            int i;
            for (i = 0; i < numDataPoints; i++)
            {
                outputFile << timeSteps.at(i) << "	" << averageIntensities.at(i) << "	" << fitValues.at(i) << "\n";
            }
            outputFile.close();
        }
        
        void setVerboseOutput(bool setting)
        {
            verboseOutput = setting;
        }
        
    private:
        ExponentialDecayFit photobleachingDecayFit;
        bool finishedCalculatingLifetime;
        bool verboseOutput;
        
        void populateTimeSteps(void)
        {
            timeSteps.clear();
            int numDataPoints = averageIntensities.size();
            int i;
            for (i = 0; i < numDataPoints; i++)
            {
                timeSteps.push_back((double)i * frameAcquisitionTime);
            }
        }
        
        void populateFitValues(void)
        {
            fitValues.clear();
            if (timeSteps.size() != averageIntensities.size()) {
                populateTimeSteps();
            }
            if (!finishedCalculatingLifetime) {
                calculatePhotobleachingLifetime();
            }
            
            int numDataPoints = averageIntensities.size();
            int i;
            for (i = 0; i < numDataPoints; i++)
            {
                fitValues.push_back(photobleachingDecayFit.A * exp(-timeSteps.at(i)/photobleachingDecayFit.B) + photobleachingDecayFit.C);
            }
        }
    };
    
    
    //Extras...
    double estimateFluorescencePerFluorophore(void);
    double estimatePortionOfFluorophoresLocalized(int numberOfSpotsLocalized, const char *tiffFileName);
    int plotOnsAndOffs(const char* inputTIFFFileName);
}


#endif
