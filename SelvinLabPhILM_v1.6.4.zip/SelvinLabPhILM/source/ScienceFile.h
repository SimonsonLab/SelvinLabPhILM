/*
 *  ScienceFile.h
 *  PositionAndFluorescenceTracker
 *
 *  Created by Paul Simonson on 2/9/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

//Note:  Things only get added here as I need them.

#ifndef ScienceFile_HEADER
#define ScienceFile_HEADER

#include <vector> //using vectors...
#include <string>

class ScienceFile {
public:
	//constructor
	ScienceFile();
	ScienceFile(const char * cpath);
	ScienceFile(std::vector< std::vector<double> > newData);

	//data
	std::vector< std::vector<double> > data;
	int hasHeader;
	//char header[1000];
	std::string header;
	
	
	//load data
	int loadFromFile(const char * cpath);
	
	//Finding out about the data
	int numRows(void);
	int numColumns(void);
	double at(unsigned x, unsigned y);
	double returnElement(unsigned x, unsigned y);
	std::vector<double> returnRow(int row);
	std::vector<int> returnRowAsIntegers(int row);
	std::vector<double> returnColumn(int column);
	std::vector< std::vector<double> > returnData(void);
	
	//outputting to devices
	void display(void);
	void displayRow(int row);
	int writeToFile(const char * cpath);
	int writeToFile(const char * cpath, const char * header);
	
	//altering contents
	int setElement(unsigned x, unsigned y, double value);
	int addRow(std::vector<double>);
	int addColumn(std::vector<double>);
	int addColumn(std::vector<int>);
	int addColumn(void);
	void clear(void);

	int setHeader(const char *newHeader);
	
	//Extras
	static void displayVector(std::vector<double> inputVector);
	static void displayVector(std::vector<int> inputVector);
	static double findMin(std::vector<double> inputVector);
	static double findMax(std::vector<double> inputVector);

};

#endif
