/*
 *  fitTo2DGaussian.cpp
 *  TwoPhotonMicroscopy
 *
 *  Created by Paul Simonson on 5/30/08.
 *  Copyright 2008 __MyCompanyName__. All rights reserved.
 *
 */

#include "fitTo2DGaussianUsingGSL.h"

#include <iostream>

#include "ScienceFile.h"
#include "return2DArrayFromMultiBitmap.h"
#include "returnDataForGaussianFitting.h"
//#include "tiffFrameOperations.h"
#include "writeTIFFFileUsingMagick.h"

#include <stdlib.h>
#include <stdio.h>
//#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_multifit_nlin.h>

#include <vector>

namespace Fitting2DGaussianUsingGSL {
	
	//Globals to make the programming easier.
	std::vector<double> xValues;
	std::vector<double> yValues;
	
	struct data {
		size_t n;
		double * y;
		double * sigma;
	};
	
	int
	expb_f (const gsl_vector * x, void *data, 
			gsl_vector * f)
	{
		size_t n = ((struct data *)data)->n;
		double *y = ((struct data *)data)->y;
		double *sigma = ((struct data *) data)->sigma;
		
		double A = gsl_vector_get (x, 0);
		double x0 = gsl_vector_get (x, 1);
		double s_x = gsl_vector_get (x, 2);
		double y0 = gsl_vector_get (x, 3);
		double s_y = gsl_vector_get (x, 4);
		double B = gsl_vector_get (x, 5);
		
		size_t i;
		
		for (i = 0; i < n; i++)
		{
			double Yi = A * exp(-0.5L * pow((xValues[i] - x0)/s_x, 2)) * exp(-0.5L * pow((yValues[i] - y0)/s_y, 2)) + B;
			gsl_vector_set (f, i, (Yi - y[i]) / sigma[i]);
		}
		
		return GSL_SUCCESS;
	}
	
	int
	expb_df (const gsl_vector * x, void *data, 
			 gsl_matrix * J)
	{
		size_t n = ((struct data *)data)->n;
		double *sigma = ((struct data *) data)->sigma;
		
		double A = gsl_vector_get (x, 0);
		double x0 = gsl_vector_get (x, 1);
		double s_x = gsl_vector_get (x, 2);
		double y0 = gsl_vector_get (x, 3);
		double s_y = gsl_vector_get (x, 4);
		//double B = gsl_vector_get (x, 5);
		
		size_t i;
		
		for (i = 0; i < n; i++)
		{
			/* Jacobian matrix J(i,j) = dfi / dxj, */
			/* where fi = (Yi - yi)/sigma[i],      */
			/*       Yi = A * exp(-lambda * i) + b  */
			/* and the xj are the parameters (A,lambda,b) */
			double s = sigma[i];
			double exponentialPart = exp(-0.5L * pow((xValues[i] - x0)/s_x, 2)) * exp(-0.5L * pow((yValues[i] - y0)/s_y, 2));
			gsl_matrix_set (J, i, 0, exponentialPart/s); 
			gsl_matrix_set (J, i, 1, (A * exponentialPart * (xValues[i] - x0) / s_x)/s);
			gsl_matrix_set (J, i, 2, (0.5L * A * exponentialPart * pow((xValues[i] - x0)/s_x, 2))/s );
			gsl_matrix_set (J, i, 3, (A * exponentialPart * (yValues[i] - y0) / s_y)/s); 
			gsl_matrix_set (J, i, 4, (0.5L * A * exponentialPart * pow((yValues[i] - y0)/s_y, 2))/s );
			gsl_matrix_set (J, i, 5, 1/s);
		}
		return GSL_SUCCESS;
	}
	
	int
	expb_fdf (const gsl_vector * x, void *data,
			  gsl_vector * f, gsl_matrix * J)
	{
		expb_f (x, data, f);
		expb_df (x, data, J);
		
		return GSL_SUCCESS;
	}
	
	
	
	void print_state (size_t iter, gsl_multifit_fdfsolver * s);
	
	TwoDGaussianFittingParametersAndErrors fitTo2DGaussianUsingGSL(std::vector<double> xPositions, std::vector<double> yPositions, std::vector<double> pixelIntensities)
	{
		int N = xPositions.size();
		std::vector<double> sigmas(N, 1.0L);
		
		return weightedFitTo2DGaussianUsingGSL(xPositions, yPositions, pixelIntensities, sigmas);
	}
	
	void
	print_state (unsigned int iter, gsl_multifit_fdfsolver * s)
	{
		printf ("iter: %3u x = % 15.8f % 15.8f % 15.8f "
				"|f(x)| = %g\n",
				iter,
				gsl_vector_get (s->x, 0), 
				gsl_vector_get (s->x, 1),
				gsl_vector_get (s->x, 2), 
				gsl_blas_dnrm2 (s->f));
	}
	
	
	double 
	returnSpotWidth(std::vector<double> xPositions, std::vector<double> yPositions, std::vector<double> pixelIntensities)
	{
		TwoDGaussianFittingParametersAndErrors fitValues = fitTo2DGaussianUsingGSL(xPositions, yPositions, pixelIntensities);
		double finalResult = 0.5L * (fitValues.xWidth + fitValues.yWidth);
		
		std::cout << "Averaged spot width: " << finalResult << "\n";
		return finalResult;
	}
	
	
	/////////////////////////////////////////////////////////////////

	TwoDGaussianFittingParametersAndErrors 
	weightedFitTo2DGaussian(std::vector<double> xPositions, 
							std::vector<double> yPositions, 
							std::vector<double> pixelIntensities, 
							double backgroundNoise)
	{
		TwoDGaussianFittingParametersAndErrors initialFit = fitTo2DGaussianUsingGSL(xPositions, yPositions, pixelIntensities);
		return weightedFitTo2DGaussian(xPositions, 
									   yPositions, 
									   pixelIntensities, 
									   initialFit.background, 
									   backgroundNoise);
	}
	
	
	//Use this when camera baseline and background noise are known.
	TwoDGaussianFittingParametersAndErrors 
	weightedFitTo2DGaussian(std::vector<double> xPositions, 
						   std::vector<double> yPositions, 
						   std::vector<double> pixelIntensities, 
						   double cameraBaseline, 
						   double backgroundNoise)
	{
		int N = xPositions.size();
		std::vector<double> sigmas(N);
		register int i;
		for(i = 0; i < N; i++)
		{
			sigmas[i] = backgroundNoise + sqrt(fabs(pixelIntensities[i] - cameraBaseline));
			if(sigmas[i] < 1.0L)
				sigmas[i] = 1.0L;
			//std::cout << "sqrt(" << pixelIntensities[i] << " - " << cameraBaseline << ") = " << sigmas[i] << "\n";
		}
		return weightedFitTo2DGaussianUsingGSL(xPositions, yPositions, pixelIntensities, sigmas);
	}


	
	/////////////////////////////////////////////////////////////////


	TwoDGaussianFittingParametersAndErrors 
	weightedFitTo2DGaussian(std::vector<double> xPositions, 
							std::vector<double> yPositions, 
							std::vector<double> pixelIntensities, 
							std::vector<double> pixelIntensitiesToSubtract, 
							double darkCountsNoise,
							int numFramesToBeAveragedBeforePhotobleaching,
							int numFramesToBeAveragedAfterPhotobleaching)
	{
		std::vector<double> newPixelIntensities;
		
		int i;
		int N = pixelIntensities.size();
		for(i = 0; i< N; i++)
			newPixelIntensities.push_back(pixelIntensities[i] - pixelIntensitiesToSubtract[i]);
		
		//figure out what the camera baseline is first.
		TwoDGaussianFittingParametersAndErrors initialFit = fitTo2DGaussianUsingGSL(xPositions, yPositions, newPixelIntensities);
		
		//Now do the weighted fitting knowing the camera baseline (so you can calculate the noise uncertainty for each pixel).
		return weightedFitTo2DGaussian(xPositions, 
									   yPositions, 
									   pixelIntensities, 
									   pixelIntensitiesToSubtract,
									   initialFit.background, 
									   darkCountsNoise,
									   numFramesToBeAveragedBeforePhotobleaching,
									   numFramesToBeAveragedAfterPhotobleaching);
	}
	
	TwoDGaussianFittingParametersAndErrors weightedFitTo2DGaussian(std::vector<double> xPositions, 
																		  std::vector<double> yPositions, 
																		  std::vector<double> pixelIntensities, 
																		  std::vector<double> pixelIntensitiesToSubtract, 
																		  double cameraBaseline, 
																		  double darkCountsNoise,
																		  int numFramesToBeAveragedBeforePhotobleaching,
																		  int numFramesToBeAveragedAfterPhotobleaching)
	{
		int N = pixelIntensities.size();
		std::vector<double> sigmas(N);
		std::vector<double> newPixelIntensities(N);

		register int i;
		for(i = 0; i < N; i++)
		{
		  sigmas[i] = sqrt(pow(darkCountsNoise, 2)/numFramesToBeAveragedAfterPhotobleaching
							  + pow(sqrt(pixelIntensitiesToSubtract[i] - cameraBaseline),2)/numFramesToBeAveragedAfterPhotobleaching 
							  + pow(darkCountsNoise, 2)/numFramesToBeAveragedBeforePhotobleaching
							  + pow(sqrt(pixelIntensities[i] - cameraBaseline), 2)/numFramesToBeAveragedBeforePhotobleaching);
										  
		  newPixelIntensities[i] = pixelIntensities[i] - pixelIntensitiesToSubtract[i];
		}
		
		return weightedFitTo2DGaussianUsingGSL(xPositions, yPositions, newPixelIntensities, sigmas);
	}
	
	
	TwoDGaussianFittingParametersAndErrors 
	weightedFitTo2DGaussianUsingGSL(std::vector<double> xPositions, 
									std::vector<double> yPositions, 
									std::vector<double> pixelIntensities, 
									std::vector<double> sigmas,
									int verboseFitting)
	{
		const double fitTolerance = 1e-10;
		const unsigned int maxNumberOfFitIterations = 1000;
		
		
		//Set up these global variables.
		xValues.clear();
		yValues.clear();
		xValues = xPositions;
		yValues = yPositions;
		
		const gsl_multifit_fdfsolver_type *T;
		gsl_multifit_fdfsolver *s;
		int status;
		unsigned int i, iter = 0;
		const size_t n = yPositions.size();
		const size_t p = 6;
		
		//Determine initial fitting parameters
		double maxValue = pixelIntensities.at(0);
		double minValue = pixelIntensities.at(0);
		double x0, y0;
		for(i = 0; i < n; i++)
		{
			if(pixelIntensities[i] < minValue)
				minValue = pixelIntensities[i];
			if(pixelIntensities[i] > maxValue)
			{
				maxValue = pixelIntensities[i];
				x0 = xValues[i];
				y0 = yValues[i];
			}
		}
		double A = maxValue - minValue;
		double B = minValue;
		double s_x = 1.5L;
		double s_y = 1.5L;
		
		gsl_matrix *covar = gsl_matrix_alloc (p, p);
		double y[n], sigma[n];
		struct data d = { n, y, sigma};
		gsl_multifit_function_fdf f;		
		double x_init[p] = {A, x0, s_x, y0, s_y, B };
		
		gsl_vector_view x = gsl_vector_view_array (x_init, p);
		
		f.f = &expb_f;
		f.df = &expb_df;
		f.fdf = &expb_fdf;
		f.n = n;
		f.p = p;
		f.params = &d;
		
		// These are the data to be fitted
		for (i = 0; i < n; i++)
		{
			y[i] = pixelIntensities[i];
			sigma[i] = sigmas[i];
		};
		
		T = gsl_multifit_fdfsolver_lmsder;
		s = gsl_multifit_fdfsolver_alloc (T, n, p);
		gsl_multifit_fdfsolver_set (s, &f, &x.vector);
		
		if(verboseFitting)
			print_state (iter, s);
		
		do
		{
			iter++;
			status = gsl_multifit_fdfsolver_iterate (s);
			
			if(verboseFitting)
			{
				printf ("status = %s\n", gsl_strerror (status));
				print_state (iter, s);
			}
			
			if (status)
				break;
			
			status = gsl_multifit_test_delta (s->dx, s->x,
											  fitTolerance, fitTolerance);
		}
		while (status == GSL_CONTINUE && iter < maxNumberOfFitIterations);
		
		if(iter == maxNumberOfFitIterations)
			if(verboseFitting)
				printf("Could not fit within %d iterations.\n", maxNumberOfFitIterations);
		
		gsl_multifit_covar (s->J, 0.0, covar);
		
#define FIT(i) gsl_vector_get(s->x, i)
#define ERR(i) sqrt(gsl_matrix_get(covar,i,i))
		
		TwoDGaussianFittingParametersAndErrors finalResult;
		
		{
			double chi = gsl_blas_dnrm2(s->f);
			double dof = n - p;
			double c = GSL_MAX_DBL(1, chi / sqrt(dof)); 
			
			if(verboseFitting)
			{
				printf("chisq/dof = %g\n",  pow(chi, 2.0) / dof);
				printf ("A      = %.5f +/- %.5f\n", FIT(0), c*ERR(0));
				printf ("x0 = %.5f +/- %.5f\n", FIT(1), c*ERR(1));
				printf ("s_x      = %.5f +/- %.5f\n", FIT(2), c*ERR(2));
				printf ("y0      = %.5f +/- %.5f\n", FIT(3), c*ERR(3));
				printf ("s_y = %.5f +/- %.5f\n", FIT(4), c*ERR(4));
				printf ("B      = %.5f +/- %.5f\n", FIT(5), c*ERR(5));
			}

			finalResult.peakHeight =  FIT(0);
			finalResult.xCenterValue =  FIT(1);
			finalResult.xWidth =  FIT(2);
			finalResult.yCenterValue =  FIT(3);
			finalResult.yWidth =  FIT(4);
			finalResult.background =  FIT(5);
			
			finalResult.peakHeightError = c*ERR(0);
			finalResult.xCenterValueError = c*ERR(1);
			finalResult.xWidthError = c*ERR(2);
			finalResult.yCenterValueError = c*ERR(3);
			finalResult.yWidthError = c*ERR(4);
			finalResult.backgroundError = c*ERR(5);
			
			finalResult.tiltAngle =  0;  //There is no tilt angle.
			finalResult.tiltAngleError = 0;  //There is no error.
			finalResult.numFitIterations = iter;
			finalResult.fitTolerance = fitTolerance;
		}
		if(verboseFitting)
			printf ("status = %s\n", gsl_strerror (status));
		gsl_multifit_fdfsolver_free (s);
		gsl_matrix_free (covar);
		return finalResult;
	}
	
	
	
	
	TwoDGaussianFittingParametersAndErrors
	subtractRectangularImageAndFitTo2DGaussian(char *inputFileName, int frameNumberToAnalyze, int frameNumberToSubtract, double backgroundNoise)
	{
		const int xColumn = 0;
		const int yColumn = 1;
		const int intensityColumn = 2;
		
		ScienceFile spotInformation = returnDataForGaussianFitting(Return2DArray::return2DIntArrayFromMultiBitmap(inputFileName, frameNumberToAnalyze));
		ScienceFile imageToSubtract = returnDataForGaussianFitting(Return2DArray::return2DIntArrayFromMultiBitmap(inputFileName, frameNumberToSubtract));
		
		return weightedFitTo2DGaussian(spotInformation.returnColumn(xColumn),
									   spotInformation.returnColumn(yColumn),
									   spotInformation.returnColumn(intensityColumn),
									   imageToSubtract.returnColumn(intensityColumn),
									   backgroundNoise);
	}
	
	
	
	
	TwoDGaussianFittingParametersAndErrors 
	subtractRoundImageAndFitTo2DGaussian(char *inputFileName, 
										 int frameNumberToAnalyze, 
										 int frameNumberToSubtract, 
										 double backgroundNoise, 
										 double x, 
										 double y, 
										 double spotRadius,
										 int numFramesToBeAveragedBeforePhotobleaching,
										 int numFramesToBeAveragedAfterPhotobleaching)
	
	{
		const int xColumn = 0;
		const int yColumn = 1;
		const int intensityColumn = 2;
		
		ScienceFile spotInformation = returnDataForGaussianFitting(Return2DArray::return2DIntArrayFromMultiBitmap(inputFileName, frameNumberToAnalyze), x, y, spotRadius);
		ScienceFile imageToSubtract = returnDataForGaussianFitting(Return2DArray::return2DIntArrayFromMultiBitmap(inputFileName, frameNumberToSubtract), x, y, spotRadius);
		
		return weightedFitTo2DGaussian(spotInformation.returnColumn(xColumn),
									   spotInformation.returnColumn(yColumn),
									   spotInformation.returnColumn(intensityColumn),
									   imageToSubtract.returnColumn(intensityColumn),
									   backgroundNoise,
									   numFramesToBeAveragedBeforePhotobleaching,
									   numFramesToBeAveragedAfterPhotobleaching);
	}
	
	
	//Fix me!!!
	TwoDGaussianFittingParametersAndErrors 
	subtractRoundImageAndFitTo2DGaussian(TNT::Array2D<int> beforePhotobleachingArray,
										 TNT::Array2D<int> afterPhotobleachingArray,
										 double backgroundNoise, 
										 double x, 
										 double y, 
										 double spotRadius,
										 int numFramesToBeAveragedBeforePhotobleaching,
										 int numFramesToBeAveragedAfterPhotobleaching)
	{
		const int xColumn = 0;
		const int yColumn = 1;
		const int intensityColumn = 2;
		
		ScienceFile spotInformation = returnDataForGaussianFitting(beforePhotobleachingArray, x, y, spotRadius);
		ScienceFile imageToSubtract = returnDataForGaussianFitting(afterPhotobleachingArray, x, y, spotRadius);
		
		return weightedFitTo2DGaussian(spotInformation.returnColumn(xColumn),
									   spotInformation.returnColumn(yColumn),
									   spotInformation.returnColumn(intensityColumn),
									   imageToSubtract.returnColumn(intensityColumn),
									   backgroundNoise,
									   numFramesToBeAveragedBeforePhotobleaching,
									   numFramesToBeAveragedAfterPhotobleaching);
	}
	
	
	double gaussian2D(double x, double y, double A, double x0, double s_x, double y0, double s_y, double background)
	{
		return A*exp(-0.5*pow((x-x0)/s_x,2))*exp(-0.5*pow((y-y0)/s_y,2)) + background;
	}
	
	TNT::Array2D<int> return2DGaussianImage(TwoDGaussianFittingParametersAndErrors theFit, int dim1, int dim2)
	{
		TNT::Array2D<int> imageArray(dim1, dim2);
		
		int width = dim1;
		int height = dim2;
		
		register int i, j;
		
		for(i = 0; i < width; i++)
			for(j = 0; j < height; j++)
			{
				imageArray[i][j] = (int)gaussian2D(i, j, theFit.peakHeight, theFit.xCenterValue, theFit.xWidth, theFit.yCenterValue, theFit.yWidth, theFit.background);
			}
		
		//writeTIFFFileUsingMagick("gaussianImageTest1.tif", imageArray);

		return imageArray;
	}

	TwoDGaussianFittingParametersAndErrors 
	subtractRoundImageAndFitTo2DGaussian(TNT::Array2D<int> beforePhotobleachingArray,
										 TwoDGaussianFittingParametersAndErrors fitOfLastFluorophore,
										 double backgroundNoise, 
										 double x, 
										 double y, 
										 double spotRadius,
										 int numFramesToBeAveragedBeforePhotobleaching,
										 int numFramesToBeAveragedAfterPhotobleaching)
	{
		TNT::Array2D<int> afterPhotobleachingArray = return2DGaussianImage(fitOfLastFluorophore, beforePhotobleachingArray.dim1(), beforePhotobleachingArray.dim2());
		writeTIFFFileUsingMagick("gaussianFit.tif", afterPhotobleachingArray);
		
		return subtractRoundImageAndFitTo2DGaussian(beforePhotobleachingArray,
													afterPhotobleachingArray,
													backgroundNoise, 
													x, 
													y, 
													spotRadius,
													numFramesToBeAveragedBeforePhotobleaching,
													numFramesToBeAveragedAfterPhotobleaching);
	}
	
	
	
	
	double estimateTotalCountsUsingFittingParameters(TwoDGaussianFittingParametersAndErrors fittingParameters)
	{
		double A = fittingParameters.peakHeight;//in terms of counts.
		double sx = fittingParameters.xWidth;//in terms of pixels.
		double sy = fittingParameters.yWidth;
		double N =  A * 2.0L * (double)M_PI * sy * sx;//in terms of photons.
		//std::cout << "Total number of counts: " << N << ", A = " << A << "\n";
		return N;
	}
	
	
	double estimateTotalPhotonsUsingFittingParameters(TwoDGaussianFittingParametersAndErrors fittingParameters, double countsToPhotonsConversionFactor)
	{		
		return estimateTotalCountsUsingFittingParameters(fittingParameters) * countsToPhotonsConversionFactor;
	}
	

	
	
	
	TwoDGaussianFittingParametersAndErrors 
	fitIndicatedSpotTo2DGaussianTNT(TNT::Array2D<int> imageArray, 
								 double backgroundNoise, 
								 double x, 
								 double y, 
								 double spotRadius)
	
	{
		const int xColumn = 0;
		const int yColumn = 1;
		const int intensityColumn = 2;
		
		ScienceFile spotInformation = returnDataForGaussianFitting(imageArray, x, y, spotRadius);
		
		return weightedFitTo2DGaussian(spotInformation.returnColumn(xColumn),
									   spotInformation.returnColumn(yColumn),
									   spotInformation.returnColumn(intensityColumn),
									   backgroundNoise);
	}
	
	
	
	
	
	TwoDGaussianFittingParametersAndErrors 
	fitIndicatedSpotTo2DGaussian(char *inputFileName, 
								 int frameNumberToAnalyze, 
								 double backgroundNoise, 
								 double x, 
								 double y, 
								 double spotRadius)
	
	{
		return fitIndicatedSpotTo2DGaussianTNT(Return2DArray::return2DIntArrayFromMultiBitmap(inputFileName, frameNumberToAnalyze), backgroundNoise, x, y, spotRadius);
	}
	
	


	
	
	TwoDGaussianFittingParametersAndErrors 
	fitIndicatedSpotTo2DGaussian(FIMULTIBITMAP *multibitmap, 
								 int frameNumberToAnalyze, 
								 double backgroundNoise, 
								 double x, 
								 double y, 
								 double spotRadius)
	{
		return fitIndicatedSpotTo2DGaussianTNT(Return2DArray::return2DIntArrayFromMultiBitmap(multibitmap, frameNumberToAnalyze), backgroundNoise, x, y, spotRadius);
	}

	
}



