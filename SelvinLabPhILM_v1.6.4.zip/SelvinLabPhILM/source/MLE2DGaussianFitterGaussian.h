//
//  MLE2DGaussianFitterGaussian.h
//  SelvinLabPhILM_XCode
//
//  Created by Paul Simonson on 8/4/11.
//  Copyright 2011 University of Illinois at Urbana-Champaign. All rights reserved.
//



#ifndef MLE2DGaussianFitterGaussian_H
#define MLE2DGaussianFitterGaussian_H

#include <iostream>
#include <cmath>
#include <vector>
#include "tnt.h"


namespace MatrixInversionNamespace2 {
    //Start of code by http://chi3x10.wordpress.com/2008/05/28/calculate-matrix-inversion-in-c/
    //Modified by Paul D. Simonson on June 27, 2011, University of Illinois at Urbana-Champaign.
    
    int GetMinor(double **src, double **dest, int row, int col, int order);
    double CalcDeterminant( double **mat, int order);
    
    // matrix inversioon
    // the result is put in Y
    void MatrixInversion(double **A, int order, double **Y);
    
    //End of code by http://chi3x10.wordpress.com/2008/05/28/calculate-matrix-inversion-in-c/
    
}


class MLE2DGaussianFitter_Gaussian
{
public:
    
    std::vector<double> xValues, yValues, expectationValues, wValues;     
    //std::vector<double> zValues;
    std::vector<double> varianceValues;
    int numIterations;
    int maxIterations;
    double fitTolerance;
    double maxStepCriterion;
    
    //std::vector<double> expectedBackgroundValues;     
    
    
    void setDefaultValues(void)
    {
        numIterations = 0;
        maxIterations = 100;
        fitTolerance = 0.001;
        maxStepCriterion = 0.999;
    }
    
    MLE2DGaussianFitter_Gaussian()
    {
        setDefaultValues();
    }
    
    
    double returnDeltaX(double x, std::vector<double> theta)
    {
        return -erf((-1.0-x+theta[1])
                    /(sqrt(2.0)*theta[3]))
        +erf((-x+theta[1])/(sqrt(2.0)*theta[3]));
    }
    
    double returnDeltaY(double y, std::vector<double> theta)
    {
        return -erf((-1.0-y+theta[2])/(sqrt(2.0)*theta[3]))+erf((-y+theta[2])/(sqrt(2.0)*theta[3]));
    }
    
    double ppsf(unsigned int n, std::vector<double> theta)
    {
        return theta[0]*0.5*M_PI*theta[3]*theta[3]*returnDeltaX(xValues[n], theta)*returnDeltaY(yValues[n], theta);

        /*
        if (zValues[n]) 
        {
            return zValues[n]*theta[0]*0.5*M_PI*theta[3]*theta[3]*returnDeltaX(xValues[n], theta)*returnDeltaY(yValues[n], theta);
        }
        else
        {
            return 0;
        }
         */
    }
    
    double background(unsigned int index)
    {
        return 0;
        /*
        if (expectedBackgroundValues.size()) {
            return expectedBackgroundValues[index];
        }
        else
        {
            std::cout << "Warning: no background specified.\n";
            return 0;
        }*/
    }
    
    double returnExpectationValue(unsigned int n, std::vector<double> theta)
    {
        return ppsf(n, theta) + background(n);
    }
    
    void generateExpectationValues(std::vector<double> theta)
    {
        expectationValues.resize(xValues.size());
        unsigned int i;
        for (i = 0; i < xValues.size(); i++) {
            expectationValues[i] = returnExpectationValue(i, theta);
        }
    }
    
    void printAll(void)
    {
        unsigned int i;
        for (i = 0; i < expectationValues.size(); i++) {
            std::cout 
            << xValues.at(i) << ", " 
            << yValues.at(i) << ", " 
            //<< zValues.at(i) << ", " 
            << expectationValues.at(i) << ", " 
            << wValues.at(i) << "\n";
        }
    }
    
    //Fitting stuff from here down.
    
    double dppsf_dA(double x, double y, double z, std::vector<double> theta)
    {
        if (z) 
        {
            return z*0.5*M_PI*theta[3]*theta[3]*returnDeltaX(x, theta)*returnDeltaY(y, theta);
        }
        else
        {
            return 0;
        } 
    }
    
    double dppsf_dx0(double x, double y, double z, std::vector<double> theta)
    {
        if (z) 
        {
            return  theta[0]
            *(exp(-0.5*pow((x-theta[1])/theta[3], 2))-exp(-0.5*pow((1+x-theta[1])/theta[3], 2)))
            *sqrt(M_PI*0.5)
            *theta[3]*z
            *returnDeltaY(y, theta);
        }
        else
        {
            return 0;
        } 
    }
    
    double dppsf_dy0(double x, double y, double z, std::vector<double> theta)
    {
        if (z) 
        {
            return  theta[0]
            *(exp(-0.5*pow((y-theta[2])/theta[3], 2))-exp(-0.5*pow((1+y-theta[2])/theta[3], 2)))
            *sqrt(M_PI*0.5)
            *theta[3]*z
            *returnDeltaX(x, theta);
        }
        else
        {
            return 0;
        } 
    }
    
    double dppsf_dsigma(double x, double y, double z, std::vector<double> theta)
    {
        double term1 = sqrt(2.0/M_PI);
        
        if (z) 
        {
            return  0.5*theta[0]*M_PI*z
            *
            (term1
             *(exp(-0.5*pow((y-theta[2])/theta[3], 2))*(y-theta[2])
               +exp(-0.5*pow((1+y-theta[2])/theta[3], 2))*(-1-y+theta[2])
               )
             *returnDeltaX(x, theta)
             +
             2*theta[3]*returnDeltaX(x, theta)*returnDeltaY(y, theta)
             +
             
             term1
             *(exp(-0.5*pow((x-theta[1])/theta[3], 2))
               *(x-theta[1])
               +exp(-0.5*pow((1+x-theta[1])/theta[3], 2))*(-1-x+theta[1]))
             *returnDeltaY(y, theta)
             );
        }
        else
        {
            return 0;
        } 
    }
    
    virtual TNT::Array2D<double> calculateFIM(std::vector<double> t)
    {        
        TNT::Array2D<double> temp(4, 4, 0.0);
        
        unsigned int n;
        for (n = 0; n < wValues.size(); n++) 
        {
            double oneOverError;
            if (varianceValues[n]) {
                oneOverError= 1.0/varianceValues[n];//This was changed from 1/g to 1/errorValue to work with Gaussian distributions.
            }
            else//things break down for variance = 0.
            {
                oneOverError= 1.0/0.001;//This was changed from 1/g to 1/errorValue to work with Gaussian distributions.
            }
            
            temp[0][0] += oneOverError * pow(dppsf_dA(xValues[n],yValues[n], 1.0,t), 2);
            temp[1][1] += oneOverError * pow(dppsf_dx0(xValues[n],yValues[n],1.0,t), 2);
            temp[2][2] += oneOverError * pow(dppsf_dy0(xValues[n],yValues[n],1.0,t), 2);
            temp[3][3] += oneOverError * pow(dppsf_dsigma(xValues[n],yValues[n],1.0,t), 2);
            temp[0][1] += oneOverError * dppsf_dA(xValues[n],yValues[n],1.0,t) * dppsf_dx0(xValues[n],yValues[n],1.0,t);
            temp[0][2] += oneOverError * dppsf_dA(xValues[n],yValues[n],1.0,t) * dppsf_dy0(xValues[n],yValues[n],1.0,t);
            temp[0][3] += oneOverError * dppsf_dA(xValues[n],yValues[n],1.0,t) * dppsf_dsigma(xValues[n],yValues[n],1.0,t);
            temp[1][2] += oneOverError * dppsf_dx0(xValues[n],yValues[n],1.0,t) * dppsf_dy0(xValues[n],yValues[n],1.0,t);
            temp[1][3] += oneOverError * dppsf_dx0(xValues[n],yValues[n],1.0,t) * dppsf_dsigma(xValues[n],yValues[n],1.0,t);
            temp[2][3] += oneOverError * dppsf_dy0(xValues[n],yValues[n],1.0,t) * dppsf_dsigma(xValues[n],yValues[n],1.0,t);
            
            /*//Using z values:
            temp[0][0] += oneOverError * pow(dppsf_dA(xValues[n],yValues[n],zValues[n],t), 2);
            temp[1][1] += oneOverError * pow(dppsf_dx0(xValues[n],yValues[n],zValues[n],t), 2);
            temp[2][2] += oneOverError * pow(dppsf_dy0(xValues[n],yValues[n],zValues[n],t), 2);
            temp[3][3] += oneOverError * pow(dppsf_dsigma(xValues[n],yValues[n],zValues[n],t), 2);
            temp[0][1] += oneOverError * dppsf_dA(xValues[n],yValues[n],zValues[n],t) * dppsf_dx0(xValues[n],yValues[n],zValues[n],t);
            temp[0][2] += oneOverError * dppsf_dA(xValues[n],yValues[n],zValues[n],t) * dppsf_dy0(xValues[n],yValues[n],zValues[n],t);
            temp[0][3] += oneOverError * dppsf_dA(xValues[n],yValues[n],zValues[n],t) * dppsf_dsigma(xValues[n],yValues[n],zValues[n],t);
            temp[1][2] += oneOverError * dppsf_dx0(xValues[n],yValues[n],zValues[n],t) * dppsf_dy0(xValues[n],yValues[n],zValues[n],t);
            temp[1][3] += oneOverError * dppsf_dx0(xValues[n],yValues[n],zValues[n],t) * dppsf_dsigma(xValues[n],yValues[n],zValues[n],t);
            temp[2][3] += oneOverError * dppsf_dy0(xValues[n],yValues[n],zValues[n],t) * dppsf_dsigma(xValues[n],yValues[n],zValues[n],t);
            */
            
        }
        temp[1][0] = temp[0][1];
        temp[2][0] = temp[0][2];
        temp[3][0] = temp[0][3];
        
        temp[2][1] = temp[1][2];
        temp[3][1] = temp[1][3];
        
        temp[3][2] = temp[2][3];
        
        return temp;
    }
    
    TNT::Array2D<double> calculateInverseFIM(std::vector<double> t)
    {
        TNT::Array2D<double> FIM_t = calculateFIM(t);
        //checkFisherMatrixForSingularity();
        int numParameters = FIM_t.dim1();
        TNT::Array2D<double> IFIM_t(numParameters, numParameters);
        MatrixInversionNamespace2::MatrixInversion(FIM_t, numParameters, IFIM_t);
        return IFIM_t;
    }
    
    std::vector<double> calculateCRLB(std::vector<double> t)
    {
        ///This should be generic for any CRLB.
        std::vector<double> crlb(t.size());
        
        TNT::Array2D<double> inverseFIM = calculateInverseFIM(t);
        int i;
        for (i = 0; i < inverseFIM.dim1(); i++) {
            crlb[i] = sqrt(inverseFIM[i][i]);
        }
        return crlb;
    }
    
    std::vector<double> printCRLB(std::vector<double> t)
    {
        std::vector<double> crlb = calculateCRLB(t);
        unsigned int i;
        for (i = 0; i < crlb.size(); i++) {
            std::cout << "CRLB[" << i << "] = " << crlb[i] << "\n";
        }
        return crlb;
    }
    
    virtual std::vector<double> calculateFisherScore(std::vector<double> t)
    {
        std::vector<double> s_t(t.size(), 0.0);
        
        unsigned int n;
        for (n = 0; n < wValues.size(); n++) {
            double g_n = returnExpectationValue(n, t);
            double term2;
            if (varianceValues[n]) {
                term2= (wValues[n] - g_n)/varianceValues[n];//Modified for Gaussian distribution by using provided errorValues instead of g in C^-1
            }
            else//things break down for variance = 0.
            {
                term2= (wValues[n] - g_n)/0.001;//Modified for Gaussian distribution by using provided errorValues instead of g in C^-1
            }
            /*
            s_t[0] += dppsf_dA(xValues[n], yValues[n], zValues[n], t) * term2;
            s_t[1] += dppsf_dx0(xValues[n], yValues[n], zValues[n], t) * term2;
            s_t[2] += dppsf_dy0(xValues[n], yValues[n], zValues[n], t) * term2;
            s_t[3] += dppsf_dsigma(xValues[n], yValues[n], zValues[n], t) * term2;
            */
            
            s_t[0] += dppsf_dA(xValues[n], yValues[n], 1.0, t) * term2;
            s_t[1] += dppsf_dx0(xValues[n], yValues[n], 1.0, t) * term2;
            s_t[2] += dppsf_dy0(xValues[n], yValues[n], 1.0, t) * term2;
            s_t[3] += dppsf_dsigma(xValues[n], yValues[n], 1.0, t) * term2;
        }
        return s_t;
    }
    
    void printS_t(std::vector<double> t)
    {
        std::vector<double> s_t = calculateFisherScore(t);
        unsigned int i;
        for (i = 0; i < s_t.size(); i++) {
            std::cout << "s_t[i] = " << s_t[i] << "\n";
        }
    }
    
    std::vector<double> calculateFisherScoreStep(std::vector<double> t)
    {
        TNT::Array2D<double> inverseFIM = calculateInverseFIM(t);
        std::vector<double> s_t = calculateFisherScore(t);
        
        std::vector<double> fisherScoreStep(4);
        
        int i;
        for (i = 0; i < 4; i++) {
            int j;
            for (j = 0; j < 4; j++) {
                fisherScoreStep[i] += inverseFIM[i][j] * s_t[j];
            }
        }
        
        return fisherScoreStep;
    }
    
    std::vector<double> printFisherScoreStep(std::vector<double> t)
    {
        std::vector<double> fss = calculateFisherScoreStep(t);
        unsigned int i;
        for (i = 0; i < fss.size(); i++) {
            std::cout << "fss[" << i << "] = " << fss[i] << "\n";
        }
        return fss;
    }
    
    
    std::vector<double> addVectors(std::vector<double> t1, std::vector<double> t2)
    {
        std::vector<double> result(t1.size());
        unsigned int i;
        for (i = 0; i < t1.size(); i++) {
            result[i] = t1[i] + t2[i];
        }
        return result;
    }
    
    void printVector(std::vector<double> v)
    {
        std::cout << "\n";
        unsigned int i;
        for (i = 0; i < v.size(); i++) {
            std::cout << "v[" << i << "] = " << v[i] << "\n";
        }
    }
    
    bool checkForStepSizeSmallerThanCRLB(std::vector<double> t, std::vector<double> fss)
    {
        bool answer = true;
        std::vector<double> crlb = calculateCRLB(t);
        
        unsigned int i;
        for (i = 0; i < crlb.size(); i++) {
            if (fabs(fss[i]) > crlb[i]) {
                answer = false;
            }
        }
        if (answer) {
            std::cout << "Step size was smaller than CRLB.\n";
        }
        return answer;
    }
    
    
    bool checkForToleranceCriterion(std::vector<double> t, std::vector<double> &fss);
    
    
    bool verboseCheckForToleranceCriterion(std::vector<double> t, std::vector<double> &fss)
    {
        double criterion = 0;
        unsigned int i;
        for (i = 0; i < t.size(); i++) {
            criterion += fabs(fss[i]/t[i]);
        }
        
        std::cout << "tolerance criterion = " << criterion << "\n";
        
        if (criterion > maxStepCriterion) {
            std::cout << "Step size was too large.  Now scaling it down...\n";
            for (i = 0; i < fss.size(); i++) {
                fss[i] *= maxStepCriterion/criterion;
            }
            
            std::cout << "Scaled down step:\n";
            for (i = 0; i < fss.size(); i++) {
                std::cout << "fss[" << i << "] = " << fss[i] << "\n";
            }
        }
        
        if (criterion < fitTolerance) {
            std::cout << "Fitting reached tolerance criterion.\n";
            return true;
        }
        else
        {
            return false;
        }
    }
    
    std::vector<double> fitParameters(std::vector<double> t)
    {
        if (wValues.size() < 5) {
            std::cout << "Not enough values to fit!\n";
        }
        
        numIterations = 0;
        
        std::vector<double> tc = t;
        std::vector<double> fss(4,0.0);
        
        do {
            numIterations++;
            //std::cout << "\niteration " << numIterations << ":\n";
            tc = addVectors(tc, fss);
            //printVector(tc);
            fss = calculateFisherScoreStep(tc);
            //} while (numIterations < maxIterations && (!checkForToleranceCriterion(tc, fss) || !checkForStepSizeSmallerThanCRLB(addVectors(tc, fss), fss)));
        } while (numIterations < maxIterations && (!checkForToleranceCriterion(tc, fss)));
        
        //std::cout << "\nFit result:\n";
        tc = addVectors(tc, fss);
        //printVector(tc);
        return tc;
    }
    
    std::vector<double> verboseFitParameters(std::vector<double> t)
    {
        if (wValues.size() < 5) {
            std::cout << "Not enough values to fit!\n";
        }
        
        numIterations = 0;
        
        std::vector<double> tc = t;
        std::vector<double> fss(4,0.0);
        
        do {
            numIterations++;
            std::cout << "\niteration " << numIterations << ":\n";
            tc = addVectors(tc, fss);
            printVector(tc);
            fss = printFisherScoreStep(tc);
        //} while (numIterations < maxIterations && (!checkForToleranceCriterion(tc, fss) || !checkForStepSizeSmallerThanCRLB(addVectors(tc, fss), fss)));
        } while (numIterations < maxIterations && (!verboseCheckForToleranceCriterion(tc, fss)));
        
        std::cout << "\nFit result:\n";
        tc = addVectors(tc, fss);
        printVector(tc);
        return tc;
    }
    
    unsigned int findIndexOfMaximumIntensityMinusBackground(void)
    {
        double maxIntensity = 0;
        unsigned int indexOfMaxIntensity = 0;
        unsigned int i;
        for (i = 0; i < wValues.size(); i++) {
            if (wValues[i] > maxIntensity) {
                maxIntensity = wValues[i];
                indexOfMaxIntensity = i;
                //std::cout << maxIntensity << ", " << indexOfMaxIntensity << "\n";
            }
        }
        return indexOfMaxIntensity;
    }
    
    std::vector<double> guessStartingParameters(void)
    {
        std::vector<double> guess(4,1.0);
        unsigned int indexOfMaxIntensity = findIndexOfMaximumIntensityMinusBackground();
        
        //std::cout << "index = " << indexOfMaxIntensity << "\n";
        guess[0] = wValues[indexOfMaxIntensity];// - expectedBackgroundValues[indexOfMaxIntensity];
        guess[1] = xValues[indexOfMaxIntensity];
        guess[2] = yValues[indexOfMaxIntensity];
        guess[3] = 1.3;
        
        return guess;
    }
};

#endif
