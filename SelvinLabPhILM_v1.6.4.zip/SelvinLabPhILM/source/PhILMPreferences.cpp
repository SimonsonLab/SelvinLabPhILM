/*
 *  PhILMPreferences.cpp
 *  ReverseSTORM_SL
 *
 *  Created by Paul Simonson on 8/14/10.
 *  Copyright 2010 University of Illinois at Urbana-Champaign. All rights reserved.
 *
 */

#include <iostream>
#include <fstream>

#include "PhILMPreferences.h"
#include "ScienceFile.h"

#include "basicStatistics.h"


int PhILMPreferences::saveCurrentPreferencesFile(std::string fileName)
{
	std::string preferencesHeader;
	std::vector<double> newPreferences;
    
    
    preferencesHeader = ("%spotDetectionMethod");
	newPreferences.push_back(spotDetectionMethod);
    
    preferencesHeader.append(", dilationSteps");
	newPreferences.push_back(dilationSteps);
    
    preferencesHeader.append(", spotDetectionIntegrationRadius");
	newPreferences.push_back(spotDetectionIntegrationRadius);
    
	preferencesHeader.append(", writeDetectedSpotsTIFFFiles");
	newPreferences.push_back(writeDetectedSpotsTIFFFiles);
    
    preferencesHeader.append(", maximumDetectionThreshold");
	newPreferences.push_back(maximumDetectionThreshold);  
    
    preferencesHeader.append(", throwAwayIntermediateFrames");
	newPreferences.push_back(throwAwayIntermediateFrames);
    
	preferencesHeader.append(", minimumNumberOfFramesToAverage");
	newPreferences.push_back(minimumNumberOfFramesToAverage);
    
	preferencesHeader.append(", maxNumFramesToAverage");
	newPreferences.push_back(maxNumFramesToAverage);//frames
    
    preferencesHeader.append(", spotFittingMethod");
	newPreferences.push_back(spotFittingMethod);
    
    preferencesHeader.append(", cameraBaselineCounts");
	newPreferences.push_back(cameraBaselineCounts);
    
    preferencesHeader.append(", countsToPhotonsConversionFactor");
	newPreferences.push_back(countsToPhotonsConversionFactor);
    
    preferencesHeader.append(", emGain");
	newPreferences.push_back(emGain);
	
    preferencesHeader.append(", darkCountsNoise");
	newPreferences.push_back(darkCountsNoise);//counts
	
    
    
	preferencesHeader.append(", maximumLocalizationError");
	newPreferences.push_back(maximumLocalizationError);
	
	preferencesHeader.append(", minEllipticity");
	newPreferences.push_back(minimumEllipticity);
    
	preferencesHeader.append(", maxEllipticity");
	newPreferences.push_back(maximumEllipticity);
	
	preferencesHeader.append(", minSpotWidth");
	newPreferences.push_back(minimumSpotWidth);
    
	preferencesHeader.append(", maxSpotWidth");
	newPreferences.push_back(maximumSpotWidth);

    preferencesHeader.append(", minPeakIntensity");
	newPreferences.push_back(minPeakIntensity);
    
	preferencesHeader.append(", maxPeakIntensity");
	newPreferences.push_back(maxPeakIntensity);

	
	preferencesHeader.append(", minimumSpotWidthForStillDrawingGaussian");
	newPreferences.push_back(minimumSpotWidthForStillDrawingGaussian);//zoomed pixels...
	

    
	ScienceFile defaultPreferences;
	defaultPreferences.addColumn(newPreferences);
	defaultPreferences.writeToFile(fileName.c_str(), preferencesHeader.c_str());
	
	return 0;
}

int PhILMPreferences::generateDefaultPreferencesFile(std::string fileName)
{
	std::string preferencesHeader;
	std::vector<double> newPreferences;
	
    
    //Spot detection
    preferencesHeader = ("%spotDetectionMethod");
	newPreferences.push_back(2);
    
    preferencesHeader.append(", dilationSteps");
	newPreferences.push_back(2);
    
    preferencesHeader.append(", spotDetectionIntegrationRadius");
	newPreferences.push_back(3);//pixels
    
    preferencesHeader.append(", writeDetectedSpotsTIFFFiles");
	newPreferences.push_back(0);
    
    
    //Determining frame averaging ranges
    preferencesHeader.append(", maximumDetectionThreshold");
	newPreferences.push_back(0);//counts 
    
    preferencesHeader.append(", throwAwayIntermediateFrames");
	newPreferences.push_back(0);//zero = no
    
    preferencesHeader.append(", minimumNumberOfFramesToAverage");
	newPreferences.push_back(1);//frames
    
    preferencesHeader.append(", maxNumFramesToAverage");
	newPreferences.push_back(20);//frames
    
    
    //Spot fitting
    preferencesHeader.append(", spotFittingMethod");
	newPreferences.push_back(1);
    
    preferencesHeader.append(", cameraBaselineCounts");
	newPreferences.push_back(0);//counts
    
    preferencesHeader.append(", countsToPhotonsConversionFactor");
	newPreferences.push_back(1);
    
    preferencesHeader.append(", emGain");
	newPreferences.push_back(0);
    
	preferencesHeader.append(", darkCountsNoise");
	newPreferences.push_back(0);//counts
    
    
	//Spot fit rejection criteria
	preferencesHeader.append(", maximumLocalizationError");
	newPreferences.push_back(0.5);//pixels
	
	preferencesHeader.append(", minEllipticity");
	newPreferences.push_back(1);
	preferencesHeader.append(", maxEllipticity");
	newPreferences.push_back(1.5);
	
	preferencesHeader.append(", minSpotWidth");
	newPreferences.push_back(1);//pixels
	preferencesHeader.append(", maxSpotWidth");
	newPreferences.push_back(2);//pixels
	

	preferencesHeader.append(", minPeakIntensity");
	newPreferences.push_back(0);//photons
	preferencesHeader.append(", maxPeakIntensity");
	newPreferences.push_back(0);//photons
	
    
    //Plotting
	preferencesHeader.append(", minimumSpotWidthForStillDrawingGaussian");
	newPreferences.push_back(0.5);//zoomed pixels...
    
    
	ScienceFile defaultPreferences;
	defaultPreferences.addColumn(newPreferences);
	defaultPreferences.writeToFile(fileName.c_str(), preferencesHeader.c_str());
	
	return 0;
}



int PhILMPreferences::loadPreferencesFile(const char *fileName)
{
	const int numPreferencesToLoad = 21;
	std::cout << "Now loading the preferences from file " << fileName << "...\n";
	ScienceFile PhILMPreferencesFile(fileName);
    
    PhILMPreferencesFile.display();
    
	if(PhILMPreferencesFile.numRows() != numPreferencesToLoad)
	{
		std::cout << "The preferences file, " << fileName << ", appears corrupted.  Please delete it and restart the program.\n";
		return(-1);
	}
	
	int i = 0;
    
    spotDetectionMethod = PhILMPreferencesFile.at(i++,0);
    dilationSteps = PhILMPreferencesFile.at(i++,0);
    spotDetectionIntegrationRadius = PhILMPreferencesFile.at(i++,0);
	writeDetectedSpotsTIFFFiles = PhILMPreferencesFile.at(i++,0);
    maximumDetectionThreshold = PhILMPreferencesFile.at(i++,0);
    throwAwayIntermediateFrames = PhILMPreferencesFile.at(i++,0);
	minimumNumberOfFramesToAverage = PhILMPreferencesFile.at(i++,0);
	maxNumFramesToAverage = PhILMPreferencesFile.at(i++,0);
    spotFittingMethod = PhILMPreferencesFile.at(i++,0);
    cameraBaselineCounts = PhILMPreferencesFile.at(i++,0);
    countsToPhotonsConversionFactor = PhILMPreferencesFile.at(i++,0);
    emGain = PhILMPreferencesFile.at(i++,0);
	darkCountsNoise = PhILMPreferencesFile.at(i++,0);
	maximumLocalizationError = PhILMPreferencesFile.at(i++,0);
	minimumEllipticity = PhILMPreferencesFile.at(i++,0);
	maximumEllipticity = PhILMPreferencesFile.at(i++,0);
	minimumSpotWidth = PhILMPreferencesFile.at(i++,0);
	maximumSpotWidth = PhILMPreferencesFile.at(i++,0);
    minPeakIntensity = PhILMPreferencesFile.at(i++,0);
	maxPeakIntensity = PhILMPreferencesFile.at(i++,0);
	minimumSpotWidthForStillDrawingGaussian = PhILMPreferencesFile.at(i++,0);
    
    return 0;
}



int PhILMPreferences::setTIFFFileName(const char *fileName)
{
	tiffFileName = fileName;
	chooseOutputDirectoryUsingTIFFName();
	return 0;
}


int PhILMPreferences::chooseOutputDirectoryUsingTIFFName(void)
{
	size_t found;
	
	found = tiffFileName.find("/");
	if(found != std::string::npos)
	{
		
		std::cout << "Splitting: " << tiffFileName << std::endl;
		found = tiffFileName.find_last_of("/\\");
		
		outputDirectory = tiffFileName.substr(0,found) + "/";
		
		std::cout << " output folder: " << outputDirectory << std::endl;
		std::cout << " tiff file: " << tiffFileName.substr(found+1) << std::endl;
	}
	else {
		outputDirectory = "./";
		std::cout << " output folder: " << outputDirectory << std::endl;
		std::cout << " tiff file: " << tiffFileName.substr(found+1) << std::endl;
	}
	return 0;
}


std::string PhILMPreferences::returnOutputDirectory(void)
{
	return outputDirectory;
}


std::string PhILMPreferences::prefixWithOutputDirectory(const char *theString)
{
	std::string newString = outputDirectory + theString;
	return newString;
}


std::string PhILMPreferences::formOutputFilePath(std::string simpleFileName)
{
	std::string newFilePath;
	newFilePath = outputDirectory + outputFilePrefix + simpleFileName;
	return newFilePath;
}

int PhILMPreferences::checkWhetherFileIsPresent(const char *cpath)
{
	std::ifstream file; // indata is like cin
	file.open(cpath); // opens the file
	if(!file) { // file couldn't be opened
		return 0;
	}
	else
	{
		file.close();
		return 1;
	}
}


double PhILMPreferences::retrospectivelySuggestDetectionThreshold(void)
{
    std::cout << "\nRetrospective analysis based on good spot fits:\n";
    if (checkWhetherFileIsPresent(formOutputFilePath("spotFits.txt").c_str())) {
        ScienceFile spotFits(formOutputFilePath("spotFits.txt").c_str());
        if (spotFits.numRows()) {
            double medianPeakIntensity = BasicStatistics::returnMedian(spotFits.returnColumn(0));
            double medianSigmaX = BasicStatistics::returnMedian(spotFits.returnColumn(3));
            double medianSigmaY = BasicStatistics::returnMedian(spotFits.returnColumn(4));
            return suggestADetectionThresholdUsingPeakPhotons(medianPeakIntensity, 0.5*(medianSigmaX+medianSigmaY));
        }
        else
        {
            std::cout << "Sorry, there were not good spot fits, so a retrospective suggestion on detectionThreshold is not possible.\n";
            return -1;
        }

    }
    else
    {
        std::cout << "Sorry, " << formOutputFilePath("spotFits.txt") << " is not present, so a retrospective suggestion on detectionThreshold is not possible.\n";
        return -1.0;
    }
}

double PhILMPreferences::retrospectivelySuggestDetectionThreshold(int argc, char *argv[])
{
    double suggestedThreshold = retrospectivelySuggestDetectionThreshold();
    std::cout << "Next time, you might try:\n";
    int i;
    for (i = 0; i < 4; i++) {
        std::cout << argv[i] << " ";
    }
    std::cout << suggestedThreshold;
    for (i = 5; i < argc; i++) {
        std::cout << " " << argv[i];
    }
    std::cout << "\n";
    return suggestedThreshold;
    
}
