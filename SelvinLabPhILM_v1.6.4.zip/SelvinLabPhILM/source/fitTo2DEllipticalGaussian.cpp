/*
 *  fitTo2DEllipticalGaussian.cpp
 *  ReverseSTORM_SL
 *
 *  Created by Paul Simonson on 11/5/09.
 *  Copyright 2009 Champaign Illinois Stake. All rights reserved.
 *
 */

#include "fitTo2DEllipticalGaussian.h"

#include <cmath>
#include <iostream>

#include "ScienceFile.h"
#include "return2DArrayFromMultiBitmap.h"
#include "returnDataForGaussianFitting.h"
#include "writeTIFFFileUsingMagick.h"
#include "tiffFrameOperationsUsingMagick.h"

#include <stdlib.h>
#include <stdio.h>
//#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_multifit_nlin.h>

#include <vector>

using namespace Return2DArray;

namespace Fitting2DEllipticalGaussianUsingGSL {
	
	
	class data {
	public:
		size_t n;
		double * y;
		double * sigma;
		
		std::vector<double> xValues;
		std::vector<double> yValues;
	};
	
	
	//I am fitting the equation on page 4 of the supplemental information to 
	//	Authors:	Rust,Michael J.; Bates,Mark; Zhuang,Xiaowei
	//	Title:	Sub-diffraction-limit imaging by stochastic optical reconstruction microscopy (STORM)
	//	Periodical, Abbrev:	Nat Meth
	//	Pub Year:	2006
	inline double xPrime(double x, double x0, double theta, double y, double y0)
	{
		double answer = (x - x0) * cos(theta) - (y - y0) * sin(theta);
		return answer;
	}
	
	inline double yPrime(double x, double x0, double theta, double y, double y0)
	{
		double answer = (x - x0) * sin(theta) + (y - y0) * cos(theta);
		return answer;
	}
	
	
	
	int
	expb_f (const gsl_vector * x, void *data, 
			gsl_vector * f)
	{
		size_t n = ((class data *)data)->n;
		double *y = ((class data *)data)->y;
		double *sigma = ((class data *) data)->sigma;
		
		double A = gsl_vector_get (x, 0);
		double x0 = gsl_vector_get (x, 1);
		double s_x = gsl_vector_get (x, 2);
		double y0 = gsl_vector_get (x, 3);
		double s_y = gsl_vector_get (x, 4);
		double B = gsl_vector_get (x, 5);
		double theta = gsl_vector_get (x, 6);
		
		std::vector<double> xValues = ((class data *)data)->xValues;
		std::vector<double> yValues = ((class data *)data)->yValues;
		
		size_t i;
		
		for (i = 0; i < n; i++)
		{
			double xP = xPrime(xValues[i], x0, theta, yValues[i], y0);
			double yP = yPrime(xValues[i], x0, theta, yValues[i], y0);
			
			double Yi = A 
						* exp(-0.5L * ((xP*xP)/(s_x*s_x) + (yP*yP)/(s_y*s_y)))
						+ B;
			gsl_vector_set (f, i, (Yi - y[i]) / sigma[i]);
		}
		
		return GSL_SUCCESS;
	}
	
	int
	expb_df (const gsl_vector * x, void *data, 
			 gsl_matrix * J)
	{
		size_t n = ((class data *)data)->n;
		double *sigma = ((class data *) data)->sigma;
		
		std::vector<double> xValues = ((class data *)data)->xValues;
		std::vector<double> yValues = ((class data *)data)->yValues;
		
		double A = gsl_vector_get (x, 0);
		double x0 = gsl_vector_get (x, 1);
		double s_x = gsl_vector_get (x, 2);
		double y0 = gsl_vector_get (x, 3);
		double s_y = gsl_vector_get (x, 4);
		//double B = gsl_vector_get (x, 5);
		double theta = gsl_vector_get (x, 6);	
		
		double sineTheta = sin(theta);
		double cosineTheta = cos(theta);
		
		size_t i;
		
		for (i = 0; i < n; i++)
		{
			/* Jacobian matrix J(i,j) = dfi / dxj, */
			/* where fi = (Yi - yi)/sigma[i],      */
			/*       Yi = A * exp(-lambda * i) + b  */
			/* and the xj are the parameters (A,lambda,b) */
			
			double inverseSigma = 1.0L/sigma[i];			
			double xP = xPrime(xValues[i], x0, theta, yValues[i], y0);
			double yP = yPrime(xValues[i], x0, theta, yValues[i], y0);
			double exponentialPart = exp(-0.5L * ((xP*xP)/(s_x*s_x) + (yP*yP)/(s_y*s_y)));
			double s_xSquared = s_x*s_x;
			double s_ySquared = s_y*s_y;
			
			double partial_A = exponentialPart;
			double partial_x0 = A * exponentialPart * (sineTheta * yP/s_ySquared + cosineTheta * xP/s_xSquared);
			double partial_s_x = A * exponentialPart * (xP*xP)/pow(s_x, 3);
			double partial_y0 = A * exponentialPart * (cosineTheta * yP/s_ySquared - sineTheta * xP/s_xSquared);
			double partial_s_y = A * exponentialPart * (yP*yP)/pow(s_y, 3);
			double partial_B = 1;
			double partial_theta = A * exponentialPart * (yP*xP/s_xSquared - yP * xP/s_ySquared);

			gsl_matrix_set (J, i, 0, partial_A * inverseSigma); 
			gsl_matrix_set (J, i, 1, partial_x0 * inverseSigma);
			gsl_matrix_set (J, i, 2, partial_s_x * inverseSigma); 
			gsl_matrix_set (J, i, 3, partial_y0 * inverseSigma);
			gsl_matrix_set (J, i, 4, partial_s_y * inverseSigma); 
			gsl_matrix_set (J, i, 5, partial_B * inverseSigma);
			gsl_matrix_set (J, i, 6, partial_theta * inverseSigma); 
		}
		return GSL_SUCCESS;
	}
	
	int
	expb_fdf (const gsl_vector * x, void *data, 
			  gsl_vector * f, gsl_matrix * J)
	{
		expb_f (x, data, f);
		expb_df (x, data, J);
		
		return GSL_SUCCESS;
	}
	
	
	
	void print_state (size_t iter, gsl_multifit_fdfsolver * s);
	
	TwoDGaussianFittingParametersAndErrors fitTo2DGaussianUsingGSL(std::vector<double> xPositions, std::vector<double> yPositions, std::vector<double> pixelIntensities)
	{
		int N = xPositions.size();
		std::vector<double> sigmas(N, 1.0L);
		
		return weightedFitTo2DGaussianUsingGSL(xPositions, yPositions, pixelIntensities, sigmas);
	}
	
	
	void
	print_state (unsigned int iter, gsl_multifit_fdfsolver * s)
	{
		printf ("iter: %3u x = % 15.8f % 15.8f % 15.8f "
				"|f(x)| = %g\n",
				iter,
				gsl_vector_get (s->x, 0), 
				gsl_vector_get (s->x, 1),
				gsl_vector_get (s->x, 2), 
				gsl_blas_dnrm2 (s->f));
	}
	
	
	double 
	returnSpotWidth(std::vector<double> xPositions, std::vector<double> yPositions, std::vector<double> pixelIntensities)
	{
		 TwoDGaussianFittingParametersAndErrors fitValues = fitTo2DGaussianUsingGSL(xPositions, yPositions, pixelIntensities);
		double finalResult = 0.5L * (fitValues.xWidth + fitValues.yWidth);
		
		std::cout << "Averaged spot width: " << finalResult << "\n";
		return finalResult;
	}
	
	
	/////////////////////////////////////////////////////////////////
	
	TwoDGaussianFittingParametersAndErrors 
	weightedFitTo2DGaussian(std::vector<double> xPositions, 
							std::vector<double> yPositions, 
							std::vector<double> pixelIntensities, 
							double backgroundNoise)
	{
		 TwoDGaussianFittingParametersAndErrors initialFit = fitTo2DGaussianUsingGSL(xPositions, yPositions, pixelIntensities);
		return weightedFitTo2DGaussian(xPositions, 
									   yPositions, 
									   pixelIntensities, 
									   initialFit.background, 
									   backgroundNoise);
	}
	
	
	//Use this when camera baseline and background noise are known.
	 TwoDGaussianFittingParametersAndErrors 
	weightedFitTo2DGaussian(std::vector<double> xPositions, 
							std::vector<double> yPositions, 
							std::vector<double> pixelIntensities, 
							double cameraBaseline, 
							double backgroundNoise)
	{
		int N = xPositions.size();
		std::vector<double> sigmas(N);
		register int i;
		for(i = 0; i < N; i++)
		{
			sigmas[i] = backgroundNoise + sqrt(fabs(pixelIntensities[i] - cameraBaseline));
			if(sigmas[i] < 1.0L)
				sigmas[i] = 1.0L;
		}
		return weightedFitTo2DGaussianUsingGSL(xPositions, yPositions, pixelIntensities, sigmas);
	}
	
	
	
	/////////////////////////////////////////////////////////////////
	
	
	 TwoDGaussianFittingParametersAndErrors 
	weightedFitTo2DGaussian(std::vector<double> xPositions, 
							std::vector<double> yPositions, 
							std::vector<double> pixelIntensities, 
							std::vector<double> pixelIntensitiesToSubtract, 
							double darkCountsNoise,
							int numFramesToBeAveragedBeforePhotobleaching,
							int numFramesToBeAveragedAfterPhotobleaching)
	{
		std::vector<double> newPixelIntensities;
		
		int i;
		int N = pixelIntensities.size();
		for(i = 0; i< N; i++)
			newPixelIntensities.push_back(pixelIntensities[i] - pixelIntensitiesToSubtract[i]);
		
		//figure out what the camera baseline is first.
		 TwoDGaussianFittingParametersAndErrors initialFit = fitTo2DGaussianUsingGSL(xPositions, yPositions, newPixelIntensities);
		
		//Now do the weighted fitting knowing the camera baseline (so you can calculate the noise uncertainty for each pixel).
		return weightedFitTo2DGaussian(xPositions, 
									   yPositions, 
									   pixelIntensities, 
									   pixelIntensitiesToSubtract,
									   initialFit.background, 
									   darkCountsNoise,
									   numFramesToBeAveragedBeforePhotobleaching,
									   numFramesToBeAveragedAfterPhotobleaching);
	}
	
	
	TwoDGaussianFittingParametersAndErrors weightedFitTo2DGaussian(std::vector<double> xPositions, 
																		  std::vector<double> yPositions, 
																		  std::vector<double> pixelIntensities, 
																		  std::vector<double> pixelIntensitiesToSubtract, 
																		  double cameraBaseline, 
																		  double darkCountsNoise,
																		  int numFramesToBeAveragedBeforePhotobleaching,
																		  int numFramesToBeAveragedAfterPhotobleaching)
	{
		int N = pixelIntensities.size();
		std::vector<double> sigmas(N);
		std::vector<double> newPixelIntensities(N);
		
		register int i;
		for(i = 0; i < N; i++)
		{
			sigmas[i] = sqrt(pow(darkCountsNoise, 2)/numFramesToBeAveragedAfterPhotobleaching
								+ pow(sqrt(pixelIntensitiesToSubtract[i] - cameraBaseline),2)/numFramesToBeAveragedAfterPhotobleaching 
								+ pow(darkCountsNoise, 2)/numFramesToBeAveragedBeforePhotobleaching
								+ pow(sqrt(pixelIntensities[i] - cameraBaseline), 2)/numFramesToBeAveragedBeforePhotobleaching);
			
			newPixelIntensities[i] = pixelIntensities[i] - pixelIntensitiesToSubtract[i];
		}
		
		return weightedFitTo2DGaussianUsingGSL(xPositions, yPositions, newPixelIntensities, sigmas);
	}
	
	
	TwoDGaussianFittingParametersAndErrors 
	weightedFitTo2DGaussianUsingGSL(std::vector<double> xValues, 
									std::vector<double> yValues, 
									std::vector<double> pixelIntensities, 
									std::vector<double> sigmas,
									int verboseFitting)
	{
		const double fitTolerance = 1e-10;
		const unsigned int maxNumberOfFitIterations = 1000;
		
		//Set up these global variables.
		//xValues.clear();
		//yValues.clear();
		//xValues = xPositions;
		//yValues = yPositions;
		
		const gsl_multifit_fdfsolver_type *T;
		gsl_multifit_fdfsolver *s;
		int status;
		unsigned int i, iter = 0;
		const size_t n = yValues.size();
		const size_t p = 7;
		
		//Determine initial fitting parameters
		double maxValue = pixelIntensities.at(0);
		double minValue = pixelIntensities.at(0);
		double x0 = 0, y0 = 0;
		for(i = 0; i < n; i++)
		{
			if(pixelIntensities[i] < minValue)
				minValue = pixelIntensities[i];
			if(pixelIntensities[i] > maxValue)
			{
				maxValue = pixelIntensities[i];
				x0 = xValues[i];
				y0 = yValues[i];
			}
		}
		double A = maxValue - minValue;
		double B = minValue;
		double s_x = 1.5L;
		double s_y = 1.5L;
		double theta = 0.0001L;
		
		gsl_matrix *covar = gsl_matrix_alloc (p, p);
		double y[n], sigma[n];
		class data d = { n, y, sigma, xValues, yValues};
		gsl_multifit_function_fdf f;		
		double x_init[p] = {A, x0, s_x, y0, s_y, B, theta };
		
		gsl_vector_view x = gsl_vector_view_array (x_init, p);
		
		f.f = &expb_f;
		f.df = &expb_df;
		f.fdf = &expb_fdf;
		f.n = n;
		f.p = p;
		f.params = &d;
		
		// These are the data to be fitted
		for (i = 0; i < n; i++)
		{
			y[i] = pixelIntensities[i];
			sigma[i] = sigmas[i];
		};
		
		T = gsl_multifit_fdfsolver_lmsder;
		s = gsl_multifit_fdfsolver_alloc (T, n, p);
		gsl_multifit_fdfsolver_set (s, &f, &x.vector);
		
		if(verboseFitting)
			print_state (iter, s);
		
		do
		{
			iter++;
			status = gsl_multifit_fdfsolver_iterate (s);
			
			if(verboseFitting)
			{
				printf ("status = %s\n", gsl_strerror (status));
				print_state (iter, s);
			}
			
			if (status)
				break;
			
			status = gsl_multifit_test_delta (s->dx, s->x,
											  fitTolerance, fitTolerance);
		}
		while (status == GSL_CONTINUE && iter < maxNumberOfFitIterations);
		
		if(iter == maxNumberOfFitIterations)
			if(verboseFitting)
				std::cout << "Could not fit within " << maxNumberOfFitIterations << " iterations.\n";
		
		//std::cout << gsl_strerror (status) << "\n";
		
		gsl_multifit_covar (s->J, 0.0, covar);
		
#define FIT(i) gsl_vector_get(s->x, i)
#define ERR(i) sqrt(gsl_matrix_get(covar,i,i))
		
		 TwoDGaussianFittingParametersAndErrors finalResult;
		
		{
			double chi = gsl_blas_dnrm2(s->f);
			double dof = n - p;
			double c = GSL_MAX_DBL(1, chi / sqrt(dof)); 
			
			if(verboseFitting)
			{
				printf("chisq/dof = %g\n",  pow(chi, 2.0) / dof);
				printf ("A      = %.5f +/- %.5f\n", FIT(0), c*ERR(0));
				printf ("x0 = %.5f +/- %.5f\n", FIT(1), c*ERR(1));
				printf ("s_x      = %.5f +/- %.5f\n", FIT(2), c*ERR(2));
				printf ("y0      = %.5f +/- %.5f\n", FIT(3), c*ERR(3));
				printf ("s_y = %.5f +/- %.5f\n", FIT(4), c*ERR(4));
				printf ("B      = %.5f +/- %.5f\n", FIT(5), c*ERR(5));
				printf ("theta      = %.5f +/- %.5f\n", FIT(6), c*ERR(6));

			}
			
			finalResult.peakHeight =  FIT(0);
			finalResult.xCenterValue =  FIT(1);
			finalResult.xWidth =  FIT(2);
			finalResult.yCenterValue =  FIT(3);
			finalResult.yWidth =  FIT(4);
			finalResult.background =  FIT(5);
			finalResult.tiltAngle =  FIT(6);
			
			
			while (finalResult.tiltAngle > M_PI) {
				finalResult.tiltAngle -= 2.0L*M_PI;
			}
			
			while (finalResult.tiltAngle < -M_PI) {
				finalResult.tiltAngle += 2.0L*M_PI;
			}
			
			if(finalResult.tiltAngle > 0.5L * M_PI) {
				finalResult.tiltAngle -= M_PI;
			}
			
			if(finalResult.tiltAngle < -0.5L * M_PI) {
				finalResult.tiltAngle += M_PI;
			}

			finalResult.peakHeightError = c*ERR(0);
			finalResult.xCenterValueError = c*ERR(1);
			finalResult.xWidthError = c*ERR(2);
			finalResult.yCenterValueError = c*ERR(3);
			finalResult.yWidthError = c*ERR(4);
			finalResult.backgroundError = c*ERR(5);
			finalResult.tiltAngleError = c*ERR(6);

			finalResult.numFitIterations = iter;
			finalResult.fitTolerance = fitTolerance;
		}
		if(verboseFitting)
			printf ("status = %s\n", gsl_strerror (status));
		gsl_multifit_fdfsolver_free (s);
		gsl_matrix_free (covar);
		return finalResult;
	}
	
	
	
	
	TwoDGaussianFittingParametersAndErrors
	subtractRectangularImageAndFitTo2DGaussian(char *inputFileName, int frameNumberToAnalyze, int frameNumberToSubtract, double backgroundNoise)
	{
		const int xColumn = 0;
		const int yColumn = 1;
		const int intensityColumn = 2;
		
		ScienceFile spotInformation = returnDataForGaussianFitting(return2DIntArrayUsingMagick(inputFileName, frameNumberToAnalyze));
		ScienceFile imageToSubtract = returnDataForGaussianFitting(return2DIntArrayUsingMagick(inputFileName, frameNumberToSubtract));
		
		return weightedFitTo2DGaussian(spotInformation.returnColumn(xColumn),
									   spotInformation.returnColumn(yColumn),
									   spotInformation.returnColumn(intensityColumn),
									   imageToSubtract.returnColumn(intensityColumn),
									   backgroundNoise);
	}
	
	
	
	
	TwoDGaussianFittingParametersAndErrors 
	subtractRoundImageAndFitTo2DGaussian(char *inputFileName, 
										 int frameNumberToAnalyze, 
										 int frameNumberToSubtract, 
										 double backgroundNoise, 
										 double x, 
										 double y, 
										 double spotRadius,
										 int numFramesToBeAveragedBeforePhotobleaching,
										 int numFramesToBeAveragedAfterPhotobleaching)
	
	{
		const int xColumn = 0;
		const int yColumn = 1;
		const int intensityColumn = 2;
		
		ScienceFile spotInformation = returnDataForGaussianFitting(return2DIntArrayUsingMagick(inputFileName, frameNumberToAnalyze), x, y, spotRadius);
		ScienceFile imageToSubtract = returnDataForGaussianFitting(return2DIntArrayUsingMagick(inputFileName, frameNumberToSubtract), x, y, spotRadius);
		
		return weightedFitTo2DGaussian(spotInformation.returnColumn(xColumn),
									   spotInformation.returnColumn(yColumn),
									   spotInformation.returnColumn(intensityColumn),
									   imageToSubtract.returnColumn(intensityColumn),
									   backgroundNoise,
									   numFramesToBeAveragedBeforePhotobleaching,
									   numFramesToBeAveragedAfterPhotobleaching);
	}
	
	

	

	TwoDGaussianFittingParametersAndErrors 
	subtractRoundImageAndFitTo2DGaussian(TNT::Array2D<double> beforePhotobleachingArray,
										 TNT::Array2D<double> afterPhotobleachingArray,
										 double backgroundNoise, 
										 double x, 
										 double y, 
										 double spotRadius,
										 int numFramesAveragedForBeforePhotobleaching,
										 int numFramesAveragedForAfterPhotobleaching)
	{
		const int xColumn = 0;
		const int yColumn = 1;
		const int intensityColumn = 2;
		
		ScienceFile spotInformation = returnDataForGaussianFitting(beforePhotobleachingArray, x, y, spotRadius);
		ScienceFile imageToSubtract = returnDataForGaussianFitting(afterPhotobleachingArray, x, y, spotRadius);
		
		return weightedFitTo2DGaussian(spotInformation.returnColumn(xColumn),
									   spotInformation.returnColumn(yColumn),
									   spotInformation.returnColumn(intensityColumn),
									   imageToSubtract.returnColumn(intensityColumn),
									   backgroundNoise,
									   numFramesAveragedForBeforePhotobleaching,
									   numFramesAveragedForAfterPhotobleaching);
	}
	
	
    
    /*
     
     TwoDGaussianFittingParametersAndErrors 
     weightedFitTo2DGaussian(std::vector<double> xPositions, 
     std::vector<double> yPositions, 
     std::vector<double> pixelIntensities, 
     std::vector<double> preSubtractedPixelIntensities, 
     double backgroundNoise,
     int numFramesToBeAveragedBeforePhotobleaching = 1,
     int numFramesToBeAveragedAfterPhotobleaching = 1);
     */
	
	double gaussian2D(double x, double y, double A, double x0, double s_x, double y0, double s_y, double background)
	{
		return A*exp(-0.5*pow((x-x0)/s_x,2))*exp(-0.5*pow((y-y0)/s_y,2)) + background;
	}
	

	
	
	
	
	 TwoDGaussianFittingParametersAndErrors 
	fitIndicatedSpotTo2DGaussianTNT(TNT::Array2D<int> imageArray, 
									double backgroundNoise, 
									double x, 
									double y, 
									double spotRadius)
	
	{
		const int xColumn = 0;
		const int yColumn = 1;
		const int intensityColumn = 2;
		
		ScienceFile spotInformation = returnDataForGaussianFitting(imageArray, x, y, spotRadius);
		
		return weightedFitTo2DGaussian(spotInformation.returnColumn(xColumn),
									   spotInformation.returnColumn(yColumn),
									   spotInformation.returnColumn(intensityColumn),
									   backgroundNoise);
	}
	
	
	
	
	
	TwoDGaussianFittingParametersAndErrors 
	fitIndicatedSpotTo2DGaussian(const char *inputFileName, 
								 int frameNumberToAnalyze, 
								 double backgroundNoise, 
								 double x, 
								 double y, 
								 double spotRadius)
	
	{
		return fitIndicatedSpotTo2DGaussianTNT(return2DIntArrayUsingMagick(inputFileName, frameNumberToAnalyze), backgroundNoise, x, y, spotRadius);
	}
	
	
	
	TwoDGaussianFittingParametersAndErrors 
	fitIndicatedSpotTo2DGaussian(std::vector<Magick::Image> imageVector, 
								 int frameNumberToAnalyze, 
								 double backgroundNoise, 
								 double x, 
								 double y, 
								 double spotRadius)
	
	{
		return fitIndicatedSpotTo2DGaussianTNT(return2DIntArrayUsingMagick(imageVector, frameNumberToAnalyze), backgroundNoise, x, y, spotRadius);
	}
	
	
	
	TwoDGaussianFittingParametersAndErrors 
	fitIndicatedSpotTo2DGaussian(FIMULTIBITMAP *multibitmap, 
								 int frameNumberToAnalyze, 
								 double backgroundNoise, 
								 double x, 
								 double y, 
								 double spotRadius)
	{
		return fitIndicatedSpotTo2DGaussianTNT(return2DIntArrayFromMultiBitmap(multibitmap, frameNumberToAnalyze), backgroundNoise, x, y, spotRadius);
	}
	
	
	/*
	 TwoDGaussianFittingParametersAndErrors 
	fitIndicatedSpotTo2DGaussian(FIMULTIBITMAP *multibitmap, 
								 int frameNumberToAnalyze, 
								 double backgroundNoise, 
								 double x, 
								 double y, 
								 double spotRadius)
	{
		return fitIndicatedSpotTo2DGaussianTNT(Return2DArray::return2DIntArrayFromMultiBitmap(multibitmap, frameNumberToAnalyze), backgroundNoise, x, y, spotRadius);
	}
	*/
	
	
	
}



