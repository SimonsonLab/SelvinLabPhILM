/*
 *  tiffFrameOperationsUsingMagick.h
 *  PositionAndFluorescenceTracker
 *
 *  Created by Paul Simonson on 7/15/09.
 *  Copyright 2009 University of Illinois at Urbana Champaign. All rights reserved.
 *
 */



#ifndef tiffFrameOperationsUsingMagick_H
#define tiffFrameOperationsUsingMagick_H

#include "Magick++.h"
#include "tnt.h"
#include <vector>

//Converters
Magick::Image returnMagickImageFromTNTArray(TNT::Array2D< int > imageArray);

//whichFrame should be the frame number using a counting system that starts with ONE.
TNT::Array2D< int > return2DIntArrayUsingMagick(std::vector<Magick::Image> &imageVector, int whichFrame);
TNT::Array2D< int > return2DIntArrayUsingMagick(const char *TIFFFileName, int whichFrame);

//startFrame and endFrame should be the frame number using a counting system that starts with ONE.
TNT::Array2D< int > returnIntArrayAverageOfFramesUsingMagick(std::vector<Magick::Image> &imageVector, int startFrame, int endFrame);
TNT::Array2D< int > returnIntArrayAverageOfFramesUsingMagick(const char *inputFileName, int startFrame, int endFrame);

TNT::Array2D< int > returnStandardDeviationOfFramesUsingMagick(const char *inputFileName, int startFrame, int endFrame);


#endif


