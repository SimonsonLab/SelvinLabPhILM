//
//  MLE2DGaussianFitterGaussian.h
//  SelvinLabPhILM_XCode
//
//  Created by Paul Simonson on 8/4/11.
//  Copyright 2011 University of Illinois at Urbana-Champaign. All rights reserved.
//



#ifndef MLE2DGaussianFitterGaussian_H
#define MLE2DGaussianFitterGaussian_H

#include <iostream>
#include <cmath>
#include <vector>
#include "tnt.h"


namespace MatrixInversionNamespace2 {
    //Start of code by http://chi3x10.wordpress.com/2008/05/28/calculate-matrix-inversion-in-c/
    //Modified by Paul D. Simonson on June 27, 2011, University of Illinois at Urbana-Champaign.
    
    int GetMinor(double **src, double **dest, int row, int col, int order);
    double CalcDeterminant( double **mat, int order);
    
    // matrix inversioon
    // the result is put in Y
    void MatrixInversion(double **A, int order, double **Y);
    
    //End of code by http://chi3x10.wordpress.com/2008/05/28/calculate-matrix-inversion-in-c/
    
}


class PoissonianMLE2DGaussianFitter
{
public:
    
    std::vector<double> xValues, yValues, expectationValues, observedValues;     
    //std::vector<double> varianceValues;
    int numIterations;
    int maxIterations;
    double fitTolerance;
    double maxStepCriterion;
    std::string fitterDescription;
    
    void setDefaultValues(void)
    {
        numIterations = 0;
        maxIterations = 100;
        fitTolerance = 0.0001;
        maxStepCriterion = 0.999;
    }
    
    PoissonianMLE2DGaussianFitter()
    {
        setDefaultValues();
        fitterDescription = "Fisher scoring step iteration and Poissonian distributed noise";
    }
    
    
    double returnDeltaX(double x, std::vector<double> theta)
    {
        return -erf((-1.0-x+theta[1])
                    /(sqrt(2.0)*theta[3]))
        +erf((-x+theta[1])/(sqrt(2.0)*theta[3]));
    }
    
    double returnDeltaY(double y, std::vector<double> theta)
    {
        return -erf((-1.0-y+theta[2])/(sqrt(2.0)*theta[3]))+erf((-y+theta[2])/(sqrt(2.0)*theta[3]));
    }
    
    double ppsf(unsigned int n, std::vector<double> theta)
    {
        return theta[0]*0.5*M_PI*theta[3]*theta[3]*returnDeltaX(xValues[n], theta)*returnDeltaY(yValues[n], theta);
        
        /*
         if (zValues[n]) 
         {
         return zValues[n]*theta[0]*0.5*M_PI*theta[3]*theta[3]*returnDeltaX(xValues[n], theta)*returnDeltaY(yValues[n], theta);
         }
         else
         {
         return 0;
         }
         */
    }
    
    double background(unsigned int index)
    {
        return 0;
        /*
         if (expectedBackgroundValues.size()) {
         return expectedBackgroundValues[index];
         }
         else
         {
         std::cout << "Warning: no background specified.\n";
         return 0;
         }*/
    }
    
    double returnExpectationValue(unsigned int n, std::vector<double> theta)
    {
        return ppsf(n, theta);// + background(n);
    }
    
    virtual double returnVarianceEstimate(unsigned int n, std::vector<double> theta)
    {
        double variance = returnExpectationValue(n, theta);
        if (variance) {
            return variance;
        }
        else
        {
            std::cout << "Variance estimate was zero.  Setting variance to 0.001.\n";
            return 0.001;
        }
    }
    
    void generateExpectationValues(std::vector<double> theta)
    {
        expectationValues.resize(xValues.size());
        unsigned int i;
        for (i = 0; i < xValues.size(); i++) {
            expectationValues[i] = returnExpectationValue(i, theta);
        }
    }
    
    void printAll(void)
    {
        unsigned int i;
        for (i = 0; i < expectationValues.size(); i++) {
            std::cout 
            << xValues.at(i) << ", " 
            << yValues.at(i) << ", " 
            //<< zValues.at(i) << ", " 
            << expectationValues.at(i) << ", " 
            << observedValues.at(i) << "\n";
        }
    }
    
    //Fitting stuff from here down.
    
    double dppsf_dA(double x, double y, double z, std::vector<double> theta)
    {
        if (z) 
        {
            return z*0.5*M_PI*theta[3]*theta[3]*returnDeltaX(x, theta)*returnDeltaY(y, theta);
        }
        else
        {
            return 0;
        } 
    }
    
    double dppsf_dx0(double x, double y, double z, std::vector<double> theta)
    {
        if (z) 
        {
            return  theta[0]
            *(exp(-0.5*pow((x-theta[1])/theta[3], 2))-exp(-0.5*pow((1+x-theta[1])/theta[3], 2)))
            *sqrt(M_PI*0.5)
            *theta[3]*z
            *returnDeltaY(y, theta);
        }
        else
        {
            return 0;
        } 
    }
    
    double dppsf_dy0(double x, double y, double z, std::vector<double> theta)
    {
        if (z) 
        {
            return  theta[0]
            *(exp(-0.5*pow((y-theta[2])/theta[3], 2))-exp(-0.5*pow((1+y-theta[2])/theta[3], 2)))
            *sqrt(M_PI*0.5)
            *theta[3]*z
            *returnDeltaX(x, theta);
        }
        else
        {
            return 0;
        } 
    }
    
    double dppsf_dsigma(double x, double y, double z, std::vector<double> theta)
    {
        double term1 = sqrt(2.0/M_PI);
        
        if (z) 
        {
            return  0.5*theta[0]*M_PI*z
            *
            (term1
             *(exp(-0.5*pow((y-theta[2])/theta[3], 2))*(y-theta[2])
               +exp(-0.5*pow((1+y-theta[2])/theta[3], 2))*(-1-y+theta[2])
               )
             *returnDeltaX(x, theta)
             +
             2*theta[3]*returnDeltaX(x, theta)*returnDeltaY(y, theta)
             +
             
             term1
             *(exp(-0.5*pow((x-theta[1])/theta[3], 2))
               *(x-theta[1])
               +exp(-0.5*pow((1+x-theta[1])/theta[3], 2))*(-1-x+theta[1]))
             *returnDeltaY(y, theta)
             );
        }
        else
        {
            return 0;
        } 
    }
    
    virtual TNT::Array2D<double> calculateFIM(std::vector<double> t);
    
    
    TNT::Array2D<double> calculateInverseFIM(std::vector<double> t)
    {
        TNT::Array2D<double> FIM_t = calculateFIM(t);
        //checkFisherMatrixForSingularity();
        int numParameters = FIM_t.dim1();
        TNT::Array2D<double> IFIM_t(numParameters, numParameters);
        MatrixInversionNamespace2::MatrixInversion(FIM_t, numParameters, IFIM_t);
        return IFIM_t;
    }
    
    std::vector<double> calculateCRLB(std::vector<double> t)
    {
        ///This should be generic for any CRLB.
        std::vector<double> crlb(t.size());
        
        TNT::Array2D<double> inverseFIM = calculateInverseFIM(t);
        int i;
        for (i = 0; i < inverseFIM.dim1(); i++) {
            crlb[i] = sqrt(inverseFIM[i][i]);
        }
        return crlb;
    }
    
    std::vector<double> printCRLB(std::vector<double> t)
    {
        std::vector<double> crlb = calculateCRLB(t);
        unsigned int i;
        for (i = 0; i < crlb.size(); i++) {
            std::cout << "CRLB[" << i << "] = " << crlb[i] << "\n";
        }
        return crlb;
    }
    
    virtual std::vector<double> calculateFisherScore(std::vector<double> t)
    {
        std::vector<double> s_t(t.size(), 0.0);
        
        unsigned int n;
        for (n = 0; n < observedValues.size(); n++) {
            double g_n = returnExpectationValue(n, t);
            
            double term2 = (observedValues[n] - g_n)/returnExpectationValue(n, t);//Changing it back...
            
            /*
             s_t[0] += dppsf_dA(xValues[n], yValues[n], zValues[n], t) * term2;
             s_t[1] += dppsf_dx0(xValues[n], yValues[n], zValues[n], t) * term2;
             s_t[2] += dppsf_dy0(xValues[n], yValues[n], zValues[n], t) * term2;
             s_t[3] += dppsf_dsigma(xValues[n], yValues[n], zValues[n], t) * term2;
             */
            
            s_t[0] += dppsf_dA(xValues[n], yValues[n], 1.0, t) * term2;
            s_t[1] += dppsf_dx0(xValues[n], yValues[n], 1.0, t) * term2;
            s_t[2] += dppsf_dy0(xValues[n], yValues[n], 1.0, t) * term2;
            s_t[3] += dppsf_dsigma(xValues[n], yValues[n], 1.0, t) * term2;
        }
        return s_t;
    }
    
    void printS_t(std::vector<double> t)
    {
        std::vector<double> s_t = calculateFisherScore(t);
        unsigned int i;
        for (i = 0; i < s_t.size(); i++) {
            std::cout << "s_t[i] = " << s_t[i] << "\n";
        }
    }
    
    std::vector<double> calculateFisherScoreStep(std::vector<double> t)
    {
        TNT::Array2D<double> inverseFIM = calculateInverseFIM(t);
        std::vector<double> s_t = calculateFisherScore(t);
        
        std::vector<double> fisherScoreStep(4);
        
        int i;
        for (i = 0; i < 4; i++) {
            int j;
            for (j = 0; j < 4; j++) {
                fisherScoreStep[i] += inverseFIM[i][j] * s_t[j];
            }
        }
        
        return fisherScoreStep;
    }
    
    std::vector<double> printFisherScoreStep(std::vector<double> t)
    {
        std::vector<double> fss = calculateFisherScoreStep(t);
        unsigned int i;
        for (i = 0; i < fss.size(); i++) {
            std::cout << "fss[" << i << "] = " << fss[i] << "\n";
        }
        return fss;
    }
    
    
    std::vector<double> addVectors(std::vector<double> t1, std::vector<double> t2)
    {
        std::vector<double> result(t1.size());
        unsigned int i;
        for (i = 0; i < t1.size(); i++) {
            result[i] = t1[i] + t2[i];
        }
        return result;
    }
    
    void printVector(std::vector<double> v)
    {
        std::cout << "\n";
        unsigned int i;
        for (i = 0; i < v.size(); i++) {
            std::cout << "v[" << i << "] = " << v[i] << "\n";
        }
    }
    
    
    bool checkForToleranceCriterion(std::vector<double> t, std::vector<double> &fss)
    {
        double criterion = 0;
        double fssMagnitudeSquared = 0.0;
        
        unsigned int i;
        for (i = 0; i < t.size(); i++) {
            criterion += fabs(fss[i]/t[i]);
            fssMagnitudeSquared += fss[i] * fss[i];
        }
        
        //std::cout << "fssMagnitude = " << sqrt(fssMagnitudeSquared) << "\n";
        
        if (criterion > maxStepCriterion) {
            //std::cout << "Step size was too large.  Now scaling it down...\n";
            for (i = 0; i < fss.size(); i++) {
                fss[i] *= maxStepCriterion/criterion;
            }
            
            //std::cout << "Scaled down step:\n";
            //for (i = 0; i < fss.size(); i++) {
            //    std::cout << "fss[" << i << "] = " << fss[i] << "\n";
            //}
            
            return false;
        }
        
        
        if (fssMagnitudeSquared < fitTolerance*fitTolerance) {
            //if (criterion < fitTolerance) {
            //std::cout << "Fitting reached tolerance criterion.\n";
            return true;
        }
        else
        {
            return false;
        }
    }
    
    
    std::vector<double> fitParameters(std::vector<double> t)
    {
        if (observedValues.size() < 5) {
            std::cout << "Not enough values to fit!\n";
        }
        
        numIterations = 0;
        
        std::vector<double> tc = t;
        std::vector<double> fss(4,0.0);
        
        do {
            numIterations++;
            //std::cout << "\niteration " << numIterations << ":\n";
            tc = addVectors(tc, fss);
            //printVector(tc);
            fss = calculateFisherScoreStep(tc);
            
        } while (numIterations < maxIterations && (!checkForToleranceCriterion(tc, fss)));
        
        //std::cout << "\nFit result:\n";
        tc = addVectors(tc, fss);
        //printVector(tc);
        return tc;
    }
    
    unsigned int findIndexOfMaximumIntensityMinusBackground(void)
    {
        double maxIntensity = 0;
        unsigned int indexOfMaxIntensity = 0;
        unsigned int i;
        for (i = 0; i < observedValues.size(); i++) {
            if (observedValues[i] > maxIntensity) {
                maxIntensity = observedValues[i];
                indexOfMaxIntensity = i;
                //std::cout << maxIntensity << ", " << indexOfMaxIntensity << "\n";
            }
        }
        return indexOfMaxIntensity;
    }
    
    std::vector<double> guessStartingParameters(void)
    {
        std::vector<double> guess(4,1.0);
        unsigned int indexOfMaxIntensity = findIndexOfMaximumIntensityMinusBackground();
        
        //std::cout << "index = " << indexOfMaxIntensity << "\n";
        guess[0] = observedValues[indexOfMaxIntensity];// - expectedBackgroundValues[indexOfMaxIntensity];
        guess[1] = xValues[indexOfMaxIntensity];
        guess[2] = yValues[indexOfMaxIntensity];
        guess[3] = 1.3;
        
        return guess;
    }
};


class twoDGaussianFitter_WithReadoutNoiseAndEMGain : public PoissonianMLE2DGaussianFitter
{
public:
    double emGain;
    double readoutNoisePhotonsSquared;
    
    twoDGaussianFitter_WithReadoutNoiseAndEMGain() : PoissonianMLE2DGaussianFitter()
    {
        //std::cout << "Setting camera defaults.\n\a";
        emGain = 0.0;
        readoutNoisePhotonsSquared = 0.0;
    }
    
    virtual double returnVarianceEstimate(unsigned int n, std::vector<double> theta);
    
};


class PhILMFitter : public PoissonianMLE2DGaussianFitter
{
    
public:
    
    double emGain;
    double readoutNoisePhotonsSquared;
    int numFramesAveragedBeforePhotobleaching;
    int numFramesAveragedAfterPhotobleaching;
    
    std::vector<double> prePhotobleachingIntensityValues, postPhotobleachingIntensityValues;     

    PhILMFitter() : PoissonianMLE2DGaussianFitter()
    {
        //std::cout << "Setting camera defaults.\n\a";
        emGain = 0.0;
        readoutNoisePhotonsSquared = 0.0;
        numFramesAveragedBeforePhotobleaching = 1;
        numFramesAveragedAfterPhotobleaching = 1;
        
        fitterDescription = "Fisher scoring step iteration and variance is calculated for difference of frames, EM gain, and readout noise";
    }
    
    void calculateObservedIntensityDifferenceValues()
    {
        observedValues.resize(prePhotobleachingIntensityValues.size());
        unsigned int n;
        for(n = 0; n < prePhotobleachingIntensityValues.size(); n++)
        {
            observedValues[n] = prePhotobleachingIntensityValues[n] - postPhotobleachingIntensityValues[n];
        }
    }
    
    void calculateObservedIntensityDifferenceValues(std::vector<double> prePhotobleachingIntensityValues1, std::vector<double>postPhotobleachingIntensityValues1)
    {
        prePhotobleachingIntensityValues = prePhotobleachingIntensityValues1;
        postPhotobleachingIntensityValues = postPhotobleachingIntensityValues1;
        calculateObservedIntensityDifferenceValues();
    }
    
    virtual double returnVarianceEstimate(unsigned int n, std::vector<double> theta);
    
};


#endif
