//
//  MLE2DGaussianFitterGaussian.cpp
//  SelvinLabPhILM_XCode
//
//  Created by Paul Simonson on 8/4/11.
//  Copyright 2011 University of Illinois at Urbana-Champaign. All rights reserved.
//

#include "MLE2DGaussianFitterGaussian.h"


TNT::Array2D<double> PoissonianMLE2DGaussianFitter::calculateFIM(std::vector<double> t)
{        
    TNT::Array2D<double> temp(4, 4, 0.0);
    
    unsigned int n;
    for (n = 0; n < observedValues.size(); n++) 
    {
        //There is a serious problem if the variance is estimated as zero.  Here is a hack:
        /*
        if (!varianceValues[n]) {
            varianceValues[n] = 0.001;
        }
        double oneOverError = 1.0/varianceValues[n];//This was changed from 1/g to 1/errorValue to work with Gaussian distributions.
        */
        
        double oneOverError = 1.0/returnExpectationValue(n, t);//Changing it back...
        
        
        temp[0][0] += oneOverError * pow(dppsf_dA(xValues[n],yValues[n], 1.0,t), 2);
        temp[1][1] += oneOverError * pow(dppsf_dx0(xValues[n],yValues[n],1.0,t), 2);
        temp[2][2] += oneOverError * pow(dppsf_dy0(xValues[n],yValues[n],1.0,t), 2);
        temp[3][3] += oneOverError * pow(dppsf_dsigma(xValues[n],yValues[n],1.0,t), 2);
        temp[0][1] += oneOverError * dppsf_dA(xValues[n],yValues[n],1.0,t) * dppsf_dx0(xValues[n],yValues[n],1.0,t);
        temp[0][2] += oneOverError * dppsf_dA(xValues[n],yValues[n],1.0,t) * dppsf_dy0(xValues[n],yValues[n],1.0,t);
        temp[0][3] += oneOverError * dppsf_dA(xValues[n],yValues[n],1.0,t) * dppsf_dsigma(xValues[n],yValues[n],1.0,t);
        temp[1][2] += oneOverError * dppsf_dx0(xValues[n],yValues[n],1.0,t) * dppsf_dy0(xValues[n],yValues[n],1.0,t);
        temp[1][3] += oneOverError * dppsf_dx0(xValues[n],yValues[n],1.0,t) * dppsf_dsigma(xValues[n],yValues[n],1.0,t);
        temp[2][3] += oneOverError * dppsf_dy0(xValues[n],yValues[n],1.0,t) * dppsf_dsigma(xValues[n],yValues[n],1.0,t);
        
        /*//Using z values:
         temp[0][0] += oneOverError * pow(dppsf_dA(xValues[n],yValues[n],zValues[n],t), 2);
         temp[1][1] += oneOverError * pow(dppsf_dx0(xValues[n],yValues[n],zValues[n],t), 2);
         temp[2][2] += oneOverError * pow(dppsf_dy0(xValues[n],yValues[n],zValues[n],t), 2);
         temp[3][3] += oneOverError * pow(dppsf_dsigma(xValues[n],yValues[n],zValues[n],t), 2);
         temp[0][1] += oneOverError * dppsf_dA(xValues[n],yValues[n],zValues[n],t) * dppsf_dx0(xValues[n],yValues[n],zValues[n],t);
         temp[0][2] += oneOverError * dppsf_dA(xValues[n],yValues[n],zValues[n],t) * dppsf_dy0(xValues[n],yValues[n],zValues[n],t);
         temp[0][3] += oneOverError * dppsf_dA(xValues[n],yValues[n],zValues[n],t) * dppsf_dsigma(xValues[n],yValues[n],zValues[n],t);
         temp[1][2] += oneOverError * dppsf_dx0(xValues[n],yValues[n],zValues[n],t) * dppsf_dy0(xValues[n],yValues[n],zValues[n],t);
         temp[1][3] += oneOverError * dppsf_dx0(xValues[n],yValues[n],zValues[n],t) * dppsf_dsigma(xValues[n],yValues[n],zValues[n],t);
         temp[2][3] += oneOverError * dppsf_dy0(xValues[n],yValues[n],zValues[n],t) * dppsf_dsigma(xValues[n],yValues[n],zValues[n],t);
         */
        
    }
    temp[1][0] = temp[0][1];
    temp[2][0] = temp[0][2];
    temp[3][0] = temp[0][3];
    
    temp[2][1] = temp[1][2];
    temp[3][1] = temp[1][3];
    
    temp[3][2] = temp[2][3];
    
    return temp;
}


double twoDGaussianFitter_WithReadoutNoiseAndEMGain::returnVarianceEstimate(unsigned int n, std::vector<double> theta)
{
    double variance = returnExpectationValue(n, theta) + readoutNoisePhotonsSquared;
    if (emGain) {
        variance *= 2.0;
    }
    if (variance) {
        return variance;
    }
    else
    {
        std::cout << "Variance estimate was zero.  Setting variance to 0.001.\n";
        return 0.001;
    }
}


double PhILMFitter::returnVarianceEstimate(unsigned int n, std::vector<double> theta)
{
    double variance 
    = numFramesAveragedBeforePhotobleaching * prePhotobleachingIntensityValues[n]
    + numFramesAveragedAfterPhotobleaching * postPhotobleachingIntensityValues[n]
    //- returnExpectationValue(n, theta)/numFramesAveragedBeforePhotobleaching 
    + readoutNoisePhotonsSquared
    + readoutNoisePhotonsSquared;
    
    //variance = returnExpectationValue(n, theta) + 20000;
    
    /*
    double variance 
    = returnExpectationValue(n, theta)
    + 2.0*postPhotobleachingIntensityValues[n]
    + readoutNoisePhotonsSquared/numFramesAveragedBeforePhotobleaching
    + readoutNoisePhotonsSquared/numFramesAveragedAfterPhotobleaching;
    */
    
    if (emGain) {
        variance *= 2.0;
    }
    
    if (variance) {
        return variance;
    }
    else
    {
        std::cout << "Variance estimate was zero.  Setting variance to 0.001.\n";
        return 0.001;
    }
}


namespace MatrixInversionNamespace2 {
    //Start of code by http://chi3x10.wordpress.com/2008/05/28/calculate-matrix-inversion-in-c/
    //Modified by Paul D. Simonson on June 27, 2011, University of Illinois at Urbana-Champaign.
    
    int GetMinor(double **src, double **dest, int row, int col, int order);
    double CalcDeterminant( double **mat, int order);
    
    // matrix inversioon
    // the result is put in Y
    void MatrixInversion(double **A, int order, double **Y)
    {
        // get the determinant of a
        double det = 1.0/CalcDeterminant(A,order);
        
        // memory allocation
        double *temp = new double[(order-1)*(order-1)];
        double **minor = new double*[order-1];
        for(int i=0;i<order-1;i++)
            minor[i] = temp+(i*(order-1));
        
        for(int j=0;j<order;j++)
        {
            for(int i=0;i<order;i++)
            {
                // get the co-factor (matrix) of A(j,i)
                GetMinor(A,minor,j,i,order);
                //std::cout << "i = " << i << ", j = " << j << "\n";
                //std::cout << "Y = " << Y[i][j] << "\n";
                //std::cout << "det... = " << det*CalcDeterminant(minor,order-1) << "\n";
                Y[i][j] = det*CalcDeterminant(minor,order-1);
                if( (i+j)%2 == 1)
                    Y[i][j] = -Y[i][j];
            }
        }
        
        // release memory
        //delete [] minor[0];
        delete [] temp;
        delete [] minor;
    }
    
    // calculate the cofactor of element (row,col)
    int GetMinor(double **src, double **dest, int row, int col, int order)
    {
        // indicate which col and row is being copied to dest
        int colCount=0,rowCount=0;
        
        for(int i = 0; i < order; i++ )
        {
            if( i != row )
            {
                colCount = 0;
                for(int j = 0; j < order; j++ )
                {
                    // when j is not the element
                    if( j != col )
                    {
                        dest[rowCount][colCount] = src[i][j];
                        colCount++;
                    }
                }
                rowCount++;
            }
        }
        
        return 1;
    }
    
    // Calculate the determinant recursively.
    double CalcDeterminant( double **mat, int order)
    {
        // order must be >= 0
        // stop the recursion when matrix is a single element
        if( order == 1 )
            return mat[0][0];
        
        // the determinant value
        double det = 0;
        
        // allocate the cofactor matrix
        double **minor;
        minor = new double*[order-1];
        for(int i=0;i<order-1;i++)
            minor[i] = new double[order-1];
        
        for(int i = 0; i < order; i++ )
        {
            // get minor of element (0,i)
            GetMinor( mat, minor, 0, i , order);
            // the recusion is here!
            
            det += (i%2==1?-1.0:1.0) * mat[0][i] * CalcDeterminant(minor,order-1);
            //det += pow( -1.0, i ) * mat[0][i] * CalcDeterminant( minor,order-1 );
        }
        
        // release memory
        for(int i=0;i<order-1;i++)
            delete [] minor[i];
        delete [] minor;
        
        return det;
    }
    //End of code by http://chi3x10.wordpress.com/2008/05/28/calculate-matrix-inversion-in-c/
    
}


