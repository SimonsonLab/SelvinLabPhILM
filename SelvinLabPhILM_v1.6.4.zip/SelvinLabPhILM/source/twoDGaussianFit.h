/*
 *  twoDGaussianFit.h
 *  ReverseSTORM_SL
 *
 *  Created by Paul Simonson on 12/21/09.
 *  Copyright 2009 University of Illinois at Urbana-Champaign. All rights reserved.
 *
 */

#ifndef twoDGaussianFit_H
#define twoDGaussianFit_H

#include <vector>
#include <string>

class TwoDGaussianFittingParametersAndErrors
{
public:
	TwoDGaussianFittingParametersAndErrors();
	TwoDGaussianFittingParametersAndErrors(double pH,
										   double x0,
										   double y0,
										   double xW,
										   double yW,
										   double bg,
										   double ta,
										   double phe,
										   double x0Error,
										   double y0Error,
										   double xwe,
										   double ywe,
										   double bge,
										   double tae);
	
	
	double	peakHeight, 
	xCenterValue, 
	yCenterValue, 
	xWidth, 
	yWidth, 
	tiltAngle,
	background;
	
	double	peakHeightError, 
	xCenterValueError, 
	yCenterValueError, 
	xWidthError, 
	yWidthError, 
	tiltAngleError,
	backgroundError;
	
	int numFitIterations;
	double fitTolerance;
	
	std::vector<double> returnFitAsVector(void);
	static std::string returnFitVectorHeader(void);
	
	int printFit(void);
	
	double estimateTotalCountsUsingFittingParameters(void);
	double estimateTotalPhotonsUsingFittingParameters(double countsToPhotonsConversionFactor);
	double STORMEllipticity(void);
	double ellipticity(void);
	double averageOfXWidthAndYWidth(void);
	
	double returnFitValue(double x, double y);

	double returnFitValueOfLocalization(double x, double y);

};
typedef class TwoDGaussianFittingParametersAndErrors TwoDGaussianFittingParametersAndErrors;

#endif



