/*
 *  detectParticlesClass.cpp
 *  ReverseSTORM_SL
 *
 *  Created by Paul Simonson on 1/23/10.
 *  Copyright 2009-2011 University of Illinois at Urbana-Champaign. All rights reserved.
 *
 */

const bool verboseOutput = false;
//#define WRITEDILATEDIMAGEFILE

#include "detectParticlesClass.h"

#include <omp.h>
#include <fstream>
#include <iostream>
#include <vector>
#include <cmath>

#include "tnt.h"
//#include "fitTo2DGaussianUsingGSL.h"
//#include "fitTo2DEllipticalGaussian.h"
//#include "fitTo2DRoundGaussian.h"
//using namespace Fitting2DRoundGaussian;//Just use this one because it is the fastest.
//using namespace Fitting2DGaussianUsingGSL;
//using namespace Fitting2DEllipticalGaussianUsingGSL;//Use this one if you have to do elliptical spot rejection.
#include "tiffFrameOperations.h"
#include "SimonsonLibTIFF_IO.h"
#include "return2DArrayFromMultiBitmap.h"
#include "returnSpotIntensity.h"


using namespace Return2DArray;



//const double pi = 3.141592653589793238462643383279L;
const double pi = M_PI;
const double inversePi = 1.0L/pi;



TNT::Array2D< int > adjustNearestNeighborsBy1SoMultipleSpotsAreNotDetectedFromOneSpot(TNT::Array2D< int > image)
{
    //std::cout << "adjustNearestNeighborsBy1SoMultipleSpotsAreNotDetectedFromOneSpot\n";
    
    TNT::Array2D< int > temp = image.copy();
    
    
	int width, height;
	width = image.dim1() - 1;//not going through whole range...
	height = image.dim2()- 1;//not going through whole range...
	
    int i;
//#pragma omp parallel for
    for (i = 1; i < width; i++) {
        int j;
        for (j = 1; j < height; j++) {
            
            int localMax = image[i][j];
            int localMin = image[i][j];

            bool updated = false;
            bool updatedMin = false;

            int m, n;
            for (m = i - 1; m < i + 2; m++) {
                for (n = j - 1; n < j + 2; n++) {
                    if (m != i && n != j) {
                        if (image[m][n] >= localMax) {
                            localMax = image[m][n];
                            updated = true;
                        }
                        if (image[m][n] <= localMin) {
                            localMin = image[m][n];
                            updatedMin = true;
                        }
                    }
                }
            }
            if (updated) {
                if (localMax == image[i][j]) {
                    temp[i][j] += 1;
                    //std::cout << "updated max\n";
                }
            }
            if (updatedMin) {
                if (localMin == image[i][j]) {
                    temp[i][j] -= 1;
                    //std::cout << "updated min\n";
                }
            }
        }
    }
    return temp;
}




//Enter -1 for the startFrame to apply it to every frame.
//Use positiveParticles to determine whether you search for "hills" or "holes."
int DetectParticlesClass::detectParticlesUsingFreeImage(const char *inputTIFFFileName, //FIMULTIBITMAP *multibitmap, 
														const char *outputFileNamex, 
														int numFramesToAveragex, 
														int startFramex, 
														int endFramex, 
														int dilationStepsx, 
														double spotRadiusx, 
														int thresholdx, 
														double minimumSeparationx,
														double minimumSpotWidthx,
														double maximumSpotWidthx,
														double backgroundNoisex,
														int positiveParticlesx,
														int pixelIntensityCutoffx)
{	
	if (verboseOutput) {
		copyrightInformation();
	}
	
	updateDetectionSettings(inputTIFFFileName, //FIMULTIBITMAP *multibitmap, 
							outputFileNamex, 
							numFramesToAveragex, 
							startFramex, 
							endFramex, 
							dilationStepsx, 
							spotRadiusx, 
							thresholdx, 
							minimumSeparationx,
							minimumSpotWidthx,
							maximumSpotWidthx,
							backgroundNoisex,
							positiveParticlesx,
							pixelIntensityCutoffx);
	
    std::vector< TNT::Array2D< int > > imageVector;
    
	detectParticles(imageVector);
	
	writeDetectionSettings();
	writeDetectedSpotsFile();
	
	return 0;
}


int DetectParticlesClass::detectParticles(std::vector< TNT::Array2D< int > > &imageVector, 
                                          const char *outputFileNamex, 
                                          int numFramesToAveragex, 
                                          int startFramex, 
                                          int endFramex, 
                                          int dilationStepsx, 
                                          double spotRadiusx, 
                                          int thresholdx, 
                                          double minimumSeparationx,
                                          double minimumSpotWidthx,
                                          double maximumSpotWidthx,
                                          double backgroundNoisex,
                                          int positiveParticlesx,
                                          int pixelIntensityCutoffx)
{	
	if (verboseOutput) {
		copyrightInformation();
	}
	
	updateDetectionSettings("Image vector was passed, not tiff file name.", //FIMULTIBITMAP *multibitmap, 
							outputFileNamex, 
							numFramesToAveragex, 
							startFramex, 
							endFramex, 
							dilationStepsx, 
							spotRadiusx, 
							thresholdx, 
							minimumSeparationx,
							minimumSpotWidthx,
							maximumSpotWidthx,
							backgroundNoisex,
							positiveParticlesx,
							pixelIntensityCutoffx);
    
    //std::cout << "I made it to here.\n";
    
	detectParticles(imageVector);
	
	writeDetectionSettings();
	writeDetectedSpotsFile();
	
	return 0;
}


int DetectParticlesClass::detectParticles(std::vector< TNT::Array2D< int > > &imageVector)
{
    int detectionResults;
    /*
    switch (particleDetectionMethod) {
        case 1:
        {
            detectionResults = detectParticlesMethod1(imageVector);
        }
            break;
            
        case 2:
        {
            detectionResults = detectParticlesMethod2(imageVector);
        }
            break;
            
        default:
            break;
    }
     */
    if (particleDetectionMethod == 2) {
        detectionResults = detectParticlesMethod2(imageVector);
    }
    else //default to method 1
    {
        detectionResults = detectParticlesMethod1(imageVector);
    }
    return detectionResults;
}

int DetectParticlesClass::detectParticlesMethod1(std::vector< TNT::Array2D< int > > &imageVector)
{	
	clearVariablesForNewDetection();
    
	if(!dilationSteps)//not using default values, so enter them manually
		askForDetectionSettings();
	
	//Benchmarking stuff
	TNT::Stopwatch Q;
	Q.start();
	
    if (!imageVector.size()) {
        std::cout << "The image vector is empty!  Trying to open by the file name...\n";
        SimonsonLibTIFF_IO::readTIFFStack(inputFileName, imageVector);
    }
    
	numFrames = imageVector.size();
    
#ifdef WRITEDILATEDIMAGEFILE
	std::vector< TNT::Array2D< int > > dilatedImagesList(numFrames); 
#endif
	
	correctFrameRanges();
	
	int j;
    //#pragma omp parallel for
	for(j = startFrame; j < endFrame + 1; j++)
	{	
		if (verboseOutput) {
            //#pragma omp critical
            {
                std::cout << "Frame: " << j + 1 << ", Time: " << Q.read() << " s\n";
            }
		}
		
		//Get the image data for frame j from the multibitmap
		TNT::Array2D< int > imageArray;
		//#pragma omp critical
		{
			if(numFramesToAverage == 1)
            {
                imageArray = imageVector.at(j).copy();
            }
			else
            {
                imageArray = SimonsonLibTIFF_IO::returnAverageOfFramesAsInt(imageVector, j+1, j+numFramesToAverage);
            }
		}
        
		width = imageArray.dim1();
		height = imageArray.dim2();
		
		//Use it if you want to ignore pixels brighter (or dimmer) than the cutoff.
		if(pixelIntensityCutoff){
			applyPixelIntensityCutoff(imageArray);
		}
		
		//Dilate the image.
		TNT::Array2D<int> dilatedImage;
		if(positiveParticles)
		{
			dilatedImage = dilateMaximaReturnTNTArray(imageArray, dilationSteps);
		}
		else
		{
			dilatedImage = dilateMinimaReturnTNTArray(imageArray, dilationSteps);
		}
		
#ifdef WRITEDILATEDIMAGEFILE
		dilatedImagesList.at(j-startFrame) = dilatedImage;
#endif
		
		findLocalMaximaUsingImageAndDilatedImageMethod1(j+1, imageArray, dilatedImage);

	}
	
	
#ifdef WRITEDILATEDIMAGEFILE
	if(positiveParticles)	
	{
		SimonsonLibTIFF_IO::writeTIFFStack<int>(formOutputFilePath("dilatedMaxima.tif"), dilatedImagesList);	
	}
	else
	{
		SimonsonLibTIFF_IO::writeTIFFStack<int>(formOutputFilePath("dilatedMinima.tif"), dilatedImagesList);	
	}
#endif
	
	if (writeOutputTIFFsFlag) {
		createDetectedSpotsTIFF(imageVector);
        writeSpotsPerFrameFile(numFrames);
	}
    
	//std::cout << "Ending particle detection.\n\a";
	//printDetectedSpots(detectedSpots);
    
    std::cout << detectedSpots.size() << " total spots were detected.\n";
	return 0;
}
        
        
int DetectParticlesClass::detectParticlesMethod2(std::vector< TNT::Array2D< int > > &imageVector)
{	
    std::cout << "Now using particle detection method 2, with no pixel intensity cutoff or ring background subtraction.\n";
	clearVariablesForNewDetection();
    
	if(!dilationSteps)//not using default values, so enter them manually
		askForDetectionSettings();
	
    if (!imageVector.size()) {
        std::cout << "The image vector is empty!  Trying to open by the file name...\n";
        SimonsonLibTIFF_IO::readTIFFStack(inputFileName, imageVector);
    }
    
	numFrames = imageVector.size();
    
#ifdef WRITEDILATEDIMAGEFILE
	std::vector< TNT::Array2D< int > > dilatedImagesList(numFrames); 
#endif
	
    
    std::vector< TNT::Array2D< int > > adjustedByAPixel(numFrames); 

	correctFrameRanges();
	    
	int j;
    //#pragma omp parallel for
	for(j = startFrame; j < endFrame + 1; j++)
	{	
		if (verboseOutput) {
            //#pragma omp critical
            {
                std::cout << "Frame: " << j + 1 << "\n";
            }
		}
		
		//Get the image data for frame j from the multibitmap
		TNT::Array2D< int > imageArray;
		//#pragma omp critical
		{
			if(numFramesToAverage == 1)
            {
                imageArray = imageVector.at(j).copy();
            }
			else
            {
                imageArray = SimonsonLibTIFF_IO::returnAverageOfFramesAsInt(imageVector, j+1, j+numFramesToAverage);
            }
		}
        
        //imageArray = adjustNearestNeighborsBy1SoMultipleSpotsAreNotDetectedFromOneSpot(imageArray);
        //adjustedByAPixel.at(j-startFrame) = imageArray.copy();
        
		width = imageArray.dim1();
		height = imageArray.dim2();
		
		//Use it if you want to ignore pixels brighter (or dimmer) than the cutoff.
        
		if(pixelIntensityCutoff){
			subtractPixelIntensityCutoff(imageArray);
		}
         
		
		//Dilate the image.
		TNT::Array2D<int> dilatedImage;
		if(positiveParticles)
		{
			dilatedImage = dilateMaximaReturnTNTArray(imageArray, dilationSteps);
		}
		else
		{
			dilatedImage = dilateMinimaReturnTNTArray(imageArray, dilationSteps);
		}
		
#ifdef WRITEDILATEDIMAGEFILE
		dilatedImagesList.at(j-startFrame) = dilatedImage;
#endif
		
		findLocalMaximaUsingImageAndDilatedImageMethod2(j+1, imageArray, dilatedImage);
        
	}
		
    //SimonsonLibTIFF_IO::writeTIFFStack<int>(formOutputFilePath("adjustedByAPixel.tif"), adjustedByAPixel);
    
#ifdef WRITEDILATEDIMAGEFILE
	if(positiveParticles)	
	{
		SimonsonLibTIFF_IO::writeTIFFStack<int>(formOutputFilePath("dilatedMaxima.tif"), dilatedImagesList);	
	}
	else
	{
		SimonsonLibTIFF_IO::writeTIFFStack<int>(formOutputFilePath("dilatedMinima.tif"), dilatedImagesList);	
	}
#endif
	
	if (writeOutputTIFFsFlag) {
		createDetectedSpotsTIFF(imageVector);
        writeSpotsPerFrameFile(numFrames);
	}
    
	//std::cout << "Ending particle detection.\n\a";
	//printDetectedSpots(detectedSpots);
    
    std::cout << detectedSpots.size() << " total spots were detected.\n";
	return 0;
}



int DetectParticlesClass::updateDetectionSettings(const char *inputTIFFFileName, //FIMULTIBITMAP *multibitmap, 
												  const char *outputFileNamex, 
												  int numFramesToAveragex, 
												  int startFramex, 
												  int endFramex, 
												  int dilationStepsx, 
												  double spotRadiusx, 
												  int thresholdx, 
												  double minimumSeparationx,
												  double minimumSpotWidthx,
												  double maximumSpotWidthx,
												  double backgroundNoisex,
												  int positiveParticlesx,
												  int pixelIntensityCutoffx)
{
	inputFileName = inputTIFFFileName;
	outputFileName = outputFileNamex;
	numFramesToAverage  = numFramesToAveragex;
	startFrame = startFramex;	
	endFrame = endFramex;
	dilationSteps = dilationStepsx;
	spotRadius = spotRadiusx;
	threshold = thresholdx;
	minimumSeparation = minimumSeparationx;
	minimumSpotWidth = minimumSpotWidthx;
	maximumSpotWidth = maximumSpotWidthx;
	backgroundNoise = backgroundNoisex;
	positiveParticles = positiveParticlesx;
	pixelIntensityCutoff = pixelIntensityCutoffx;
	
	chooseOutputDirectoryUsingOutputFileName();
	
	return 0;
}


int DetectParticlesClass::chooseOutputDirectoryUsingOutputFileName(void)
{
	size_t found;
	
	found = outputFileName.find("/");
	if(found != std::string::npos)
	{
        found = outputFileName.find_last_of("/\\");
		outputDirectory = outputFileName.substr(0,found) + "/";
        
        if (verboseOutput) {
            std::cout << "Detect particles splitting: " << outputFileName << std::endl;
            std::cout << " output folder: " << outputDirectory << std::endl;
            std::cout << " output file: " << outputFileName.substr(found+1) << std::endl;
        }
        
	}
	else {
		outputDirectory = "./";
        if (verboseOutput) {
            std::cout << " output folder: " << outputDirectory << std::endl;
            std::cout << " output file: " << outputFileName.substr(found+1) << std::endl;
        }
        
	}
	return 0;
}


void printDetectedSpots(std::vector<class DetectedSpot> detectedSpots)
{
	std::cout << "Frame	x	y	intensity	width\n";
	unsigned int i;
	for (i = 0; i < detectedSpots.size(); i++) {
		std::cout << detectedSpots.at(i).frame << "	" 
		<< detectedSpots.at(i).xPosition << "	" 
		<< detectedSpots.at(i).yPosition << "	"
		<< detectedSpots.at(i).averagePixelIntensity << "	"
		<< detectedSpots.at(i).spotWidth << "\n";
	}
}


void DetectParticlesClass::clearVariablesForNewDetection(void)
{
	detectedSpots.clear();
}


void DetectParticlesClass::writeDetectedSpotsFile(void)
{
	std::ofstream detectedSpotsFile;
	detectedSpotsFile.open(outputFileName.c_str());		//open a file
	detectedSpotsFile << "%x	y	frame	average pixel intensity	spot width\n";
	
	unsigned long i;
	for (i = 0; i < detectedSpots.size(); i++) {
		detectedSpotsFile 
		<< detectedSpots.at(i).xPosition << "	" 
		<< detectedSpots.at(i).yPosition << "	"
		<< detectedSpots.at(i).frame << "	" 
		<< detectedSpots.at(i).averagePixelIntensity << "	"
		<< detectedSpots.at(i).spotWidth << "\n";
	}
	
	detectedSpotsFile.close();
}


int DetectParticlesClass::copyrightInformation(void)
{
	//Algorithm Author Information
	std::cout	<< "DetectParticlesClass running.\n"
	<< "Note that this program only works with 16 bit TIFF files.\n"
	<< "This algorithm was written by:\n"
	<< "Paul D. Simonson\n"
	<< "Selvin Lab\n"
	<< "Department of Physics\n"
	<< "University of Illinois at Urbana-Champaign\n"
	<< "Copyright 2009-2011\n";
	return 0;
}


int DetectParticlesClass::correctFrameRanges(void)
{
	//std::cout << "startFrame in fixFrameRanges = " << startFrame << "\n";
	
	//Check, and correct if necessary, the start and end frame boundaries.
	if(startFrame > endFrame)
	{
		std::cout << "startFrame > endFrame\n";
		int temp = startFrame;
		startFrame = endFrame;
		endFrame = temp;
	}
	if(startFrame < 0)//Enter -1 for the startFrame to apply it to every frame.
	{
        if (verboseOutput) {
            std::cout << "startFrame = " << startFrame << " < 0\n";
        }
		startFrame = 0;
		endFrame = numFrames - 1;
	}
	if(startFrame > numFrames - 1)
	{
		std::cout << "startFrame > numFrames - 1\n";
		startFrame = endFrame = numFrames - 1;
	}
	if(endFrame > numFrames - 1)
		endFrame = numFrames - 1;
    
	return 0;
}


int DetectParticlesClass::askForDetectionSettings(void)
{
	std::cout << "Please enter number of dilation steps: ";
	std::cin >> dilationSteps;
	if(dilationSteps < 1)
		dilationSteps = 1;	
	std::cout << "You chose " << dilationSteps << "\n";
	
	std::cout << "Please enter spot radius (pixels), minimum is 1: ";
	std::cin >> spotRadius;
	if(spotRadius < 1)
		spotRadius = 1;
	std::cout << "You chose " << spotRadius << "\n";
	
	std::cout << "Please enter pixel intensity threshold value: ";
	std::cin >> threshold;
	std::cout << "You chose " << threshold << "\n";
	
	std::cout << "What is the minimum distance in pixels between spot centers?: ";
	std::cin >> minimumSeparation;
	std::cout << "You chose " << minimumSeparation << "\n";
	
	std::cout << "What is the minimum spot width (pixels)?: ";
	std::cin >> minimumSpotWidth;
	std::cout << "You chose " << minimumSpotWidth << "\n";
	
	std::cout << "What is the maximum spot width (pixels)?: ";
	std::cin >> maximumSpotWidth;
	std::cout << "You chose " << maximumSpotWidth << "\n";
	
	return 0;
}


std::string DetectParticlesClass::formOutputFilePath(std::string simpleFileName)
{
	std::string newFilePath;
	newFilePath = outputDirectory + outputFilePrefix + simpleFileName;
	return newFilePath;
}


double DetectParticlesClass::separationDistanceSquared(double x1, double x2, double y1, double y2)
{
	return pow(x1-x2,2) + pow(y1-y2,2);
}


int DetectParticlesClass::findLocalMaximaUsingImageAndDilatedImageMethod1(int frameNumber, TNT::Array2D<int> imageArray, TNT::Array2D<int> dilatedImageArray)
{
	//xPositionsOfGoodSpotsInCurrentFrame.clear();
	//yPositionsOfGoodSpotsInCurrentFrame.clear();
	
	int width = imageArray.dim1();
	int height = imageArray.dim2();
	
	int x;
//#pragma omp parallel for
	for (x = 0; x < width; x++)
	{
		int y;
		for (y = 0; y < height; y++)
		{
			class DetectedSpot spot;
			
			if(positiveParticles)
			{
				if(dilatedImageArray[x][y] == imageArray[x][y])
				{
					int pixelsCounted = 0;
					double backgroundSubtractedAveragedSpotIntensity = oneSpotAverageIntensity(imageArray, (double)x, (double)y, spotRadius, backgroundRingWidth, &pixelsCounted);
					if(backgroundSubtractedAveragedSpotIntensity >= threshold)
					{
						spot.frame = frameNumber;
						spot.xPosition = x;
						spot.yPosition = y;
						spot.averagePixelIntensity = backgroundSubtractedAveragedSpotIntensity;
						spot.numPixelsAveraged = pixelsCounted;
//#pragma omp critical
						{
							detectedSpots.push_back(spot);
                        }
                        
					}
				}
			}
			else
			{
				if(dilatedImageArray[x][y] == imageArray[x][y])
				{
					int pixelsCounted = 0;
					double backgroundSubtractedAveragedSpotIntensity = oneSpotAverageIntensity(imageArray, (double)x, (double)y, spotRadius, backgroundRingWidth, &pixelsCounted);
					if(backgroundSubtractedAveragedSpotIntensity <= -threshold)
					{
						spot.frame = frameNumber;
						spot.xPosition = x;
						spot.yPosition = y;
						spot.averagePixelIntensity = backgroundSubtractedAveragedSpotIntensity;
						spot.numPixelsAveraged = pixelsCounted;
//#pragma omp critical
						{
							detectedSpots.push_back(spot);
						}
					}
				}
			}
		}
	}
	
	return 0;
}


int DetectParticlesClass::findLocalMaximaUsingImageAndDilatedImageMethod2(int frameNumber, TNT::Array2D<int> imageArray, TNT::Array2D<int> dilatedImageArray)
{	
	int width = imageArray.dim1();
	int height = imageArray.dim2();
	
	int x;
    //#pragma omp parallel for
	for (x = 0; x < width; x++)
	{
		int y;
		for (y = 0; y < height; y++)
		{
			class DetectedSpot spot;
			
			if(positiveParticles)
			{
				if(dilatedImageArray[x][y] == imageArray[x][y])
				{
					int pixelsCounted = 0;
					double backgroundSubtractedAveragedSpotIntensity = oneSpotAverageIntensity(imageArray, (double)x, (double)y, spotRadius, 0, &pixelsCounted);
					if(backgroundSubtractedAveragedSpotIntensity >= threshold)
					{
						spot.frame = frameNumber;
						spot.xPosition = x;
						spot.yPosition = y;
						spot.averagePixelIntensity = backgroundSubtractedAveragedSpotIntensity;
						spot.numPixelsAveraged = pixelsCounted;
                        //#pragma omp critical
						{
							detectedSpots.push_back(spot);
                        }
                        
					}
				}
			}
			else
			{
				if(dilatedImageArray[x][y] == imageArray[x][y])
				{
					int pixelsCounted = 0;
					double backgroundSubtractedAveragedSpotIntensity = oneSpotAverageIntensity(imageArray, (double)x, (double)y, spotRadius, 0, &pixelsCounted);
					if(backgroundSubtractedAveragedSpotIntensity <= -threshold)
					{
						spot.frame = frameNumber;
						spot.xPosition = x;
						spot.yPosition = y;
						spot.averagePixelIntensity = backgroundSubtractedAveragedSpotIntensity;
						spot.numPixelsAveraged = pixelsCounted;
                        //#pragma omp critical
						{
							detectedSpots.push_back(spot);
						}
					}
				}
			}
		}
	}
	
	return 0;
}


int DetectParticlesClass::applyPixelIntensityCutoff(TNT::Array2D< int > &imageArray)
{
	int x;
   // #pragma omp parallel for
	for (x = 0; x < width; x++)
	{
		int y;
		for (y = 0; y < height; y++)
		{
			if(positiveParticles)
			{
				if(imageArray[x][y] < pixelIntensityCutoff)
					imageArray[x][y] = pixelIntensityCutoff;
			}
			else 
			{
				if(imageArray[x][y] > pixelIntensityCutoff)
					imageArray[x][y] = pixelIntensityCutoff;
			}
		}
	}
	return 0;
}


int DetectParticlesClass::subtractPixelIntensityCutoff(TNT::Array2D< int > &imageArray)
{
	int x;
    // #pragma omp parallel for
	for (x = 0; x < width; x++)
	{
		int y;
		for (y = 0; y < height; y++)
		{
            imageArray[x][y] -= pixelIntensityCutoff;
        }
	}
	return 0;
}


int DetectParticlesClass::writeDetectionSettings(void)
{
	std::ofstream detectionSettingsFile;
	detectionSettingsFile.open(formOutputFilePath("detectionSettingsFile.txt").c_str());		//open a file
	detectionSettingsFile	
    << "%inputFileName:\n" << inputFileName << "\n"
    << "%outputFileName:\n" << outputFileName << "\n"
    << "%numFramesToAverage:\n" << numFramesToAverage << "\n"
    << "%startFrame:\n" << startFrame << "\n"
    << "%endFrame:\n" << endFrame << "\n"
    << "%Number of dilation steps:\n" << dilationSteps << "\n"
    << "%Spot radius:\n" << spotRadius << "\n"
    << "%Intensity threshold:\n" << threshold << "\n"
    << "%Minimum spot separation:\n" << minimumSeparation << "\n"
    << "%Minimum spot width:\n" << minimumSpotWidth << "\n"
    << "%Maximum spot width:\n" << maximumSpotWidth << "\n"
    << "%backgroundNoise:\n" << backgroundNoise << "\n"
    << "%positiveParticles:\n" << positiveParticles << "\n"
    << "%pixelIntensityCutoff:\n" << pixelIntensityCutoff << "\n";
	detectionSettingsFile.close();
	return 0;
}

/*
void DetectParticlesClass::createDetectedSpotsTIFF(FIMULTIBITMAP *multibitmap)
{
	int numFrames = FreeImage_GetPageCount(multibitmap);
	
	TNT::Array2D< int > imageArray;
	imageArray = return2DIntArrayFromMultiBitmap(multibitmap, 1);
	width = imageArray.dim1();
	height = imageArray.dim2();
	
	
	std::vector< TNT::Array2D<double> > spotsDetectedImagesList(numFrames);
	
	int i;
	//#pragma omp parallel for
	for(i = 0; i < numFrames; i++)
	{
		TNT::Array2D<double> pixelsUsedInCalculatingFluorescence(width, height, (double)0.0);
        
		unsigned int j;
		for (j = 0; j < detectedSpots.size(); j++) 
		{
			if (i + 1 == (int)(detectedSpots.at(j).frame)) {
				int x;
				for (x = 0; x < width; x++)
				{
					int y;
					for (y = 0; y < height; y++)
						if(	pow((x - detectedSpots.at(j).xPosition), 2) + pow((y - detectedSpots.at(j).yPosition), 2) <= spotRadius * spotRadius &&
						   x >= 0 &&
						   y >= 0 &&
						   x < width &&
						   y < height)
						{
							pixelsUsedInCalculatingFluorescence[x][y] = imageArray[x][y];
						}
				}
			}
		}
		spotsDetectedImagesList.at(i) = pixelsUsedInCalculatingFluorescence;
	}
    
	if(positiveParticles)
	{
		SimonsonLibTIFF_IO::writeTIFFStack<double>(formOutputFilePath("detectedSpots.tif"), spotsDetectedImagesList);	
	}
	else
	{
		SimonsonLibTIFF_IO::writeTIFFStack<double>(formOutputFilePath("detectedAntiSpots.tif"), spotsDetectedImagesList);	
	}
}
*/

void DetectParticlesClass::createDetectedSpotsTIFF(std::vector< TNT::Array2D< int > > &imageVector)
{
	int numFrames = imageVector.size();
	
	TNT::Array2D< int > imageArray;
	imageArray = imageVector.at(0);
	width = imageArray.dim1();
	height = imageArray.dim2();
	
	
	std::vector< TNT::Array2D<double> > spotsDetectedImagesList(numFrames);
	
	int i;
    //#pragma omp parallel for
	for(i = 0; i < numFrames; i++)
	{
		TNT::Array2D<double> pixelsUsedInCalculatingFluorescence(width, height, (double)0.0);
        
		unsigned int j;
		for (j = 0; j < detectedSpots.size(); j++) 
		{
			if (i + 1 == (int)(detectedSpots.at(j).frame)) {
				int x;
				for (x = 0; x < width; x++)
				{
					int y;
					for (y = 0; y < height; y++)
						if(	pow((x - detectedSpots.at(j).xPosition), 2) + pow((y - detectedSpots.at(j).yPosition), 2) <= spotRadius * spotRadius &&
						   x >= 0 &&
						   y >= 0 &&
						   x < width &&
						   y < height)
						{
							//pixelsUsedInCalculatingFluorescence[x][y] = imageArray[x][y];
                            pixelsUsedInCalculatingFluorescence[x][y] = 1;
						}
				}
			}
		}
		spotsDetectedImagesList.at(i) = pixelsUsedInCalculatingFluorescence;
	}
    
	if(positiveParticles)
	{
		SimonsonLibTIFF_IO::writeTIFFStack<double>(formOutputFilePath("detectedSpots.tif"), spotsDetectedImagesList);	
	}
	else
	{
		SimonsonLibTIFF_IO::writeTIFFStack<double>(formOutputFilePath("detectedAntiSpots.tif"), spotsDetectedImagesList);	
	}
}


void DetectParticlesClass::writeSpotsPerFrameFile(unsigned int numFrames)
{
	//Set up output text files
	std::ofstream spotsPerFrameFile;
	if(positiveParticles)
	{
		spotsPerFrameFile.open(formOutputFilePath(spotsPerFrameFileName).c_str());		//open a file
	}
	else
	{
		spotsPerFrameFile.open(formOutputFilePath("antiSpotsPerFrame.txt").c_str());		//open a file
	}
	spotsPerFrameFile << "%%frame	spots\n";
	
	unsigned int i;
    
	for (i = 0; i < numFrames; i++) {
		spotsPerFrameFile << i + 1 << "	";
		
		unsigned int spotsDetectedInCurrentFrame = 0;
		unsigned int j;
		for (j = 0; j<detectedSpots.size(); j++) {
			if (detectedSpots.at(j).frame == i + 1) {
				spotsDetectedInCurrentFrame++;
			}
		}
		spotsPerFrameFile << spotsDetectedInCurrentFrame << "\n";
	}
	
	spotsPerFrameFile.close();
}

