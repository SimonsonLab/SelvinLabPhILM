/*
 *  dataFileReader.cpp
 *  RotationTracker
 *
 *  Created by Paul Simonson on 10/3/07.  Modified by Paul Simonson on 9.26.2008.
 *  Copyright 2007 __MyCompanyName__. All rights reserved.
 *
 */

//May 12, 2009: Now it can see whitespace at the beginning of a line.
//April 23, 2010: Now it can count words in very long lines.

#include "dataFileReader.h"

#include <iostream>
using std::cerr;
using std::cout;
using std::endl;
#include <fstream>
using std::ifstream;
#include <cstdlib> // for exit function
#include <iomanip>   // format manipulation
#include <string>

//#define USING_DEBUGGING


// This program reads values from the tab- or space-delimited file of your choice.

//int countNumberOfRows(ifstream &dataFile);
int countNumberOfColumns(ifstream &dataFile, const char *cpath);
int wordCount(const char *strPtr);

std::vector< std::vector<double> > dataFileReader(const char *cpath) 
{
	int lineCount = 0;
	
	//std::cout << "Now parsing: " << cpath << "\n";
	ifstream dataFile; // indata is like cin
	dataFile.open(cpath); // opens the file
	if(!dataFile) { // file couldn't be opened
		cerr << "Error: " << cpath << " could not be opened.\n" << endl;
		exit(1);
	}
	
	int columnCount = countNumberOfColumns(dataFile, cpath);
	#ifdef USING_DEBUGGING
		std::cout << "Number of columns is " << columnCount << ".\n";
	#endif
	int rowCount = 0;
	std::vector< std::vector<double> > parsedData;
	if(columnCount > 0) {
		do { // keep reading until end-of-file
			int i;
			
			std::string lineString;
			
			char c;
			std::vector<double> rowOfData(columnCount);
			for(i = 0; i < columnCount; i++)
			{
				while((c = dataFile.peek()) == '#')//move down until the first character of the line is not #
				{
#ifdef USING_DEBUGGING
					std::cout << "The peek character of the line is " << c << " = " << (int)c << ".\n";
#endif
					std::getline(dataFile, lineString);	
					lineCount++;
				}
				while((c = dataFile.peek()) == '%')//move down until the first character of the line is not #
				{
#ifdef USING_DEBUGGING
					std::cout << "The peek character of the line is " << c << "\n";
#endif
					std::getline(dataFile, lineString);	
					lineCount++;
				}

#ifdef USING_DEBUGGING
				std::cout << "The first character of line " << lineCount << " is " << c << " = " << (int)c << ".\n";
#endif
				//indata >> rowOfData.at(i);
				//Do the following to handle scientific format numbers in the file:
				std::string nextString;
				dataFile >> nextString;
				//rowOfData.at(i) = strtod(nextString.c_str());
				rowOfData.at(i) = strtod(nextString.c_str(), NULL);

			}
			if( !dataFile.eof())
			{
				std::getline(dataFile, lineString);	
				lineCount++;

				parsedData.push_back(rowOfData);
				rowCount++;
			}
		} while ( !dataFile.eof());
		//cout << "End-of-file reached." << endl;	
	}
	dataFile.close();
	return parsedData;
}


int countNumberOfColumns(ifstream &dataFile, const char *cpath)
{
	//char line[2000];
	std::string lineString;
	
	int count;
	if (dataFile.is_open())
	{
		while(dataFile.peek() == '#')//move down until the first character of the line is not #
			std::getline(dataFile, lineString);	
		while(dataFile.peek() == '%')//move down until the first character of the line is not #
			std::getline(dataFile, lineString);	
		if (! dataFile.eof() )
		{
			std::getline(dataFile, lineString);	
			count = wordCount(lineString.c_str());
			#ifdef USING_DEBUGGING
				cout << "First non-comment line of the file is: " << lineString << endl;
				cout << "Number of columns is guessed to be: " << count << endl;
			#endif
		}
		else {
			cout << "The data file " << cpath << " appears to be empty.\n";
			return -1;
		}
	}
	else {
		cout << "Error in countNumberOfColumns function: file was at eof.\n";
		return -1;
	} 
	dataFile.clear();              // forget we hit the end of file
	dataFile.seekg(0, std::ios::beg);   // move to the start of the file
	return count;
}


int wordCount(const char *strPtr) 
{ 
	int index = 1; 
	
#ifdef USING_DEBUGGING
	//std::cout << "strPtr is " << strPtr << "\n";
#endif
	
	//Skip over whitespace at the beginning of the line.
	while (*strPtr == ' ' || *strPtr == '	') {
		strPtr++;
	}
	
#ifdef USING_DEBUGGING
	//std::cout << "strPtr is " << strPtr << " after skipping over white space at beginning of the line.\n";
#endif
		
	while((*strPtr != '\0'))// && (*strPtr != '\n'))//  && (*strPtr != '\r')) 
	//while((*strPtr != '\0') || (*strPtr != '\n') || (*strPtr != '\r')) 
	{ 
		if(*strPtr == ' ' || *strPtr == '	') 
		{
			index++; 
			
			//Skip extra white space:
			/*
			while((*strPtr != '\0'))
			{
				if(*strPtr == ' ' || *strPtr == '	') 
				{
					strPtr++;
				}
				else {
					break;
				}
			}
			 */
		}
		strPtr++;
		
		
#ifdef USING_DEBUGGING
		//std::cout << "strPtr is " << strPtr << "\n";
#endif
		
	}
	strPtr--;//Check to see whether the last character was a space or tab
	if(*strPtr == ' ' || *strPtr == '	')
		index--;
#ifdef USING_DEBUGGING
	std::cout << "word count index is " << index << "\n";
#endif
	return index;
}

void displayParsedFile(std::vector< std::vector<double> > parsedFile)
{
	//Display the file's data
	int rowCount, columnCount;
	rowCount = (int)parsedFile.size();
	columnCount = (int)(parsedFile[0]).size();
	cout << "The matrix is " << rowCount << " x " << columnCount << endl;
	int i, j;
	for (i = 0; i < rowCount; i++){
		for(j = 0; j < columnCount; j++){
			cout << parsedFile[i][j] << "	";
		}
		cout << endl;
	}
}
