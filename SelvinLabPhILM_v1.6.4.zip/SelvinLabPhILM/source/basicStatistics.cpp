/*
 *  basicStatistics.cpp
 *  RotationTracker
 *
 *  Created by Paul Simonson on 2/22/08.
 *  Copyright 2008 __MyCompanyName__. All rights reserved.
 *
 */

#include "basicStatistics.h"
#include <cmath>
#include <iomanip>   // format manipulation
#include <algorithm>

namespace BasicStatistics {
	
	double returnMean(const std::vector<double> &x)
	{
		unsigned long numElements = x.size();
		double sum = 0.0L;
		unsigned long i;
		for(i = 0; i < numElements; i++)
			sum += x.at(i);
		return sum/(double)numElements;
	}
	
	
	double returnMedian(const std::vector<double> &x)
	{
		std::vector<double> tempX = x;
		std::sort(tempX.begin(), tempX.end());//sort the vector
		return tempX.at(tempX.size()/2.0);
	}
	
	double returnStandardDeviation(const std::vector<double> &x)
	{
		double mean = returnMean(x);
		
		unsigned long numElements = x.size();
		double sum = 0.0L;
		unsigned long i;
		double divisor = (1.0L/((double)numElements - 1.0L));
		for(i = 0; i < numElements; i++)
			sum += pow(x.at(i) - mean, 2);
		return sqrt(divisor*sum);
	}
	
	double returnStandardDeviation(const std::vector<double> &x, const double mean)
	{	
		unsigned long numElements = x.size();
		double sum = 0.0L;
		unsigned long i;
		double divisor = (1.0L/((double)numElements - 1.0L));
		for(i = 0; i < numElements; i++)
			sum += divisor*pow(x.at(i) - mean, 2);
		return sqrt(sum);
	}
	
	double returnSampleStandardDeviation(const std::vector<double> &x)
	{
		double mean = returnMean(x);
		
		unsigned long numElements = x.size();
		double sum = 0.0L;
		unsigned long i;
		double divisor = (1.0L/((double)numElements - 1.0L));
		for(i = 0; i < numElements; i++)
			sum += pow(x.at(i) - mean, 2);
		return sqrt(divisor*sum);
	}
	
	double returnSampleStandardErrorOfTheMean(const std::vector<double> &x)
	{
		return returnSampleStandardDeviation(x)/sqrt(x.size());
	}

	std::vector<double> calculateStandardDeviationAsAFuntionOfTime(const std::vector<double> &x)
	{
		std::vector<double> outputFunction;
		
		short order = x.size();
		
		std::vector<double> tempX;
		tempX.assign(x.begin(), x.end());
		
		std::vector<double> standardDeviation(order-1);
		
		int i;
		for(i = order - 2; i > -1; i--)
		{
			standardDeviation.at(i) = returnStandardDeviation(tempX);
			tempX.pop_back();
		}
		
		return standardDeviation;
	}
	
	std::vector<std::vector<double> > calculateStandardDeviationAsAFuntionOfTime(const std::vector<double> &t, const std::vector<double> &x)
	{
		std::vector<std::vector<double> > outputFunction;
		
		short order = t.size();
		std::vector<double> timeColumn;
		timeColumn.assign((t.begin())++, t.end());
		
		std::vector<double> tempX;
		tempX.assign(x.begin(), t.end());
		
		std::vector<double> standardDeviation(order-1);
				
		int i;
		for(i = order - 2; i > -1; i--)
		{
			standardDeviation.at(i) = returnStandardDeviation(tempX);
			tempX.pop_back();
		}
		
		outputFunction.push_back(timeColumn);
		outputFunction.push_back(standardDeviation);
		
		return outputFunction;
	}
}
