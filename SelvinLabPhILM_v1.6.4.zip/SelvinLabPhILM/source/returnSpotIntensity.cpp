/*
 *  returnSpotIntensity.cpp
 *  PositionAndFluorescenceTracker
 *
 *  Created by Paul Simonson on 5/6/09.
 *  Copyright 2009 University of Illinois at Urbana-Champaign. All rights reserved.
 *
 */

#include <algorithm>
#include <vector>

#include "returnSpotIntensity.h"
#include "tnt.h"
#include "return2DArrayFromMultiBitmap.h"

const double fractionOfBackgroundSpotsToUse = 0.66;


double oneSpotAverageIntensity(TNT::Array2D< int > imageArray, double spotCenterX, double spotCenterY, double spotRadius, double backgroundRingWidth, int *pixelsCounted)
{
	double spotRadiusSquared = pow(spotRadius, 2);
	double spotRadiusPlusBackgroundRingWidthSquared = pow(spotRadius + backgroundRingWidth, 2);
	
	int width, height;
	width = imageArray.dim1();
	height = imageArray.dim2();
	
	double backgroundPerPixel = 0.0L;
	int numBackgroundPixelsSummed = 0;
	
	int numPixelsSummed = 0;
	double totalIntensity = 0.0L;
	
	//Set the x-y pixel ranges (so you do not have to scan through the whole image).
	int minXRange =  spotCenterX - (spotRadius + backgroundRingWidth + 1);
	if(minXRange < 0)
		minXRange = 0;
	
	int minYRange =  spotCenterY - (spotRadius + backgroundRingWidth + 1);
	if(minYRange < 0)
		minYRange = 0;	
	
	int maxXRange =  spotCenterX + (spotRadius + backgroundRingWidth + 1);
	if(maxXRange > width)
		maxXRange = width;
	
	int maxYRange =  spotCenterY + (spotRadius + backgroundRingWidth + 1);
	if(maxYRange > height)
		maxYRange = height;
	
	int x, y;
	for (x = minXRange; x < maxXRange; x++)
		for (y = minYRange; y < maxYRange; y++)
		{
			double distanceFromCenterSquared = pow((x - spotCenterX), 2) + pow((y - spotCenterY), 2);
			//Intensity
			if(distanceFromCenterSquared <= spotRadiusSquared)
			{
				numPixelsSummed++;
				totalIntensity += (double)(imageArray[x][y]);
			}
			
			//Auto-Detect Background
			if(backgroundRingWidth > 0)
				if(distanceFromCenterSquared > spotRadiusSquared) //greater than spot radius
				   if(distanceFromCenterSquared <= spotRadiusPlusBackgroundRingWidthSquared)
					{
						numBackgroundPixelsSummed++;
						backgroundPerPixel += (double)(imageArray[x][y]);
					}
		}
	
	if(numBackgroundPixelsSummed > 0)
		backgroundPerPixel = backgroundPerPixel/(double)numBackgroundPixelsSummed;
	double averagedIntensity = totalIntensity/(double)numPixelsSummed - backgroundPerPixel;
	*pixelsCounted = numPixelsSummed;
	return averagedIntensity;
}

//Frame number counting system starts with ZERO.
double oneSpotAverageIntensity(FIMULTIBITMAP *multibitmap, int frameNumber, double spotCenterX, double spotCenterY, double spotRadius, double backgroundRingWidth, int *pixelsCounted)
{
	TNT::Array2D< int > imageArray = Return2DArray::return2DIntArrayFromMultiBitmap(multibitmap, frameNumber + 1);
	return oneSpotAverageIntensity(imageArray, spotCenterX, spotCenterY, spotRadius, backgroundRingWidth, pixelsCounted);
}

//Frame number counting system starts with ZERO.
double oneSpotAverageIntensityNoBackgroundSubtraction(FIMULTIBITMAP *multibitmap, int frameNumber, double spotCenterX, double spotCenterY, double spotRadius, int *pixelsCounted)
{
	return oneSpotAverageIntensity(multibitmap, frameNumber,  spotCenterX,  spotCenterY, spotRadius, 0, pixelsCounted);
}


double chooseBackgroundIntensityValueForMethod2(std::vector<double> pixelIntensities)
{
	if (!pixelIntensities.size()) {
		return 0;
	}
	
	int numValuesToUse = fractionOfBackgroundSpotsToUse * pixelIntensities.size() + 1;
	
	sort(pixelIntensities.begin(), pixelIntensities.end());
	
	double backgroundIntensityValue = 0;
	int i;
	for (i = 0; i < numValuesToUse; i++) {
		backgroundIntensityValue += pixelIntensities.at(i);
	}
	
	return backgroundIntensityValue/(double)numValuesToUse;
}


double oneSpotAverageIntensityMethod2(TNT::Array2D< int > imageArray, double spotCenterX, double spotCenterY, double spotRadius, double backgroundRingWidth, int *pixelsCounted)
{
	double spotRadiusSquared = pow(spotRadius, 2);
	double spotRadiusPlusBackgroundRingWidthSquared = pow(spotRadius + backgroundRingWidth, 2);
	
	int width, height;
	width = imageArray.dim1();
	height = imageArray.dim2();
	
	double backgroundPerPixel = 0.0L;
	//int numBackgroundPixelsSummed = 0;
	
	int numPixelsSummed = 0;
	double totalIntensity = 0.0L;
	
	//Set the x-y pixel ranges (so you do not have to scan through the whole image).
	int minXRange =  spotCenterX - (spotRadius + backgroundRingWidth + 1);
	if(minXRange < 0)
		minXRange = 0;
	
	int minYRange =  spotCenterY - (spotRadius + backgroundRingWidth + 1);
	if(minYRange < 0)
		minYRange = 0;	
	
	int maxXRange =  spotCenterX + (spotRadius + backgroundRingWidth + 1);
	if(maxXRange > width)
		maxXRange = width;
	
	int maxYRange =  spotCenterY + (spotRadius + backgroundRingWidth + 1);
	if(maxYRange > height)
		maxYRange = height;
	
	std::vector<double> backgroundPixelIntensities;
	
	int x, y;
	for (x = minXRange; x < maxXRange; x++)
		for (y = minYRange; y < maxYRange; y++)
		{
			double distanceFromCenterSquared = pow((x - spotCenterX), 2) + pow((y - spotCenterY), 2);
			//Intensity
			if(distanceFromCenterSquared <= spotRadiusSquared)
			{
				numPixelsSummed++;
				totalIntensity += (double)(imageArray[x][y]);
			}
			
			//Auto-Detect Background
			if(backgroundRingWidth > 0)
				if(distanceFromCenterSquared > spotRadiusSquared) //greater than spot radius
					if(distanceFromCenterSquared <= spotRadiusPlusBackgroundRingWidthSquared)
					{
						//numBackgroundPixelsSummed++;
						//backgroundPerPixel += (double)(imageArray[x][y]);
						
						backgroundPixelIntensities.push_back(imageArray[x][y]);
					}
		}
	
	//if(numBackgroundPixelsSummed > 0)
	//	backgroundPerPixel = backgroundPerPixel/(double)numBackgroundPixelsSummed;
	
	
	backgroundPerPixel = chooseBackgroundIntensityValueForMethod2(backgroundPixelIntensities);
	double averagedIntensity = totalIntensity/(double)numPixelsSummed - backgroundPerPixel;
	*pixelsCounted = numPixelsSummed;
	
	return averagedIntensity;
}

//Frame number counting system starts with ONE.
double oneSpotAverageIntensityMethod2(FIMULTIBITMAP *multibitmap, int frameNumber, double spotCenterX, double spotCenterY, double spotRadius, double backgroundRingWidth, int *pixelsCounted)
{
	TNT::Array2D< int > imageArray = Return2DArray::return2DIntArrayFromMultiBitmap(multibitmap, frameNumber);
	return oneSpotAverageIntensityMethod2(imageArray, spotCenterX, spotCenterY, spotRadius, backgroundRingWidth, pixelsCounted);
}

