/*
 *  PhILMMicrotubuleExtras.cpp
 *  
 *
 *  Created by Paul Simonson on 2/7/11.
 *  Copyright 2011 Champaign Illinois Stake. All rights reserved.
 *
 */

#include "PhILMMicrotubuleExtras.h"

#include <cstring>
#include <vector>
#include <iostream>
#include <fstream>
#include <list>
#include <cmath>

//#include "Magick++.h"
#include "writeTIFFFileUsingMagick.h"
#include "PhILMCoreCode.h"
#include "return2DArrayFromMultiBitmap.h"
#include "ScienceFile.h"
#include "tiffStackOperations.h"
#include "tiffFrameOperations.h"
#include "returnSpotIntensity.h"
//#include "fitTo2DGaussianUsingGSL.h"
#include "fitTo2DEllipticalGaussian.h"
#include "tiffFrameOperations.h"
#include "basicStatistics.h"
#include "FreeImage.h"
#include "returnDataForGaussianFitting.h"


using namespace Fitting2DEllipticalGaussianUsingGSL;

#define RESTRICTING_FRAME_RANGES


extern PhILMPreferences thePhILMPreferences;
extern const int newPixelOffset;
const double pixelShiftForDrawingSuperResolutionImages = 0.5;

namespace PhILM_namespace 
{	

	std::vector<double> rotateCoordinates(double x, double y, double rotationAngle)
	{
		double rotationMatrix[2][2];
		rotationMatrix[0][0] = cos(rotationAngle);
		rotationMatrix[0][1] = -sin(rotationAngle);
		rotationMatrix[1][0] = sin(rotationAngle);
		rotationMatrix[1][1] = cos(rotationAngle);
		
		std::vector<double> newCoordinates;
		newCoordinates.push_back(rotationMatrix[0][0] * x + rotationMatrix[0][1] * y);
		newCoordinates.push_back(rotationMatrix[1][0] * x + rotationMatrix[1][1] * y);
		
		return newCoordinates;
	}
	
	
	int rotateShrimpFitsFile(const char *inputFileName, const char *outputFileName, double rotationAngle, double yIntercept)
	{
		ScienceFile shrimpFitsFile(inputFileName);
		int numSpots = shrimpFitsFile.numRows();
		int i;
		for(i = 0; i < numSpots; i++)
		{
			double x = shrimpFitsFile.at(i, 1);
			double y = shrimpFitsFile.at(i, 2) - yIntercept;
			std::vector<double> newCoordinates = rotateCoordinates(x, y, rotationAngle);
			shrimpFitsFile.setElement(i, 1, newCoordinates.at(0));
			shrimpFitsFile.setElement(i, 2, newCoordinates.at(1));
		}
		shrimpFitsFile.writeToFile(outputFileName);
		return 0;
	}
	
	
	//From "An Introduction to Error Analysis" by John R. Taylor, 2nd Edition, page 184.
	std::vector<double> fitDataToStraightLine(std::vector<double> x0s, std::vector<double> y0s)
	{
		std::vector<double> lineFit;
		
		double sumX = 0;
		double sumY = 0;
		double sumXSquared = 0;
		double sumXY = 0;
		
		int numPoints = x0s.size();
		int i;
		for(i = 0; i < numPoints; i++)
		{
			sumX += x0s.at(i);
			sumY += y0s.at(i);
			sumXSquared += pow(x0s.at(i), 2);
			sumXY += x0s.at(i) * y0s.at(i);
		}
		
		double delta = numPoints * sumXSquared - pow(sumX, 2);
		double oneOverDelta = 1.0L/delta;
		
		double B = oneOverDelta * (sumXSquared * sumY - sumX * sumXY);
		double A = oneOverDelta * (numPoints * sumXY - sumX * sumY);
		
		std::cout << "Line fit: slope = " << A << ", intercept = " << B << "\n";
		
		lineFit.push_back(A);
		lineFit.push_back(B);
		return lineFit;
	}
	
	
	int concatenateShrimpFitsFiles(const char* firstFile, const char * secondFile, const char * outputFile)
	{
		ScienceFile file1(firstFile);
		ScienceFile file2(secondFile);
		
		int lastFrameInFile1 = ScienceFile::findMax(file1.returnColumn(16));
		
		std::cout << "The last frame in file 1 is " << lastFrameInFile1 << ".\n";
		
		int numRowsInFile2 = file2.numRows();
		
		int i;
		
		for(i = 0; i < numRowsInFile2; i++)
		{
			file2.setElement(i, 14, file2.at(i,14) + lastFrameInFile1);
			file2.setElement(i, 15, file2.at(i,15) + lastFrameInFile1);
			file2.setElement(i, 16, file2.at(i,16) + lastFrameInFile1);
			
			file1.addRow(file2.returnRow(i));
		}
		
		file1.writeToFile(outputFile, "%%peakHeight	x0	y0	xWidth	yWidth	background	tiltAngle	peakHeightError	x0Error	y0Error	xWidthError	yWidthError	backgroundError tiltAngleError");
		
		return 0;
	}
	
	
	int createDriftCorrectedSpotFitsFile(const char *driftCorrectionFileName, const char *spotFitsFileName, const char *outputFileName)
	{
		const int frameWherePhotobleachingOccursColumn = 15;
		const int x0Column = 1;
		const int y0Column = 2;
		
		ScienceFile stageDriftCorrectionFile(driftCorrectionFileName);
		ScienceFile spotFitsFile(spotFitsFileName);
		
		double driftOriginX = stageDriftCorrectionFile.at(0, 1);
		double driftOriginY = stageDriftCorrectionFile.at(0, 2);
		
		int numSpotFits = spotFitsFile.numRows();
		int i;
		for (i = 0; i < numSpotFits; i++) 
		{
			//std::cout << "i = " << i << "\n";
			int frameOfTheGivenSpot = spotFitsFile.at(i, frameWherePhotobleachingOccursColumn) - 1;
			
			double xCorrection = driftOriginX - stageDriftCorrectionFile.at(frameOfTheGivenSpot, 1);
			double yCorrection = driftOriginY - stageDriftCorrectionFile.at(frameOfTheGivenSpot, 2);
			
			//std::cout << "Drift correcting spot" << i + 1 << ", frameOfTheGivenSpot = " << frameOfTheGivenSpot << ", " << xCorrection << "	" << yCorrection << "\n";
			
			//std::cout << "This far...\n";
			double newX = xCorrection + spotFitsFile.at(i, x0Column);
			double newY = yCorrection + spotFitsFile.at(i, y0Column);
			
			spotFitsFile.setElement(i, x0Column, newX);
			spotFitsFile.setElement(i, y0Column, newY);
		}
		
		spotFitsFile.writeToFile(outputFileName);
		std::cout << "Created " << outputFileName << ".\n";
		
		return 0;
	}
	
	
	int MicrotubuleLineFit::convertFitXToOutputX(int fitX)
	{
		return superResolutionZoomFactor * (fitX + pixelShiftForDrawingSuperResolutionImages);
	}
	
	
	int MicrotubuleLineFit::convertFitYToOutputY(int fitY, int height)
	{
		return superResolutionZoomFactor * (height - 1 - fitY + pixelShiftForDrawingSuperResolutionImages);
	}
	
	
	void MicrotubuleLineFit::drawLineFitInSuperResolutionImage(void)
	{
		outputImage.read(formOutputFilePath("superResolutionImage.pixels.tif").c_str());
		outputImage.normalize();
		
		// Set draw options
		outputImage.strokeColor("red"); // Outline color
		outputImage.strokeWidth(1);
		
		//Draw the line
		
		if(checkWhetherFileIsPresent((tiffFileName).c_str()))
		{
			std::cout << "Tiff file " << (tiffFileName) << " is present.\a\n";
		}
		else {
			std::cout << "Tiff file " << (tiffFileName) << " is not present.\a\a\n";
		}
		
		Magick::Image originalImage(tiffFileName);
		
		std::cout << "This far..." << std::endl;
		
		superResolutionZoomFactor = (double)outputImage.rows()/(double)originalImage.rows();
		int rows, columns;
		columns = originalImage.columns();
		rows = originalImage.rows();
		int startX, startY, endX, endY;
		
		//y = mx + B
		double m = lineFit.at(0);
		double B = lineFit.at(1);
		
		if (B >= 0 && B < rows) {
			startX = 0;
			endX = columns - 1;
			startY = B;
			endY = m*(columns - 1) + B;
		}
		else {
			startY = 0;
			endY = rows - 1;
			startX = (startY-B)/m;
			endX = (endY - B)/m;
		}
		
		startX = convertFitXToOutputX(startX);
		endX = convertFitXToOutputX(endX);
		startY = convertFitYToOutputY(startY, rows);
		endY = convertFitYToOutputY(endY, rows);
		
		std::cout	<< startX << "	"
		<< endX << "	"
		<< startY << "	"
		<< endY << "\n";
		
		outputImage.draw(Magick::DrawableLine(startX,startY,endX,endY));
		
		calculationDone = 1;
		
		outputImage.display();
	}
	
	
    
#include <fstream>
    
#include <gsl/gsl_blas.h>
    
#include "ScienceFile.h"
#include "tiffFrameOperations.h"
#include "returnDataForGaussianFitting.h"
    
    
    int MicrotubuleFit::checkWhetherFileIsPresent(const char *cpath)
    {
        std::ifstream file; // indata is like cin
        file.open(cpath); // opens the file
        if(!file) { // file couldn't be opened
            return 0;
        }
        else
        {
            file.close();
            return 1;
        }
    }
    
    
    
    ///The following are for drawing the output image.
    int MicrotubuleFit::convertFitXToOutputX(int fitX)
    {
        return superResolutionZoomFactor * (fitX + pixelShiftForDrawingSuperResolutionImages);
    }
    
    
    int MicrotubuleFit::convertFitYToOutputY(int fitY, int height)
    {
        return superResolutionZoomFactor * (height - 1 - fitY + pixelShiftForDrawingSuperResolutionImages);
    }
    
    
    int MicrotubuleFit::drawLineFitInImage(void)
    {
        if(!doneFitting)
        {
            std::cout << "The microtubule image must be fit before the fit line can be drawn.\n";
            return -1;
        }
        
        outputImage.read(tiffFileName.c_str());
        outputImage.normalize();
        
        // Set draw options
        outputImage.strokeColor(lineColor); // Outline color
        outputImage.strokeWidth(1);
        
        //Draw the line
        Magick::Image originalImage(tiffFileName);
        
        //std::cout << "This far..." << std::endl;
        
        superResolutionZoomFactor = (double)outputImage.rows()/(double)originalImage.rows();
        int rows, columns;
        columns = originalImage.columns();
        rows = originalImage.rows();
        int startX, startY, endX, endY;
        
        //y = mx + B
        double m = lineFit.at(0);
        double B = lineFit.at(1);
        
        if (B >= 0 && B < rows) {
            startX = 0;
            endX = columns - 1;
            startY = B;
            endY = m*(columns - 1) + B;
        }
        else {
            startY = 0;
            endY = rows - 1;
            startX = (startY-B)/m;
            endX = (endY - B)/m;
        }
        
        startX = convertFitXToOutputX(startX);
        endX = convertFitXToOutputX(endX);
        startY = convertFitYToOutputY(startY, rows);
        endY = convertFitYToOutputY(endY, rows);
        
        //std::cout	<< startX << "	" << endX << "	" << startY << "	" << endY << "\n";
        
        outputImage.draw(Magick::DrawableLine(startX,startY,endX,endY));
        
        calculationDone = 1;
        
        doneDrawing = 1;
        //outputImage.display();
        
        return 0;
    }
    
    
    
    ///The following are for fitting.
    struct data {
        size_t n;
        double * y;
        double * sigma;
        
        std::vector<double> pointerToXValues;
        std::vector<double> pointerToYValues;
    };
    
    int MicrotubuleFit::expb_f (const gsl_vector * x, void *data, gsl_vector * f)
    {
        size_t n = ((struct data *)data)->n;
        double *y = ((struct data *)data)->y;
        double *sigma = ((struct data *) data)->sigma;
        
        std::vector<double> pointerToXValues = ((struct data *) data)->pointerToXValues;
        std::vector<double> pointerToYValues = ((struct data *) data)->pointerToYValues;
        
        
        double A = gsl_vector_get (x, 0);
        double B = gsl_vector_get (x, 1);
        double C = gsl_vector_get (x, 2);
        double m = gsl_vector_get (x, 3);
        double b = gsl_vector_get (x, 4);
        
        size_t i;
        
        for (i = 0; i < n; i++)
        {
            double Yi = A * exp(
                                -((-b-m*pointerToXValues.at(i)+
                                   pointerToYValues.at(i))
                                  *(-b-m*pointerToXValues.at(i)+
                                    pointerToYValues.at(i))
                                  /((1.0+m*m)*B*B))
                                ) + C;
            gsl_vector_set (f, i, (Yi - y[i]) / sigma[i]);
        }
        
        return GSL_SUCCESS;
    }
    
    int MicrotubuleFit::expb_df (const gsl_vector * x, void *data, gsl_matrix * J)
    {
        size_t n = ((struct data *)data)->n;
        double *sigma = ((struct data *) data)->sigma;
        std::vector<double> pointerToXValues = ((struct data *) data)->pointerToXValues;
        std::vector<double> pointerToYValues = ((struct data *) data)->pointerToYValues;
        
        double A = gsl_vector_get (x, 0);
        double B = gsl_vector_get (x, 1);
        //double C = gsl_vector_get (x, 2);
        double m = gsl_vector_get (x, 3);
        double b = gsl_vector_get (x, 4);
        
        size_t i;
        
        for (i = 0; i < n; i++)
        {
            /* Jacobian matrix J(i,j) = dfi / dxj, */
            /* where fi = (Yi - yi)/sigma[i],      */
            /*       Yi = A * exp(-lambda * i) + b  */
            /* and the xj are the parameters (A,lambda,b) */
            
            double x = pointerToXValues[i];
            double y = pointerToYValues[i];
            
            double partial_A = 
			exp(-((-b - m*x + y)*(-b - m*x + y)/((1 + m*m) *B*B)))
            ;
            
            double partial_B = 
            (2.0* A * exp(-((-b - m*x + y)*(-b - m*x + y)/((1 + m*m) *B*B))) *(-b - m*x + y)*(-b - m*x + y))/((1 + m*m) *B*B*B)
            ;
            
            double partial_C = 1;
            
            double partial_m =
			A *exp(-((-b - m*pointerToXValues[i] + pointerToYValues[i])*(-b - m*pointerToXValues[i] + pointerToYValues[i])/((1.0 + m*m) *B*B))) 
			*((2.0 * pointerToXValues[i] * (-b - m*pointerToXValues[i] + y))/((1.0 + m*m) *B*B) 
			  + (2.0*m* (-b - m*pointerToXValues[i] + y)*(-b - m*pointerToXValues[i] + y))/((1 + m*m)*(1 + m*m) *B*B))
			;
            
            double partial_b =
			(2.0* A *exp(-((-b - m* x + y)*(-b - m* x + y)/((1 + m*m) *B*B)))* (-b - m*x + y))/((1.0 +
                                                                                                 m*m) *B*B)
			;
            
            gsl_matrix_set (J, i, 0, partial_A /sigma[i]); 
            gsl_matrix_set (J, i, 1, partial_B /sigma[i]);
            gsl_matrix_set (J, i, 2, partial_C /sigma[i]); 
            gsl_matrix_set (J, i, 3, partial_m /sigma[i]); 
            gsl_matrix_set (J, i, 4, partial_b /sigma[i]); 
            
        }
        return GSL_SUCCESS;
    }
    
    int MicrotubuleFit::expb_fdf (const gsl_vector * x, void *data, gsl_vector * f, gsl_matrix * J)
    {
        expb_f (x, data, f);
        expb_df (x, data, J);
        
        return GSL_SUCCESS;
    }
    
    void MicrotubuleFit::print_state (size_t iter, gsl_multifit_fdfsolver * s)
    {
        printf ("iter: %3u x = % 15.8f % 15.8f % 15.8f "
                "|f(x)| = %g\n",
                (unsigned int)iter,
                gsl_vector_get (s->x, 0), 
                gsl_vector_get (s->x, 1),
                gsl_vector_get (s->x, 2), 
                gsl_blas_dnrm2 (s->f));
    }
    
    void MicrotubuleFit::fit(void)
    {
        numIterations = 0;
        yValues.clear();
        xValues.clear();
        std::vector<double> zValues;
        
        std::cout << tiffFileName << "\n";
        
        Magick::Image inputImage(tiffFileName);
        ScienceFile imageInXYZFormat = returnDataForGaussianFitting(returnTNTArrayFromMagickImage(inputImage));
        xValues = imageInXYZFormat.returnColumn(0);
        yValues = imageInXYZFormat.returnColumn(1);
        zValues = imageInXYZFormat.returnColumn(2);
        sigmas.clear();
        sigmas.resize(xValues.size(), 1);
        
        const gsl_multifit_fdfsolver_type *T;
        gsl_multifit_fdfsolver *s;
        int status;
        unsigned int i, iter = 0;
        const size_t n = yValues.size();//Number of data points
        const size_t p = 5;//Number of fit parameters
        
        //Determine initial fitting parameters
        if(m ==0)
        {
            m = 1;
            b = 1;
        }
        //calculatePreliminaryFit();
        
        TNT::Array2D<int> inputImageArray = returnTNTArrayFromMagickImage(inputImage);
        B = 10;
        C = returnMinimumPixelIntensity(inputImageArray);
        A = returnMaximumPixelIntensity(inputImageArray) - C;
        
        gsl_matrix *covar = gsl_matrix_alloc (p, p);
        
        double y[n], sigma[n];
        struct data d = { n, y, sigma, xValues, yValues};
        
        gsl_multifit_function_fdf f;		
        double x_init[p] = {A, B, C, m, b};
        
        gsl_vector_view x = gsl_vector_view_array (x_init, p);
        
        
        f.f = &expb_f;
        f.df = &expb_df;
        f.fdf = &expb_fdf;
        f.n = n;
        f.p = p;
        f.params = &d;
        
        // These are the data to be fitted
        for (i = 0; i < n; i++)
        {
            y[i] = zValues.at(i);
            sigma[i] = sigmas.at(i);
        }
        
        
        T = gsl_multifit_fdfsolver_lmsder;
        s = gsl_multifit_fdfsolver_alloc (T, n, p);
        gsl_multifit_fdfsolver_set (s, &f, &x.vector);
        
        if(verboseFitting)
            print_state (iter, s);
        
        do
        {
            iter++;
            status = gsl_multifit_fdfsolver_iterate (s);
            
            if(verboseFitting)
            {
                printf ("status = %s\n", gsl_strerror (status));
                print_state (iter, s);
            }
            
            if (status)
                break;
            
            status = gsl_multifit_test_delta (s->dx, s->x,
                                              fitTolerance, fitTolerance);
        }
        while (status == GSL_CONTINUE && iter < maxNumberOfFitIterations);
        
        if(iter == maxNumberOfFitIterations)
            if(verboseFitting)
                std::cout << "Could not fit within " << maxNumberOfFitIterations << " iterations.\n";
        
        //std::cout << gsl_strerror (status) << "\n";
        
        gsl_multifit_covar (s->J, 0.0, covar);
        
        {
#define FIT(i) gsl_vector_get(s->x, i)
#define ERR(i) sqrt(gsl_matrix_get(covar,i,i))
            
            double chi = gsl_blas_dnrm2(s->f);
            double dof = n - p;
            double c = GSL_MAX_DBL(1, chi / sqrt(dof)); 
            
            if(verboseFitting)
            {
                printf("chisq/dof = %g\n",  pow(chi, 2.0) / dof);
                printf ("A	=	%.5f +/- %.5f\n", FIT(0), c*ERR(0));
                printf ("B	=	%.5f +/- %.5f\n", FIT(1), c*ERR(1));
                printf ("C	=	%.5f +/- %.5f\n", FIT(2), c*ERR(2));
                printf ("m	=	%.5f +/- %.5f\n", FIT(3), c*ERR(3));
                printf ("b	=	%.5f +/- %.5f\n", FIT(4), c*ERR(4));
                
            }
            
            A =  FIT(0);
            B =  FIT(1);
            C =  FIT(2);
            m =  FIT(3);
            b =  FIT(4);
            
            A_Error = c*ERR(0);
            B_Error = c*ERR(1);
            C_Error = c*ERR(2);
            m_Error = c*ERR(3);
            b_Error = c*ERR(4);
            
            lineFit.clear();
            lineFit.resize(4,0);
            lineFit.at(0) = m;
            lineFit.at(1) = b;
            lineFit.at(2) = m_Error;
            lineFit.at(3) = b_Error;
        }
        
        if(verboseFitting)
            printf ("status = %s\n", gsl_strerror (status));
        gsl_multifit_fdfsolver_free (s);
        gsl_matrix_free (covar);
        
        doneFitting = 1;
        
        std::cout << "I finished the microtubule fitting.\n";
        
    }
    
    
    void MicrotubuleFit::calculatePreliminaryFitUsingSpotFitsFile(void)
    {
        std::cout << "Performing preliminary fit.\n";
        
        std::string stageDriftCorrectionFileName = outputDirectory + "/stageDriftCorrection.txt";
        std::string shrimpFitsFileName = outputDirectory + "/" + outputFilePrefix + "shrimpFits.txt";
        std::string driftCorrectedSpotFitsFileName = outputDirectory + "/" + outputFilePrefix + "driftCorrectedSpotFits.txt";
        
        int usingStageDriftCorrection = checkWhetherFileIsPresent(stageDriftCorrectionFileName.c_str());
        if(usingStageDriftCorrection){
            std::cout << stageDriftCorrectionFileName << " stage drift correction file was found.\n";
            createDriftCorrectedSpotFitsFile(stageDriftCorrectionFileName.c_str(), shrimpFitsFileName.c_str(), driftCorrectedSpotFitsFileName.c_str());
        }
        else {
            std::cout << stageDriftCorrectionFileName << " stage drift correction file was not found.\n";
        }
        
        
        ScienceFile shrimpFitsFile;
        
        if(usingStageDriftCorrection)
        {
            shrimpFitsFile.loadFromFile(driftCorrectedSpotFitsFileName.c_str());
        }
        else {
            shrimpFitsFile.loadFromFile(shrimpFitsFileName.c_str());
        }
        
        std::vector<double> x0s = shrimpFitsFile.returnColumn(1);
        std::vector<double> y0s = shrimpFitsFile.returnColumn(2);
        lineFit.clear();
        lineFit = fitDataToStraightLine(x0s, y0s);
        
        std::string folderName = outputDirectory.substr(0, outputDirectory.size() - 1);
        
        std::string normalImageName = folderName + "/" + folderName + ".tif";
        std::string superResolutionImageName = tiffFileName;
        
        std::cout << normalImageName << " " << superResolutionImageName << "\n";
        
        double scalingFactor = determineScalingFactorFromNormalAndSuperResolutionImages(normalImageName, superResolutionImageName);
        
        lineFit.at(1) *= scalingFactor;
        
        m = lineFit.at(0);
        b = lineFit.at(1);
        
        std::cout << "Finished preliminary line fit.\n";
    }
    
    
    
    std::vector<double> MicrotubuleFit::fitDataToStraightLine(std::vector<double> x0s, std::vector<double> y0s)
    {
        std::vector<double> lineFit;
        
        double sumX = 0;
        double sumY = 0;
        double sumXSquared = 0;
        double sumXY = 0;
        
        int numPoints = x0s.size();
        int i;
        for(i = 0; i < numPoints; i++)
        {
            sumX += x0s.at(i);
            sumY += y0s.at(i);
            sumXSquared += pow(x0s.at(i), 2);
            sumXY += x0s.at(i) * y0s.at(i);
        }
        
        double delta = numPoints * sumXSquared - pow(sumX, 2);
        double oneOverDelta = 1.0L/delta;
        
        double B = oneOverDelta * (sumXSquared * sumY - sumX * sumXY);
        double A = oneOverDelta * (numPoints * sumXY - sumX * sumY);
        
        //std::cout << "Line fit: slope = " << A << ", intercept = " << B << "\n";
        
        lineFit.push_back(A);
        lineFit.push_back(B);
        return lineFit;
    }
    
    
    double MicrotubuleFit::determineScalingFactorFromNormalAndSuperResolutionImages(std::string normalImageName, std::string superResolutionImageName)
    {
        Magick::Image originalTIFF(normalImageName);
        Magick::Image superResolutionImage(superResolutionImageName);
        double scalingFactor = superResolutionImage.rows()/originalTIFF.rows();
        return scalingFactor;
    }
    
    
    int MicrotubuleFit::createDriftCorrectedSpotFitsFile(const char *driftCorrectionFileName, const char *spotFitsFileName, const char *outputFileName)
    {
        const int frameWherePhotobleachingOccursColumn = 15;
        const int x0Column = 1;
        const int y0Column = 2;
        
        ScienceFile stageDriftCorrectionFile(driftCorrectionFileName);
        ScienceFile spotFitsFile(spotFitsFileName);
        
        double driftOriginX = stageDriftCorrectionFile.at(0, 1);
        double driftOriginY = stageDriftCorrectionFile.at(0, 2);
        
        int numSpotFits = spotFitsFile.numRows();
        int i;
        for (i = 0; i < numSpotFits; i++) 
        {
            //std::cout << "i = " << i << "\n";
            int frameOfTheGivenSpot = spotFitsFile.at(i, frameWherePhotobleachingOccursColumn) - 1;
            
            double xCorrection = driftOriginX - stageDriftCorrectionFile.at(frameOfTheGivenSpot, 1);
            double yCorrection = driftOriginY - stageDriftCorrectionFile.at(frameOfTheGivenSpot, 2);
            
            //std::cout << "Drift correcting spot" << i + 1 << ", frameOfTheGivenSpot = " << frameOfTheGivenSpot << ", " << xCorrection << "	" << yCorrection << "\n";
            
            //std::cout << "This far...\n";
            double newX = xCorrection + spotFitsFile.at(i, x0Column);
            double newY = yCorrection + spotFitsFile.at(i, y0Column);
            
            spotFitsFile.setElement(i, x0Column, newX);
            spotFitsFile.setElement(i, y0Column, newY);
        }
        
        spotFitsFile.writeToFile(outputFileName);
        std::cout << "Created " << outputFileName << ".\n";
        
        return 0;
    }
    
    
    void MicrotubuleFit::printFit(void)
    {
        std::cout	<< "A = " << A << ",	"
        << "B = " << B << ",	"
        << "C = " << C << ",	"
        << "m = " << m << ",	"
        << "b = " << b << "\n";
        
        std::cout << "Angle of the fit line is " << rotationAngle() << " radians = " << rotationAngle() * 180.0/3.14159 << " degrees.\n";
        std::cout << "The y intercept of the line is " << lineFit.at(1) << ".\n";
    }
    

}
