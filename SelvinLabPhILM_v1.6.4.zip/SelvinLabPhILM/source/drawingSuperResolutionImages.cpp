/*
 *  drawingSuperResolutionImages.cpp
 *  ReverseSTORM_SL
 *
 *  Created by Paul Simonson on 8/14/10.
 *  Copyright 2010 University of Illinois at Urbana-Champaign. All rights reserved.
 *
 */

#include "PhILMCoreCode.h"
#include "drawingSuperResolutionImages.h"
#include "return2DArrayFromMultiBitmap.h"
//#include "writeTIFFFileUsingMagick.h"
#include "SimonsonLibTIFF_IO.h"

using namespace PhILM_namespace;

extern class PhILMPreferences thePhILMPreferences;

const bool verboseOutput = false;

namespace DrawingSuperResolutionImages {
	
	const double pixelShiftForDrawingSuperResolutionImages = 0.5;
	
	
	double ellipticalGaussian2D(double x, 
								double y, 
								double peakHeight, 
								double x0, 
								double y0, 
								double x0Error, 
								double y0Error,
								double tiltAngle)
	{
		double xP = (x - x0) * cos(tiltAngle) - (y - y0) * sin(tiltAngle);
		double yP = (x - x0) * sin(tiltAngle) + (y - y0) * cos(tiltAngle);
		return peakHeight * exp(-0.5L * (pow(xP/x0Error, 2) + pow(yP/y0Error, 2)));
	}
	
	struct PlottingRange {
		int minXRange, maxXRange, minYRange, maxYRange;
	};
	
	
	struct PlottingRange determineSpotPlottingRange(TNT::Array2D<int> superResolutionImage, TwoDGaussianFittingParametersAndErrors spotFit)
	{
		struct PlottingRange plotRange;
		
		int width = superResolutionImage.dim1();
		int height = superResolutionImage.dim2();
		
		plotRange.minXRange = spotFit.xCenterValue - 4.0 * spotFit.xCenterValueError;
		plotRange.maxXRange = spotFit.xCenterValue + 4.0 * spotFit.xCenterValueError;
		plotRange.minYRange = spotFit.yCenterValue - 4.0 * spotFit.yCenterValueError;
		plotRange.maxYRange = spotFit.yCenterValue + 4.0 * spotFit.yCenterValueError;
		
		if(plotRange.minXRange < 0)
			plotRange.minXRange = 0;
		if(plotRange.minYRange < 0)
			plotRange.minYRange = 0;
		if(plotRange.maxXRange > width)
			plotRange.maxXRange = width;
		if(plotRange.maxYRange > height)
			plotRange.maxYRange = height;
		
		return plotRange;
	}
	
	
	
	int quicklyDrawEllipticalGaussianSpot(TNT::Array2D<int> superResolutionImage, 
										  TwoDGaussianFittingParametersAndErrors spotFit,
										  double scalingFactor,
										  int drawingStyle)
	{
		if (verboseOutput) {
			std::cout << "Drawing style: " << drawingStyle << "\n";
		}
		
		struct PlottingRange plotRange = determineSpotPlottingRange(superResolutionImage, spotFit);
		
		if(spotFit.xCenterValueError < thePhILMPreferences.minimumSpotWidthForStillDrawingGaussian  
		   && spotFit.yCenterValueError < thePhILMPreferences.minimumSpotWidthForStillDrawingGaussian)//the spot is too small to draw...
		{
			if ((int)spotFit.xCenterValue < superResolutionImage.dim1() 
				&& (int)spotFit.yCenterValue < superResolutionImage.dim2() 
				&& (int)spotFit.xCenterValue > -1 
				&& (int)spotFit.yCenterValue > -1) 
			{
				double totalCounts = 2.0 * M_PI * spotFit.peakHeight * spotFit.xWidth * spotFit.yWidth;
				
				switch (drawingStyle) 
				{
					case maxZProject:
						if (scalingFactor * spotFit.peakHeight > superResolutionImage[(int)spotFit.xCenterValue][(int)spotFit.yCenterValue])
							superResolutionImage[(int)spotFit.xCenterValue][(int)spotFit.yCenterValue] = scalingFactor * spotFit.peakHeight;
						break;
					case standard:
						superResolutionImage[(int)spotFit.xCenterValue][(int)spotFit.yCenterValue] += scalingFactor * spotFit.peakHeight;
						break;
					case normalizedSpots:
						superResolutionImage[(int)spotFit.xCenterValue][(int)spotFit.yCenterValue] += scalingFactor * 1000;
						break;
					case PhILMDrawingStyle:
						//std::cout << "Single pixel value = " <<  scalingFactor * totalCounts << ".\n";
						superResolutionImage[(int)spotFit.xCenterValue][(int)spotFit.yCenterValue] += scalingFactor * totalCounts;
						break;
					default:
						break;
				}
			}
		}
		else 
		{
			int i,j;
			
			for(i = plotRange.minXRange; i < plotRange.maxXRange; i++)
				for(j = plotRange.minYRange; j < plotRange.maxYRange; j++)
				{
					int plotValue = ellipticalGaussian2D(i, j, spotFit.peakHeight, 
														 spotFit.xCenterValue, 
														 spotFit.yCenterValue, 
														 spotFit.xCenterValueError, 
														 spotFit.yCenterValueError,
														 spotFit.tiltAngle);
					switch (drawingStyle) {
						case maxZProject:
						{
							if (plotValue > superResolutionImage[i][j])
								superResolutionImage[i][j] = plotValue;
						}
							break;
						case standard:
						{
							superResolutionImage[i][j] += plotValue;
						}
							break;
						case normalizedSpots:
						{
							double adjustedPlotValue = plotValue * scalingFactor * 1000.0/(2.0* spotFit.peakHeight * spotFit.xCenterValueError * spotFit.yCenterValueError * M_PI);
							superResolutionImage[i][j] += adjustedPlotValue;
						}
							break;
						case PhILMDrawingStyle:
							superResolutionImage[i][j] += scalingFactor * plotValue * spotFit.xWidth * spotFit.yWidth/(spotFit.xCenterValueError * spotFit.yCenterValueError);
							break;
						default:
							break;
					}
					
					if (superResolutionImage[i][j] > 65535) {//maximum 16 bit integer value.
						superResolutionImage[i][j] = 65535;
					}
				}
		}
		
		return 0;
	}
	
	
	double totalSpotIntensity(const double &peakHeight, const double &sigmaX, const double &sigmaY)
	{
		return peakHeight * 2.0 * M_PI * sigmaX * sigmaY;
	}
	
	
	void quicklyDrawSpotsInSuperResolutionImage(const char *inputFileName, const char *outputFileName, double imageZoomFactor, double drawingIntensityScalingFactor, int drawingStyle, double fixedSpotIntensity)
	{	
		//if (verboseOutput) 
        {
			std::cout << "Drawing super-resolution image using style " << drawingStyle << "...\n";
		}
		
		//1
		int usingStageDriftCorrection = checkWhetherFileIsPresent(thePhILMPreferences.prefixWithOutputDirectory("stageDriftCorrection.txt").c_str());
		ScienceFile stageDriftCorrectionFile;
		if(usingStageDriftCorrection)
		{
			std::cout << thePhILMPreferences.prefixWithOutputDirectory("stageDriftCorrection.txt") << " was found and will be used in drawing spots.\n";
			stageDriftCorrectionFile.loadFromFile(thePhILMPreferences.prefixWithOutputDirectory("stageDriftCorrection.txt").c_str());
		}
		
		//2
		if(!checkWhetherFileIsPresent(inputFileName))
		{
			std::cout << "Could not find the input tiff file " << inputFileName << ".\n";
			return;
		}
		//Magick::Image firstImageInStack(inputFileName);
		//TNT::Array2D<int> originalTIFF0 = returnTNTArrayFromMagickImage(firstImageInStack);
		TNT::Array2D<int> originalTIFF0 = Return2DArray::return2DIntArrayFromMultiBitmap(inputFileName, 1);
		
		//3
		int width = originalTIFF0.dim1();
		int height = originalTIFF0.dim2();
		TNT::Array2D<int> superResolutionImage(width * imageZoomFactor, height * imageZoomFactor, 0);
		
		//4
		//I would normally use the ScienceFile class, but it seems that the file is too large in some cases,
		//so I am reading the file one row at a time and drawing the spots.
		std::ifstream indata; // indata is like cin
		indata.open(thePhILMPreferences.formOutputFilePath("spotFits.txt").c_str()); // opens the file
		if(!indata) { // file couldn't be opened
			std::cout << "Error: " << thePhILMPreferences.formOutputFilePath("spotFits.txt") << " could not be opened.\n" << "\n";
			exit(1);
		}
		char line[2000];
		char c;
		while((c = indata.peek()) == '#')//move down until the first character of the line is not #
		{
			indata.getline(line, 2000);
			std::cout << indata << "\n";
		}
		while((c = indata.peek()) == '%')//move down until the first character of the line is not #
		{
			indata.getline(line, 2000);
			//std::cout << indata << "\n";
		}
		
		
		int frameWherePhotobleachingOccurs;
		int normalSpotFlag;
		
		TwoDGaussianFittingParametersAndErrors spotFit;
		
		int numNormalSpotsDrawn = 0;
		int numAntiSpotsDrawn = 0;
		int numSpotsDrawn = 0;
		while ( !indata.eof())
		{		
			if (verboseOutput) {
				std::cout << "Now drawing spot " << ++numSpotsDrawn << " in the super-resolution image.\n";
			}
			
			indata	>> std::scientific 
			>> spotFit.peakHeight 
			>> spotFit.xCenterValue >> spotFit.yCenterValue 
			>> spotFit.xWidth >> spotFit.yWidth >> spotFit.background >> spotFit.tiltAngle
			>> spotFit.peakHeightError 
			>> spotFit.xCenterValueError >> spotFit.yCenterValueError 
			>> spotFit.xWidthError >> spotFit.yWidthError >> spotFit.backgroundError >> spotFit.tiltAngleError
			>> frameWherePhotobleachingOccurs 
			>> frameWherePhotobleachingOccurs
			>> normalSpotFlag
            >> normalSpotFlag
			>> normalSpotFlag;
			
			indata.getline(line, 2000);//finish off the line...
			
			if(checkWhetherSpotIsGood(spotFit, 1))
			{	
				TwoDGaussianFittingParametersAndErrors scaledSpotFit = spotFit;
				
				if(fixedSpotIntensity)
					scaledSpotFit.peakHeight = fixedSpotIntensity;
				
				if(usingStageDriftCorrection)
				{
					scaledSpotFit.xCenterValue += stageDriftCorrectionFile.at(0, 1) - stageDriftCorrectionFile.at(frameWherePhotobleachingOccurs - 1, 1);
					scaledSpotFit.yCenterValue += stageDriftCorrectionFile.at(0, 2) - stageDriftCorrectionFile.at(frameWherePhotobleachingOccurs - 1, 2);
					if (verboseOutput) {
						std::cout << "Applying stage correction...  x0 = " << scaledSpotFit.xCenterValue << ", y0 = " << scaledSpotFit.yCenterValue << "\n";
					}
				}
				
				scaledSpotFit.xCenterValue += pixelShiftForDrawingSuperResolutionImages;
				scaledSpotFit.yCenterValue += pixelShiftForDrawingSuperResolutionImages;
				
				scaledSpotFit.xCenterValue *= imageZoomFactor;
				scaledSpotFit.yCenterValue *= imageZoomFactor;
				scaledSpotFit.xCenterValueError *= imageZoomFactor;
				scaledSpotFit.yCenterValueError *= imageZoomFactor;
				
				if (verboseOutput) {
					std::cout << scaledSpotFit.peakHeight << "	" << scaledSpotFit.xCenterValue << "	" << scaledSpotFit.yCenterValue << "	" << scaledSpotFit.xCenterValueError << "	" << scaledSpotFit.yCenterValueError << "\n";
				}
				
				switch (drawingStyle) {
					case pixels:
					{
						if ((int)scaledSpotFit.xCenterValue >= 0 
							&& (int)scaledSpotFit.yCenterValue >= 0 
							&& (int)scaledSpotFit.xCenterValue < superResolutionImage.dim1()
							&& (int)scaledSpotFit.yCenterValue < superResolutionImage.dim2()) //There can be problems when stage drift correction is used.
						{
							if (verboseOutput) {
								std::cout << (int)scaledSpotFit.xCenterValue << "	" << (int)scaledSpotFit.yCenterValue << "\n";
							}
							superResolutionImage[(int)scaledSpotFit.xCenterValue][(int)scaledSpotFit.yCenterValue] += 1;
						}
						else {
							numSpotsDrawn--;
							if (verboseOutput) {
								std::cout << "The pixel location was out of range, and therefore the spot was not drawn.\n";
							}
						}
					}
						break;
						
					case standard:
					{
						quicklyDrawEllipticalGaussianSpot(superResolutionImage, 
														  scaledSpotFit,
														  drawingIntensityScalingFactor,
														  drawingStyle);
					}
						break;
						
					case maxZProject:
					{
						quicklyDrawEllipticalGaussianSpot(superResolutionImage, 
														  scaledSpotFit,
														  drawingIntensityScalingFactor,
														  drawingStyle);				
					}
						break;
						
					case normalizedSpots:
						
					{
						quicklyDrawEllipticalGaussianSpot(superResolutionImage, 
														  scaledSpotFit,
														  drawingIntensityScalingFactor,
														  drawingStyle);
					}
						break;
						
					case PhILMDrawingStyle:
					{
						if (verboseOutput) {
							std::cout << "PhILMDrawingStyle!\n";
						}
						quicklyDrawEllipticalGaussianSpot(superResolutionImage, 
														  scaledSpotFit,
														  drawingIntensityScalingFactor,
														  drawingStyle);
					}
						break;
						
					default:
						break;
				}
				
				if(normalSpotFlag)
					numNormalSpotsDrawn++;
				else
					numAntiSpotsDrawn++;
				
				
			}
			else {
				if (verboseOutput) {
					std::cout << "Spot fit " << numSpotsDrawn << " was not drawn to the super-resolution image.\n";
				}
			}
			
			//jump out if the first character in the next line is '\n'
			if(indata.peek() == '\n')
				indata.getline(line, 2000);//finish off the line...
			//jump out if the first character in the next line is '\r'
			if(indata.peek() == '\r')
				indata.getline(line, 2000);//finish off the line...
		}
		indata.close();
        
		std::cout << "Number of spots drawn as a result of going from fluorescent to dark state: " << numNormalSpotsDrawn << "\n";
		std::cout << "Number of spots drawn as a result of going from dark to fluorescent state: " << numAntiSpotsDrawn << "\n";
		std::cout << "Now writing the super-resolution image to disk...\n";

		//writeTIFFFileUsingMagick(outputFileName, superResolutionImage);
		SimonsonLibTIFF_IO::writeTIFFFile(outputFileName, superResolutionImage);
		std::cout << "\a";
	}
	

	void drawSuperResolutionImageUsingNormalizedSpots(const char *inputFileName, const char *outputFileName, double imageZoomFactor, double volumeUnderSpot)
	{
		quicklyDrawSpotsInSuperResolutionImage(inputFileName, 
											   outputFileName, 
											   imageZoomFactor, 
											   volumeUnderSpot, 
											   normalizedSpots, 
											   0);
	}
		
}

