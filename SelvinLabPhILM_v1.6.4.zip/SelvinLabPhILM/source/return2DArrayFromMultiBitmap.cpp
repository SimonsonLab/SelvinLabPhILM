/*
 *  return2DArrayFromMultiBitmap.cpp
 *  TIFFStackEditor
 *
 *  Created by Paul Simonson on 10/2/06.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */

#include "return2DArrayFromMultiBitmap.h"
#include <iostream>

namespace Return2DArray  
{
	///These use a frame counting system that starts with ONE.
	TNT::Array2D< unsigned short > return2DArrayFromMultiBitmap(FIMULTIBITMAP *MTmultibitmap, int whichFrame){
		unsigned width, height;
		unsigned x, y;
		
		FIBITMAP *lockedPage =  FreeImage_LockPage(MTmultibitmap, whichFrame - 1);
		
		width = FreeImage_GetWidth(lockedPage); 
		height = FreeImage_GetHeight(lockedPage);
		
		TNT::Array2D< unsigned short > imageArray(width, height);
		//This part just sticks the image in a 2 d array of unsigned shorts.
		for(y = 0; y < height; y++) 
		{ 
			unsigned short *bits = (unsigned short *)FreeImage_GetScanLine(lockedPage, y); 
			for(x = 0; x < width; x++) 
			{ 
				imageArray[(int)x][(int)y] = bits[(int)x];
			}
		}
		FreeImage_UnlockPage(MTmultibitmap, lockedPage, 0);
		return imageArray;
	}

	
	TNT::Array2D< double > return2DDoubleArrayFromMultiBitmap(FIMULTIBITMAP *MTmultibitmap, int whichFrame)
	{
		unsigned width, height;
		unsigned x, y;
		
		if (whichFrame - 1 < 0) {
			std::cout << "Error: tried to access a frame at whichFrame < 0...\n";
		}
		
		FIBITMAP *lockedPage =  FreeImage_LockPage(MTmultibitmap, whichFrame - 1);
		
		width = FreeImage_GetWidth(lockedPage); 
		height = FreeImage_GetHeight(lockedPage);
		
		TNT::Array2D< double > imageArray(width, height);
		//This part just sticks the image in a 2 d array of unsigned shorts.
		for(y = 0; y < height; y++) 
		{ 
			unsigned short *bits = (unsigned short *)FreeImage_GetScanLine(lockedPage, y); 
			for(x = 0; x < width; x++) 
			{ 
				imageArray[(int)x][(int)y] = bits[(int)x];
			}
		}
		FreeImage_UnlockPage(MTmultibitmap, lockedPage, 0);
		return imageArray;
	}
	
	
	
	TNT::Array2D< int > return2DIntArrayFromMultiBitmap(FIMULTIBITMAP *MTmultibitmap, int whichFrame)
	{
		unsigned width, height;
		unsigned x, y;
		
		if (whichFrame - 1 < 0) {
			std::cout << "Error in return2DIntArrayFromMultiBitmap(FIMULTIBITMAP *MTmultibitmap, int whichFrame): tried to access a frame at whichFrame < 0...\n";
		}
		
		FIBITMAP *lockedPage =  FreeImage_LockPage(MTmultibitmap, whichFrame - 1);
		
		width = FreeImage_GetWidth(lockedPage); 
		height = FreeImage_GetHeight(lockedPage);
		
		TNT::Array2D< int > imageArray(width, height);
		//This part just sticks the image in a 2 d array of unsigned shorts.
		for(y = 0; y < height; y++) 
		{ 
			unsigned short *bits = (unsigned short *)FreeImage_GetScanLine(lockedPage, y); 
			for(x = 0; x < width; x++) 
			{ 
				imageArray[(int)x][(int)y] = bits[(int)x];
			}
		}
		FreeImage_UnlockPage(MTmultibitmap, lockedPage, 0);
		return imageArray;
	}
	
	
	TNT::Array2D< int > return2DIntArrayFromMultiBitmap(const char *TIFFFileName, int whichFrame)
	{	
		FIMULTIBITMAP *MTmultibitmap = FreeImage_OpenMultiBitmap(FIF_TIFF, TIFFFileName, 0, 1, 0, 0);
		
		TNT::Array2D< int > imageArray;
		if(MTmultibitmap)
		{
			imageArray = return2DIntArrayFromMultiBitmap(MTmultibitmap, whichFrame);
			FreeImage_CloseMultiBitmap(MTmultibitmap, 0);
			
			return imageArray;
		}
		else
		{
			std::cout << "Could not open " << TIFFFileName << " for reading.\n";
			TNT::Array2D< int > imageArray(1, 1,-1);
			return imageArray;
		}
	}
	
	
	
	//startFrame and endFrame should be the frame number using a counting system that starts with ONE.
	TNT::Array2D< double > returnDoubleArrayAverageOfFrames(FIMULTIBITMAP *MTmultibitmap, int startFrame, int endFrame)
	{
		startFrame--;
		endFrame--;
		
		int width, height;
		int x, y;
		int numFrames = FreeImage_GetPageCount(MTmultibitmap);
		if(startFrame > numFrames - 1)
		{
			startFrame = numFrames - 1;
			std::cout << "Start frame in averaging passes end of tiff stack--setting to last frame.\n";
		}
		if(endFrame > numFrames - 1)
		{
			endFrame = numFrames - 1;
			std::cout << "End frame in averaging passes end of tiff stack--setting to last frame.\n";
		}
		if(startFrame < 0)
		{
			std::cout << "Start frame was " << startFrame << "--setting to one.\n";
			startFrame = 0;
		}
		if(endFrame < 0)
		{
			std::cout << "End frame was " << endFrame << "--setting to one.\n";
			endFrame = 0;
		}
		int numToAverage = endFrame - startFrame;
		if(numToAverage < 0)
		{
			numToAverage = -numToAverage;
			int temp = startFrame;
			startFrame = endFrame;
			endFrame = temp;
			std::cout << "startFrame was greater than endFrame, so the two were swapped.\n";
		}
		numToAverage++;//to include the start frame.
		if(numToAverage == 0)//This should not be possible.
		{
			numToAverage = 1;
			std::cout << "Number of frames to average was zero--resetting to one (this should not be possible).\n";
		}
		//std::cout << "Number of frames to averge is " << numToAverage << ".\n";
		double multiplicationFactor = 1.0L/(double)numToAverage;
		
		//Get the necessary info to create the averaged frame.
		FIBITMAP *lockedPage =  FreeImage_LockPage(MTmultibitmap, startFrame);
		width = FreeImage_GetWidth(lockedPage); 
		height = FreeImage_GetHeight(lockedPage);
		FreeImage_UnlockPage(MTmultibitmap, lockedPage, 0);		
		
		TNT::Array2D< double > averagedFrame(width, height, 0.0);
		int i;
		for(i = startFrame; i < endFrame + 1; i++)
		{
			FIBITMAP *lockedPage =  FreeImage_LockPage(MTmultibitmap, i);
			for(y = 0; y < height; y++) 
			{ 
				unsigned short *bits = (unsigned short *)FreeImage_GetScanLine(lockedPage, y); 
				for(x = 0; x < width; x++) 
				{ 
					averagedFrame[(int)x][(int)y] = (double)averagedFrame[(int)x][(int)y] + (multiplicationFactor * (double)(bits[(int)x]));
				}
			}
			FreeImage_UnlockPage(MTmultibitmap, lockedPage, 0);		
		}
		return averagedFrame;
	}
	
	
	
	
	//startFrame and endFrame should be the frame number using a counting system that starts with ONE.
	TNT::Array2D< int > returnIntArrayAverageOfFrames(FIMULTIBITMAP *MTmultibitmap, int startFrame, int endFrame)
	{
		startFrame--;
		endFrame--;
		
		int width, height;
		int x, y;
		int numFrames = FreeImage_GetPageCount(MTmultibitmap);
		if(startFrame > numFrames - 1)
		{
			startFrame = numFrames - 1;
			std::cout << "Start frame in averaging passes end of tiff stack--setting to last frame.\n";
		}
		if(endFrame > numFrames - 1)
		{
			endFrame = numFrames - 1;
			std::cout << "End frame in averaging passes end of tiff stack--setting to last frame.\n";
		}
		if(startFrame < 0)
		{
			std::cout << "Start frame was " << startFrame << "--setting to one.\n";
			startFrame = 0;
		}
		if(endFrame < 0)
		{
			std::cout << "End frame was " << endFrame << "--setting to one.\n";
			endFrame = 0;
		}
		int numToAverage = endFrame - startFrame;
		if(numToAverage < 0)
		{
			numToAverage = -numToAverage;
			int temp = startFrame;
			startFrame = endFrame;
			endFrame = temp;
			std::cout << "startFrame was greater than endFrame, so the two were swapped.\n";
		}
		numToAverage++;//to include the start frame.
		if(numToAverage == 0)//This should not be possible.
		{
			numToAverage = 1;
			std::cout << "Number of frames to average was zero--resetting to one (this should not be possible).\n";
		}
		//std::cout << "Number of frames to averge is " << numToAverage << ".\n";
		double multiplicationFactor = 1.0L/(double)numToAverage;
		
		//Get the necessary info to create the averaged frame.
		FIBITMAP *lockedPage =  FreeImage_LockPage(MTmultibitmap, startFrame);
		width = FreeImage_GetWidth(lockedPage); 
		height = FreeImage_GetHeight(lockedPage);
		FreeImage_UnlockPage(MTmultibitmap, lockedPage, 0);		
		
		TNT::Array2D< int > averagedFrame(width,height,0);
		int i;
		for(i = startFrame; i < endFrame + 1; i++)
		{
			FIBITMAP *lockedPage =  FreeImage_LockPage(MTmultibitmap, i);
			for(y = 0; y < height; y++) 
			{ 
				unsigned short *bits = (unsigned short *)FreeImage_GetScanLine(lockedPage, y); 
				for(x = 0; x < width; x++) 
				{ 
					averagedFrame[(int)x][(int)y] = averagedFrame[(int)x][(int)y] + (int)(multiplicationFactor * (double)(bits[(int)x]));
				}
			}
			FreeImage_UnlockPage(MTmultibitmap, lockedPage, 0);		
		}
		return averagedFrame;
	}
	
	
	//startFrame and endFrame should be the frame number using a counting system that starts with ZERO.
	TNT::Array2D< int > returnIntArrayAverageOfFrames(const char *inputFileName, int startFrame, int endFrame)
	{
		FIMULTIBITMAP *MTmultibitmap = FreeImage_OpenMultiBitmap(FIF_TIFF, inputFileName, 0, 1, 0, 0);	
		TNT::Array2D< int > returnImage = returnIntArrayAverageOfFrames(MTmultibitmap, startFrame, endFrame);
		FreeImage_CloseMultiBitmap(MTmultibitmap);
		return returnImage;
	}
}
