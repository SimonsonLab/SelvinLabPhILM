/*
 *  tiffFrameOperations.cpp
 *  ReverseSTORM
 *
 *  Created by Paul Simonson on 5/18/09.
 *  Copyright 2009 University of Illinois at Urbana-Champaign. All rights reserved.
 *
 */

#include <omp.h>

#include <iostream>

#include "tiffFrameOperations.h"

void multiplyByAConstant(TNT::Array2D< int > imageArray, const double A)
{
	int width = imageArray.dim1();
	int height = imageArray.dim2();
	int x, y;
	for(y = 0; y < height; y++) 
	{ 
		for(x = 0; x < width; x++) 
		{ 
			imageArray[(int)x][(int)y] = (int)(A * (double)(imageArray[(int)x][(int)y]));
		}
	}
}


void subtractAConstant(TNT::Array2D< int > imageArray, const double A)
{
	int width = imageArray.dim1();
	int height = imageArray.dim2();
	int x, y;
	for(y = 0; y < height; y++) 
	{ 
		for(x = 0; x < width; x++) 
		{ 
			imageArray[(int)x][(int)y] = (int)((double)(imageArray[(int)x][(int)y]) - A);
		}
	}
}


void multiplyByAConstant(TNT::Array2D< double > imageArray, const double A)
{
	int width = imageArray.dim1();
	int height = imageArray.dim2();
	int x, y;
	for(y = 0; y < height; y++) 
	{ 
		for(x = 0; x < width; x++) 
		{ 
			imageArray[(int)x][(int)y] = (double)(A * (double)(imageArray[(int)x][(int)y]));
		}
	}
}


void subtractAConstant(TNT::Array2D< double > imageArray, const double A)
{
	int width = imageArray.dim1();
	int height = imageArray.dim2();
	int x, y;
	for(y = 0; y < height; y++) 
	{ 
		for(x = 0; x < width; x++) 
		{ 
			imageArray[(int)x][(int)y] = ((double)(imageArray[(int)x][(int)y]) - A);
		}
	}
}


TNT::Array2D< unsigned short > applyGammaFilter(TNT::Array2D< unsigned short > imageArray, const double gammaExponent)
{
	const unsigned short maxIntensity = 0xFFFF;
	const double inverseMaxIntensity = 1.0L/(double)maxIntensity;
	
	const int width = imageArray.dim1();
	const int height = imageArray.dim2();
	int x, y;
	for(x = 0; x < width; x++)
		for(y = 0; y < height; y++)
			imageArray[x][y] = (unsigned short)(maxIntensity*(pow((double)imageArray[x][y] * inverseMaxIntensity, gammaExponent)));
	return imageArray;
}

/*
FIBITMAP * dilateMaximaReturnFIBITMAP(TNT::Array2D< int > imageArray, int dilationSteps)
{
	int width, height;
	width = imageArray.dim1();
	height = imageArray.dim2();
	
	//find local maxima--similar to getBlob
	TNT::Array2D<int> tempImage1(width, height);
	TNT::Array2D<int> tempImage2(width, height);
	
	int x, y;
	tempImage2 = imageArray.copy();
	
	//Dilate the image.
	int numDilations = 0;//Used to keep track of how many new pixels are highlighted each iteration.
	do{
		numDilations++;
		tempImage1 = tempImage2.copy();
		for (y = 0; y < height; y++)
		{
			for (x = 0; x < width; x++)
			{
				//Now for the individual places on the rectangular image where the spot can be.
				//First check to see whether it is in a corner
				if(x == 0 && y == 0)
				{
					if(tempImage1[x + 1][y] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y];
					if(tempImage1[x][y + 1]> tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y + 1];
					if(tempImage1[x + 1][y + 1] > tempImage2[x + 1][y + 1])
						tempImage2[x][y] = tempImage1[x + 1][y];
				}
				else if(x == width - 1 && y == 0)
				{
					
					if(tempImage1[x - 1][y]> tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y];
					if(tempImage1[x - 1][y + 1]> tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y + 1];
					if(tempImage1[x][y + 1]> tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y + 1];
				}
				else if(x == 0 && y == height - 1)
				{
					if(tempImage1[x][y - 1]> tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y - 1];
					if(tempImage1[x + 1][y - 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y - 1] ;
					if(tempImage1[x + 1][y]> tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y];
				}							
				else if(x == width - 1 && y == height - 1)
				{
					if(tempImage1[x - 1][y - 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y - 1];
					if(tempImage1[x][y - 1]> tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y - 1];
					if(tempImage1[x - 1][y] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y];
				}
				//Now check to see whether it is on a side
				else if(x == 0)
				{
					if(tempImage1[x][y - 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y - 1];
					if(tempImage1[x + 1][y - 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y - 1] ;
					if(tempImage1[x + 1][y] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y];
					if(tempImage1[x][y + 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y + 1];
					if(tempImage1[x + 1][y + 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y + 1];
				}
				else if(x == width - 1)
				{
					if(tempImage1[x - 1][y - 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y - 1];
					if(tempImage1[x][y - 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y - 1];
					if(tempImage1[x - 1][y] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y];
					if(tempImage1[x - 1][y + 1]> tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y + 1];
					if(tempImage1[x][y + 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y + 1];
				}
				else if(y == 0)
				{
					if(tempImage1[x - 1][y] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y];
					if(tempImage1[x + 1][y] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y];
					if(tempImage1[x - 1][y + 1]> tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y + 1];
					if(tempImage1[x][y + 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y + 1];
					if(tempImage1[x + 1][y + 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y + 1];
				}
				else if(y == height - 1)
				{
					
					if(tempImage1[x - 1][y - 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y - 1];
					if(tempImage1[x][y - 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y - 1];
					if(tempImage1[x + 1][y - 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y - 1] ;
					if(tempImage1[x - 1][y] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y];
					if(tempImage1[x + 1][y] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y];
				}
				//If it made it past all of those, then it must be in the center region.
				else
				{
					if(tempImage1[x - 1][y - 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y - 1];
					if(tempImage1[x][y - 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y - 1];
					if(tempImage1[x + 1][y - 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y - 1] ;
					if(tempImage1[x - 1][y] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y];
					if(tempImage1[x + 1][y] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y];
					if(tempImage1[x - 1][y + 1]> tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y + 1];
					if(tempImage1[x][y + 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y + 1];
					if(tempImage1[x + 1][y + 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y + 1];
				}
			}
		}
	} while(numDilations < dilationSteps);
	
	return returnFIBITMAPFromTNTArray(tempImage2);
}
 */

TNT::Array2D<int>  dilateMaximaReturnTNTArray(TNT::Array2D< int > imageArray, const int dilationSteps)
{
    ///Dilates the locally maximum pixel values.
    
	int width, height;
	width = imageArray.dim1();
	height = imageArray.dim2();
	
	//find local maxima--similar to getBlob
	TNT::Array2D<int> tempImage1(width, height);
	TNT::Array2D<int> tempImage2(width, height);
	
	int y;
	tempImage2 = imageArray.copy();
	
	//Dilate the image.
	int numDilations = 0;//Used to keep track of how many new pixels are highlighted each iteration.
	do{
		numDilations++;
		tempImage1 = tempImage2.copy();
//#pragma omp parallel for
		for (y = 0; y < height; y++)
		{
			int x;
			for (x = 0; x < width; x++)
			{
				//Now for the individual places on the rectangular image where the spot can be.
				//First check to see whether it is in a corner
				if(x == 0 && y == 0)
				{
					if(tempImage1[x + 1][y] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y];
					if(tempImage1[x][y + 1]> tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y + 1];
					if(tempImage1[x + 1][y + 1] > tempImage2[x + 1][y + 1])
						tempImage2[x][y] = tempImage1[x + 1][y];
				}
				else if(x == width - 1 && y == 0)
				{
					
					if(tempImage1[x - 1][y]> tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y];
					if(tempImage1[x - 1][y + 1]> tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y + 1];
					if(tempImage1[x][y + 1]> tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y + 1];
				}
				else if(x == 0 && y == height - 1)
				{
					if(tempImage1[x][y - 1]> tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y - 1];
					if(tempImage1[x + 1][y - 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y - 1] ;
					if(tempImage1[x + 1][y]> tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y];
				}							
				else if(x == width - 1 && y == height - 1)
				{
					if(tempImage1[x - 1][y - 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y - 1];
					if(tempImage1[x][y - 1]> tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y - 1];
					if(tempImage1[x - 1][y] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y];
				}
				//Now check to see whether it is on a side
				else if(x == 0)
				{
					if(tempImage1[x][y - 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y - 1];
					if(tempImage1[x + 1][y - 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y - 1] ;
					if(tempImage1[x + 1][y] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y];
					if(tempImage1[x][y + 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y + 1];
					if(tempImage1[x + 1][y + 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y + 1];
				}
				else if(x == width - 1)
				{
					if(tempImage1[x - 1][y - 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y - 1];
					if(tempImage1[x][y - 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y - 1];
					if(tempImage1[x - 1][y] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y];
					if(tempImage1[x - 1][y + 1]> tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y + 1];
					if(tempImage1[x][y + 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y + 1];
				}
				else if(y == 0)
				{
					if(tempImage1[x - 1][y] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y];
					if(tempImage1[x + 1][y] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y];
					if(tempImage1[x - 1][y + 1]> tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y + 1];
					if(tempImage1[x][y + 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y + 1];
					if(tempImage1[x + 1][y + 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y + 1];
				}
				else if(y == height - 1)
				{
					
					if(tempImage1[x - 1][y - 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y - 1];
					if(tempImage1[x][y - 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y - 1];
					if(tempImage1[x + 1][y - 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y - 1] ;
					if(tempImage1[x - 1][y] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y];
					if(tempImage1[x + 1][y] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y];
				}
				//If it made it past all of those, then it must be in the center region.
				else
				{
					if(tempImage1[x - 1][y - 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y - 1];
					if(tempImage1[x][y - 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y - 1];
					if(tempImage1[x + 1][y - 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y - 1] ;
					if(tempImage1[x - 1][y] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y];
					if(tempImage1[x + 1][y] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y];
					if(tempImage1[x - 1][y + 1]> tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y + 1];
					if(tempImage1[x][y + 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y + 1];
					if(tempImage1[x + 1][y + 1] > tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y + 1];
				}
			}
		}
	} while(numDilations < dilationSteps);
	
	return tempImage2;
}

TNT::Array2D<int>  dilateMinimaReturnTNTArray(TNT::Array2D< int > imageArray, const int dilationSteps)
{
	int width, height;
	width = imageArray.dim1();
	height = imageArray.dim2();
	
	//find local maxima--similar to getBlob
	TNT::Array2D<int> tempImage1(width, height);
	TNT::Array2D<int> tempImage2(width, height);
	
	int y;
	tempImage2 = imageArray.copy();
	
	//Dilate the image.
	int numDilations = 0;//Used to keep track of how many new pixels are highlighted each iteration.
	do{
		numDilations++;
		tempImage1 = tempImage2.copy();
#pragma omp parallel for
		for (y = 0; y < height; y++)
		{
			int x;
			for (x = 0; x < width; x++)
			{
				//Now for the individual places on the rectangular image where the spot can be.
				//First check to see whether it is in a corner
				if(x == 0 && y == 0)
				{
					if(tempImage1[x + 1][y] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y];
					if(tempImage1[x][y + 1]< tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y + 1];
					if(tempImage1[x + 1][y + 1] < tempImage2[x + 1][y + 1])
						tempImage2[x][y] = tempImage1[x + 1][y];
				}
				
				else if(x == width - 1 && y == 0)
				{
					
					if(tempImage1[x - 1][y]< tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y];
					if(tempImage1[x - 1][y + 1]< tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y + 1];
					if(tempImage1[x][y + 1]< tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y + 1];
				}
				else if(x == 0 && y == height - 1)
				{
					if(tempImage1[x][y - 1]< tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y - 1];
					if(tempImage1[x + 1][y - 1] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y - 1] ;
					if(tempImage1[x + 1][y]< tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y];
				}							
				
				else if(x == width - 1 && y == height - 1)
				{
					if(tempImage1[x - 1][y - 1] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y - 1];
					if(tempImage1[x][y - 1]< tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y - 1];
					if(tempImage1[x - 1][y] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y];
				}
				//Now check to see whether it is on a side
				else if(x == 0)
				{
					if(tempImage1[x][y - 1] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y - 1];
					if(tempImage1[x + 1][y - 1] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y - 1] ;
					if(tempImage1[x + 1][y] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y];
					if(tempImage1[x][y + 1] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y + 1];
					if(tempImage1[x + 1][y + 1] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y + 1];
				}
				else if(x == width - 1)
				{
					if(tempImage1[x - 1][y - 1] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y - 1];
					if(tempImage1[x][y - 1] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y - 1];
					if(tempImage1[x - 1][y] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y];
					if(tempImage1[x - 1][y + 1]< tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y + 1];
					if(tempImage1[x][y + 1] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y + 1];
				}
				else if(y == 0)
				{
					if(tempImage1[x - 1][y] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y];
					if(tempImage1[x + 1][y] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y];
					if(tempImage1[x - 1][y + 1]< tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y + 1];
					if(tempImage1[x][y + 1] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y + 1];
					if(tempImage1[x + 1][y + 1] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y + 1];
				}
				else if(y == height - 1)
				{
					
					if(tempImage1[x - 1][y - 1] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y - 1];
					if(tempImage1[x][y - 1] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y - 1];
					if(tempImage1[x + 1][y - 1] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y - 1] ;
					if(tempImage1[x - 1][y] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y];
					if(tempImage1[x + 1][y] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y];
				}
				//If it made it past all of those, then it must be in the center region.
				else
				{
					if(tempImage1[x - 1][y - 1] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y - 1];
					if(tempImage1[x][y - 1] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y - 1];
					if(tempImage1[x + 1][y - 1] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y - 1] ;
					if(tempImage1[x - 1][y] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y];
					if(tempImage1[x + 1][y] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y];
					if(tempImage1[x - 1][y + 1]< tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x - 1][y + 1];
					if(tempImage1[x][y + 1] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x][y + 1];
					if(tempImage1[x + 1][y + 1] < tempImage2[x][y])
						tempImage2[x][y] = tempImage1[x + 1][y + 1];
				}
			}
		}
	} while(numDilations < dilationSteps);
	
	return tempImage2;
}

TNT::Array2D<int> cropImageCenteringOnSpot(TNT::Array2D<int> imageArray, double xMaximum, double yMaximum, double spotRadius)
{
	unsigned short width, height;
	width = imageArray.dim1();
	height = imageArray.dim2();
	
	int minXRange =  xMaximum - (2.0L * spotRadius);
	if(minXRange < 0)
		minXRange = 0;
	
	int minYRange =  yMaximum - (2.0L * spotRadius);
	if(minYRange < 0)
		minYRange = 0;	
	
	int maxXRange =  xMaximum + (2.0L * spotRadius);
	if(maxXRange > width)
		maxXRange = width;
	
	int maxYRange =  yMaximum + (2.0L * spotRadius);
	if(maxYRange > height)
		maxYRange = height;
	
	TNT::Array2D<int> croppedImage(maxXRange - minXRange, maxYRange - minYRange);
	int x, y;
	for (x = minXRange; x < maxXRange; x++)
		for (y = minYRange; y < maxYRange; y++)
		{
			croppedImage[x - minXRange][y - minYRange] = imageArray[x][y];
		}	
	return croppedImage;
}

int returnMinimumPixelIntensity(TNT::Array2D< int > imageArray)
{
	//unsigned int minimumPixelIntensity = 65535;//All the CCD images should actually be 14 bit.
	int minimumPixelIntensity = 65535;//All the CCD images should actually be 14 bit.

	int width, height;
	width = imageArray.dim1();
	height = imageArray.dim2();
	
	register int x,y;
	for(x = 0; x < width; x++)
		for(y = 0; y < height; y++)
			if(imageArray[x][y] < minimumPixelIntensity)
				minimumPixelIntensity = imageArray[x][y];
	return minimumPixelIntensity;
}

int returnMaximumPixelIntensity(TNT::Array2D< int > imageArray)
{
	//unsigned int maximumPixelIntensity = 0;//All the CCD images should actually be 14 bit.
	int maximumPixelIntensity = 0;//All the CCD images should actually be 14 bit.

	int width, height;
	width = imageArray.dim1();
	height = imageArray.dim2();
	
	register int x,y;
	for(x = 0; x < width; x++)
		for(y = 0; y < height; y++)
			if(imageArray[x][y] > maximumPixelIntensity)
				maximumPixelIntensity = imageArray[x][y];
	return maximumPixelIntensity;
}


double returnMeanPixelIntensity(TNT::Array2D< int > imageArray)
{
	double meanPixelIntensity = 0;//All the CCD images should actually be 14 bit.
	
	double width, height;
	width = imageArray.dim1();
	height = imageArray.dim2();
	double inverseTotalPixels = 1.0L/(width * height);
	
	register int x,y;
	for(x = 0; x < width; x++)
		for(y = 0; y < height; y++)
			meanPixelIntensity += (double)(imageArray[x][y]) * inverseTotalPixels;
	return meanPixelIntensity;
}


TNT::Array2D< int > scaleImageMinToMax(TNT::Array2D< int > imageArray)
{
	int width, height;
	width = imageArray.dim1();
	height = imageArray.dim2();
	
	const int maximumPixelIntensity = returnMaximumPixelIntensity(imageArray);
	const int minimumPixelIntensity = returnMinimumPixelIntensity(imageArray);
	
	const int maxPossiblePixelIntensity = 65535/4;//maximum allowed unsigned int value (16 bit)

	double conversionFactor = (double)maxPossiblePixelIntensity/(double)(maximumPixelIntensity - minimumPixelIntensity);
	
	TNT::Array2D<int> scaledImage(width, height);
	
	register int x, y;
	for(y = 0; y < height; y++) 
	{ 
		for(x = 0; x < width; x++) 
		{ 
			scaledImage[x][y] = (double)(imageArray[x][y]) - minimumPixelIntensity;
			scaledImage[x][y] = (int)(conversionFactor * (double)(imageArray[x][y]));
		}
	}
	return scaledImage;
}


TNT::Array2D<int>  scaleImageMinToMax(TNT::Array2D< int > imageArray, int newMin, int newMax)
{
	int width, height;
	width = imageArray.dim1();
	height = imageArray.dim2();
	
	const int maximumPixelIntensity = returnMaximumPixelIntensity(imageArray);
	const int minimumPixelIntensity = returnMinimumPixelIntensity(imageArray);
	
	//const int maxPossiblePixelIntensity = 65535/4;//maximum allowed unsigned int value (16 bit)
	
	double conversionFactor = ((double)newMax-(double)newMin)/(double)(maximumPixelIntensity - minimumPixelIntensity);
	
	//find local maxima--similar to getBlob
	TNT::Array2D<int> scaledImage(width, height);
	
	register int x, y;
	for(y = 0; y < height; y++) 
	{ 
		for(x = 0; x < width; x++) 
		{ 
			scaledImage[x][y] = (double)(imageArray[x][y]) - minimumPixelIntensity;
			scaledImage[x][y] = (int)(conversionFactor * (double)(imageArray[x][y])) + newMin;
		}
	}
	return scaledImage;
}





TNT::Array2D<int> changeNegativePixelsToZero(TNT::Array2D< int > imageArray)
{
	int width, height;
	width = imageArray.dim1();
	height = imageArray.dim2();
	
	TNT::Array2D<int> scaledImage(width, height);
	
	register int x, y;
	for(y = 0; y < height; y++) 
	{ 
		for(x = 0; x < width; x++) 
		{ 
			if(imageArray[x][y] > -1)
				scaledImage[x][y] = imageArray[x][y];
			else
				scaledImage[x][y] = 0;
		}
	}
	return scaledImage;
}


