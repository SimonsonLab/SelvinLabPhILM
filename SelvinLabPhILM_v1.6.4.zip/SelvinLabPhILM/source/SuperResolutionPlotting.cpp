//
//  SuperResolutionPlotting.cpp
//  SelvinLabPhILM_XCode
//
//  Created by Paul Simonson on 8/3/11.
//  Copyright 2011 University of Illinois at Urbana-Champaign. All rights reserved.
//

#include <omp.h>
#include <iostream>
#include "SuperResolutionPlotting.h"
#include "SimonsonLibTIFF_IO.h"
#include "PhILMPreferences.h"
#include "ScienceFile.h"
#include "twoDGaussianFit.h"
#include "PhILMCoreCode.h"

extern class PhILMPreferences thePhILMPreferences;

namespace SuperResolutionPlotting 
{
    
    void PixelsPlot::movePastHeaderLines(std::ifstream &indata)
    {
        char line[2000];
		char c;
		while((c = indata.peek()) == '#')//move down until the first character of the line is not #
		{
			indata.getline(line, 2000);
			std::cout << indata << "\n";
		}
		while((c = indata.peek()) == '%')//move down until the first character of the line is not %
		{
			indata.getline(line, 2000);
			//std::cout << indata << "\n";
		}
    }
    
    
    int PixelsPlot::readALineInAsSpotFit(std::ifstream &indata, TwoDGaussianFittingParametersAndErrors &spotFit, int &normalSpotFlag)
    {
        char line[2000];
        
        int frameWherePhotobleachingOccurs;
        indata	>> std::scientific 
        >> spotFit.peakHeight 
        >> spotFit.xCenterValue >> spotFit.yCenterValue 
        >> spotFit.xWidth >> spotFit.yWidth >> spotFit.background >> spotFit.tiltAngle
        >> spotFit.peakHeightError 
        >> spotFit.xCenterValueError >> spotFit.yCenterValueError 
        >> spotFit.xWidthError >> spotFit.yWidthError >> spotFit.backgroundError >> spotFit.tiltAngleError
        >> frameWherePhotobleachingOccurs 
        >> frameWherePhotobleachingOccurs
        >> normalSpotFlag
        >> normalSpotFlag
        >> normalSpotFlag;
        indata.getline(line, 2000);//finish off the line...
        
        return frameWherePhotobleachingOccurs;
    }
    
    
    TwoDGaussianFittingParametersAndErrors PixelsPlot::returnSpotFitScaledForSuperResolutionPixels(TwoDGaussianFittingParametersAndErrors spotFit, int frameWherePhotobleachingOccurs)
    {
        TwoDGaussianFittingParametersAndErrors scaledSpotFit = spotFit;
        
        
        if(usingStageDriftCorrection)
        {
            scaledSpotFit.xCenterValue += stageDriftCorrectionFile.at(0, 1) - stageDriftCorrectionFile.at(frameWherePhotobleachingOccurs - 1, 1);
            scaledSpotFit.yCenterValue += stageDriftCorrectionFile.at(0, 2) - stageDriftCorrectionFile.at(frameWherePhotobleachingOccurs - 1, 2);
            if (verboseOutput) {
                std::cout << "Applied stage correction...  x0 = " << scaledSpotFit.xCenterValue << ", y0 = " << scaledSpotFit.yCenterValue << "\n";
            }
        }
        
        scaledSpotFit.xCenterValue += pixelShiftForDrawingSuperResolutionImages;
        scaledSpotFit.yCenterValue += pixelShiftForDrawingSuperResolutionImages;
        scaledSpotFit.xCenterValue *= zoomFactor;
        scaledSpotFit.yCenterValue *= zoomFactor;
        scaledSpotFit.xCenterValueError *= zoomFactor;
        scaledSpotFit.yCenterValueError *= zoomFactor;
        
        if (verboseOutput) {
            std::cout << scaledSpotFit.peakHeight << "	" << scaledSpotFit.xCenterValue << "	" << scaledSpotFit.yCenterValue << "	" << scaledSpotFit.xCenterValueError << "	" << scaledSpotFit.yCenterValueError << "\n";
        }
        
        return scaledSpotFit;
    }
    
    
    void PixelsPlot::plotSingleSpot(TwoDGaussianFittingParametersAndErrors scaledSpotFit, TNT::Array2D<int> superResolutionImage)
    {
        if ((int)scaledSpotFit.xCenterValue >= 0 
            && (int)scaledSpotFit.yCenterValue >= 0 
            && (int)scaledSpotFit.xCenterValue < superResolutionImage.dim1()
            && (int)scaledSpotFit.yCenterValue < superResolutionImage.dim2()) //There can be problems when stage drift correction is used.
        {
            if (verboseOutput) {
                std::cout << (int)scaledSpotFit.xCenterValue << "	" << (int)scaledSpotFit.yCenterValue << "\n";
            }
            superResolutionImage[(int)scaledSpotFit.xCenterValue][(int)scaledSpotFit.yCenterValue] += 1;
        }
        else {
            numSpotsDrawn--;
            if (verboseOutput) {
                std::cout << "The pixel location was out of range, and therefore the spot was not drawn.\n";
            }
        }
    }
    
    
    void PixelsPlot::plotSpotFits(void)
	{	
        std::cout << "Drawing super-resolution image using " << plottingMethodName << "...\n";
		
		//1
        usingStageDriftCorrection = checkWhetherFileIsPresent(thePhILMPreferences.prefixWithOutputDirectory("stageDriftCorrection.txt").c_str());
        
		if(usingStageDriftCorrection)
		{
			std::cout << thePhILMPreferences.prefixWithOutputDirectory("stageDriftCorrection.txt") << " was found and will be used in drawing spots.\n";
			stageDriftCorrectionFile.loadFromFile(thePhILMPreferences.prefixWithOutputDirectory("stageDriftCorrection.txt").c_str());
		}
        
		//3
        superResolutionImage = TNT::Array2D<int>(originalDim1 * zoomFactor, originalDim2 * zoomFactor, 0);
		
		//4
		//I would normally use the ScienceFile class, but it seems that the file is too large in some cases,
		//so I am reading the file one row at a time and drawing the spots.
		std::ifstream indata;
		indata.open(thePhILMPreferences.formOutputFilePath("spotFits.txt").c_str()); // opens the file
		if(!indata) { // file couldn't be opened
			std::cout << "Error: " << thePhILMPreferences.formOutputFilePath("spotFits.txt") << " could not be opened.\n" << "\n";
			exit(1);
		}
        movePastHeaderLines(indata);
        
		int frameWherePhotobleachingOccurs;
		int normalSpotFlag;		
		TwoDGaussianFittingParametersAndErrors spotFit;
		
        numNormalSpotsDrawn = 0;
        numAntiSpotsDrawn = 0;
        numSpotsDrawn = 0;
        
		while ( !indata.eof())
		{		
			if (verboseOutput) {
				std::cout << "Now drawing spot " << ++numSpotsDrawn << " in the super-resolution image.\n";
			}
			
            frameWherePhotobleachingOccurs = readALineInAsSpotFit(indata, spotFit, normalSpotFlag);
			
			if(PhILM_namespace::checkWhetherSpotIsGood(spotFit, true))
			{	
				TwoDGaussianFittingParametersAndErrors scaledSpotFit = returnSpotFitScaledForSuperResolutionPixels(spotFit, frameWherePhotobleachingOccurs);
                
                //Do the actual drawing.
                plotSingleSpot(scaledSpotFit, superResolutionImage);
                
				
				if(normalSpotFlag)
					numNormalSpotsDrawn++;
				else
					numAntiSpotsDrawn++;
			}
			else {
				if (verboseOutput) {
					std::cout << "Spot fit " << numSpotsDrawn << " was not drawn to the super-resolution image.\n";
				}
			}
			
            char line[2000];
			//jump out if the first character in the next line is '\n'
			if(indata.peek() == '\n')
				indata.getline(line, 2000);//finish off the line...
			//jump out if the first character in the next line is '\r'
			if(indata.peek() == '\r')
				indata.getline(line, 2000);//finish off the line...
		}
		indata.close();
        
		std::cout << "Number of spots drawn as a result of going from fluorescent to dark state: " << numNormalSpotsDrawn << "\n";
		std::cout << "Number of spots drawn as a result of going from dark to fluorescent state: " << numAntiSpotsDrawn << "\n";
		
        std::cout << "Now writing the super-resolution image to disk...\n";
		SimonsonLibTIFF_IO::writeTIFFFile(outputTIFFFileName, superResolutionImage);
		std::cout << "\a";
	}
    
    ///NormalizedSpotsPlot methods
    
    class PlottingRange {
    public:
		int minXRange, maxXRange, minYRange, maxYRange;
	};
	
	
	struct PlottingRange determineSpotPlottingRange(TNT::Array2D<int> superResolutionImage, TwoDGaussianFittingParametersAndErrors &spotFit, double numGaussiansInRange = 4.0)
	{
		struct PlottingRange plotRange;
		
		int width = superResolutionImage.dim1();
		int height = superResolutionImage.dim2();
		
		plotRange.minXRange = spotFit.xCenterValue - numGaussiansInRange * spotFit.xCenterValueError;
		plotRange.maxXRange = spotFit.xCenterValue + numGaussiansInRange * spotFit.xCenterValueError;
		plotRange.minYRange = spotFit.yCenterValue - numGaussiansInRange * spotFit.yCenterValueError;
		plotRange.maxYRange = spotFit.yCenterValue + numGaussiansInRange * spotFit.yCenterValueError;
		
		if(plotRange.minXRange < 0)
			plotRange.minXRange = 0;
		if(plotRange.minYRange < 0)
			plotRange.minYRange = 0;
		if(plotRange.maxXRange > width)
			plotRange.maxXRange = width;
		if(plotRange.maxYRange > height)
			plotRange.maxYRange = height;
		
		return plotRange;
	}
    
    const double sqrt2 = sqrt(2.0);
    
    double RoundNormalizedSpotsPlot::round2DGaussianIntegratedOverPixel(double x, 
                                              double y, 
                                              double peakHeight, 
                                              double x0, 
                                              double y0, 
                                              double sigma)
	{
        double oneOversqrt2TimesSigma = 1.0/(sqrt2*sigma);
		return 0.5* peakHeight*M_PI*sigma*sigma*(erf(oneOversqrt2TimesSigma * (x-x0))-erf(oneOversqrt2TimesSigma *(1.0+x-x0)))*(erf(oneOversqrt2TimesSigma*(y-y0))-erf(oneOversqrt2TimesSigma*(1.0+y-y0)));
	}
    
    void RoundNormalizedSpotsPlot::plotSingleSpot(TwoDGaussianFittingParametersAndErrors spotFit, TNT::Array2D<int> superResolutionImage)
    {
		class PlottingRange plotRange = determineSpotPlottingRange(superResolutionImage, spotFit, 5);
		
        double sigma = 0.5*(spotFit.xCenterValueError + spotFit.yCenterValueError);
        //std::cout << spotFit.xCenterValueError << ", " << spotFit.yCenterValueError << ", " << sigma << "\n";
        
		double normalizationFactor = normalizedTotalSpotIntensity/(2.0 * M_PI * sigma * sigma * spotFit.peakHeight);
        
        int i;
#pragma omp parallel for
        for(i = plotRange.minXRange; i < plotRange.maxXRange; i++)
        {
            int j;
            for(j = plotRange.minYRange; j < plotRange.maxYRange; j++)
            {
                double plotValue = round2DGaussianIntegratedOverPixel((double)i-0.5, (double)j-0.5, spotFit.peakHeight, 
                                                                      spotFit.xCenterValue, 
                                                                      spotFit.yCenterValue, 
                                                                      sigma);
                
                plotValue *= normalizationFactor;
                //std::cout << plotValue << "\n";
                superResolutionImage[i][j] += plotValue;
                
                if (superResolutionImage[i][j] > 65535) {//maximum 16 bit integer value.
                    superResolutionImage[i][j] = 65535;
                }
            }
		}
	}
    
    
}
