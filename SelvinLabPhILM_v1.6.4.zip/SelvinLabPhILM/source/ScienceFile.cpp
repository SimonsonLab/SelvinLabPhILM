/*
 *  ScienceFile.cpp
 *  PositionAndFluorescenceTracker
 *
 *  Created by Paul Simonson on 2/9/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

//This should not require ScienceFileManipulation.

#include "ScienceFile.h"

#include "dataFileReader.h"
#include <iostream>
#include <fstream>

ScienceFile::ScienceFile()
{
	hasHeader = 0;
}

ScienceFile::ScienceFile(const char * cpath)
{
	hasHeader = 0;
	data = dataFileReader(cpath);
}

ScienceFile::ScienceFile(std::vector< std::vector<double> > newData)
{
	hasHeader = 0;
	data = newData;
}

int ScienceFile::loadFromFile(const char * cpath)
{
	data.clear();
	hasHeader = 0;
	data = dataFileReader(cpath);
	return 0;
}

void ScienceFile::clear(void)
{
	data.clear();
	hasHeader = 0;
}

std::vector<double> ScienceFile::returnRow(int row)
{
	int numRows = data.size();
	if(row < numRows)
		return data.at(row);
	else
		return data.at(numRows - 1);//Return the last row if you chose too big of a number.
}

std::vector<int> ScienceFile::returnRowAsIntegers(int row)
{
	int numRows = data.size();
	int numColumns = data.at(row).size();
	if(row < 0)
		row = 0;
	if(row > numRows - 1)
		row = numRows - 1; 
	int i;
	std::vector<int> result;
	for(i = 0; i < numColumns; i++)
		result.push_back((int)(data.at(row).at(i)));
	return result;
}


std::vector<double> ScienceFile::returnColumn(int column)
{
	int numRows = data.size();
	int numColumns = (data.at(0)).size();
	if(column > numColumns-1)
		column = numColumns-1;
	std::vector<double> returnColumn;
	returnColumn.reserve(numRows);
	int i;
	for(i = 0; i < numRows; i++)
		returnColumn.push_back((data.at(i)).at(column));
	return returnColumn;
}

void ScienceFile::display()
{
	//Display the file's data
	int rowCount, columnCount;
	rowCount = data.size();
	if(rowCount)
		columnCount = (data.at(0)).size();
	else {
		columnCount = 0;
	}

	std::cout << "The matrix is " << rowCount << " x " << columnCount << "\n";
	std::cout << header << "\n";
	int i, j;
	for (i = 0; i < rowCount; i++){
		for(j = 0; j < columnCount; j++){
			std::cout << (data.at(i)).at(j) << "	";
		}
		std::cout << "\n";
	}
}

void ScienceFile::displayRow(int row)
{
	//Display the file's data
	int rowCount, columnCount;
	rowCount = data.size();
	columnCount = (data.at(0)).size();
	//std::cout << "The matrix is " << rowCount << " x " << columnCount << "\n";
	int j;
	//for (i = 0; i < rowCount; i++){
	for(j = 0; j < columnCount; j++){
		std::cout << (data.at(row)).at(j) << "	";
	}
	std::cout << "\n";
	//}
}

int ScienceFile::writeToFile(const char * cpath)
{
	//Write to output file.
	std::ofstream outputFile; // indata is like cin
	outputFile.open(cpath); // opens the file
	if(!outputFile) { // file couldn't be opened
		std::cout << "Error: File " << cpath << " could not be opened for writing.\n";
		return -1;
	}
	
	if(data.size() > 0)
	{
		if (header.size()) {
			outputFile << header << "\n";
		}
		int rowCount, columnCount;
		rowCount = data.size();
		columnCount = (data.at(0)).size();
		int i, j;
		for (i = 0; i < rowCount; i++){
			for(j = 0; j < columnCount; j++){
				outputFile << (data.at(i)).at(j) << "	";
			}
			outputFile << "\n";
		}
	}
	else {
		std::cout << "Warning: there were no data to write to file " << cpath << ".\n";
	}
	
	outputFile.flush();
	
	if(outputFile)
		outputFile.close();
	return 0;
}

int ScienceFile::writeToFile(const char * cpath, const char * header)
{
	//Write to output file.
	std::ofstream outputFile; // indata is like cin
	outputFile.open(cpath); // opens the file
	if(!outputFile) { // file couldn't be opened
		std::cout << "Error: File " << cpath << " could not be opened for writing.\n";
		return -1;
	}
	
	outputFile << header << "\n";
	
	if(data.size() > 0)
	{
		int rowCount, columnCount;
		rowCount = data.size();
		columnCount = (data.at(0)).size();
		int i, j;
		for (i = 0; i < rowCount; i++){
			for(j = 0; j < columnCount; j++){
				outputFile << (data.at(i)).at(j) << "	";
			}
			outputFile << "\n";
		}
	}
	else {
		std::cout << "Warning: there were no data to write to file " << cpath << ".\n";
	}

	outputFile.flush();
	
	if(outputFile)
		outputFile.close();
	return 0;
}

double  ScienceFile::returnElement(unsigned x, unsigned y)
{
	return (data.at(x)).at(y);
}

double  ScienceFile::at(unsigned x, unsigned y)
{
	return (data.at(x)).at(y);
}

int  ScienceFile::setElement(unsigned x, unsigned y, double value)
{
	(data.at(x)).at(y) = value;
	return 0;
}

int ScienceFile::numRows(void)
{
	return data.size();
}

int ScienceFile::numColumns(void)
{
	return (data.at(0)).size();
}

int ScienceFile::addRow(std::vector<double> inputVector)
{
	data.push_back(inputVector);
	return 0;
}

int ScienceFile::addColumn(std::vector<double> inputVector)
{
	if(data.size() < 1)
	{
		std::vector<double> dummyVector;
		int N = inputVector.size();
		register int i;
		for(i = 0; i < N; i++)
			data.push_back(dummyVector);
	}
	
	int N = data.size();
	register int i;
	for(i = 0; i < N; i++)
		data.at(i).push_back(inputVector.at(i));
	return 0;
}

int ScienceFile::addColumn(std::vector<int> inputVector)
{
	if(data.size() < 1)
	{
		std::vector<double> dummyVector;
		int N = inputVector.size();
		register int i;
		for(i = 0; i < N; i++)
			data.push_back(dummyVector);
	}
	
	int N = data.size();
	register int i;
	for(i = 0; i < N; i++)
		data.at(i).push_back(inputVector.at(i));
	return 0;
}

int ScienceFile::addColumn(void)
{
	if(data.size() < 1)
	{
		std::vector<double> dummyVector(1, 0.0L);
		data.push_back(dummyVector);
		return -1;
	}
	
	int N = data.size();
	register int i;
	for(i = 0; i < N; i++)
		data.at(i).push_back(0.0L);
	return 0;
}

std::vector< std::vector<double> > ScienceFile::returnData(void)
{
	return data;
}

void ScienceFile::displayVector(std::vector<double> inputVector)
{
	//Display the file's data
	int rowCount;
	rowCount = inputVector.size();
	int i;
	for (i = 0; i < rowCount; i++){
		std::cout << inputVector.at(i) << "\n";
	}
}

void ScienceFile::displayVector(std::vector<int> inputVector)
{
	//Display the file's data
	int rowCount;
	rowCount = inputVector.size();
	int i;
	for (i = 0; i < rowCount; i++){
		std::cout << inputVector.at(i) << "\n";
	}
}




//Already defined in ScienceFileManipulation.cpp

double ScienceFile::findMin(std::vector<double> inputVector)
{
	int N = inputVector.size();
	int i;
	double minValue = inputVector.at(0);
	for(i = 0; i < N; i++)
		if(inputVector.at(i) < minValue)
			minValue = inputVector.at(i);
	return minValue;
}

double ScienceFile::findMax(std::vector<double> inputVector)
{
	int N = inputVector.size();
	int i;
	double maxValue = inputVector.at(0);
	for(i = 0; i < N; i++)
		if(inputVector.at(i) > maxValue)
			maxValue = inputVector.at(i);
	return maxValue;
}
