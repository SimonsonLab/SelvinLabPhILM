//includes
#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <sys/stat.h>
#include <ctime>
#include <omp.h>

#include "PhILMCoreCode.h"
#include "PhILMExtras.h"
#include "PhILMMicrotubuleExtras.h"
#include "drawingSuperResolutionImages.h"
#include "detectParticlesClass.h"
#include "tiffStackOperations.h"
//#include "return2DArrayFromMultiBitmap.h"
#include "tiffFrameOperations.h"
//#include "writeTIFFFileUsingMagick.h"
#include "returnDataForGaussianFitting.h"
#include "fitTo2DEllipticalGaussian.h"
#include "FastPhILM.h"
#include "ExponentialDecayFit.h"
#include "SimonsonLibTIFF_IO.h"
#include "SuperResolutionPlotting.h"
#include "MLE2DGaussianFitterGaussian.h"
//const std::string programVersion = __TIMESTAMP__;

using namespace PhILM_namespace;
using namespace Fitting2DEllipticalGaussianUsingGSL;
using namespace DrawingSuperResolutionImages;

extern class PhILMPreferences thePhILMPreferences;


///This function is for showing the command line usage of the program.
int displayHelp(void)
{
	std::cout << "Batch usage is 'SelvinLabPhILM -mainMenuSelection tiffFileName minimumSpotSeparation detectionThreshold zoomFactor outputDirectory outputFilePrefix'.\n";
	return 0;
}

void displayProgramOptions(void)
{
	std::cout	<< "Main Menu Selections:\n" 
	<<	"-------Perform all the steps to create a super-rsolution image-------\n"
	<<	"A.	Create a super-resolution image from photobleaching/blinking movie\n"
	<<	"B.	QuickPhILM--this runs faster but does no frame averaging\n"
	<<	"-------or, step by step using the following-------\n"
	<<	"a.	Step 1: Create the backwards-subtracted TIFF\n"
	<<	"b.	Step 2: Detect spots\n"
	<<	"c.	Step 3: Detect anti-spots\n"
	<<	"d.	-Alternate to steps 4 & 5-: Fit spots in backwards-subtracted TIFF\n"
	<<	"e.	Step 4: Calculate spot frame ranges\n"
	<<	"f.	Step 5: Perform the spot and anti-spot fitting\n"
	<<	"g.	Step 6a: Create the super-resolution image\n"
	<<	"h.	Step 6b: Create the super-resolution image using max z project\n"
	<<	"i.	Step 6c: Create the super-resolution image using pixels representation\n"
	<<	"m.	Step 6d: Create the super-resolution image using normalized spots representation\n\t(i.e., same as PALM by Betzig et al. 2006)\n"
	<<	"n.	Step 6e: Create the super-resolution image using PhILM representation\n"
    
	<<	"-------extras-------\n"
    
	<<	"k.	Estimate portion of fluorophores localized\n"
	<<	"l.	Estimate photobleaching lifetime\n"
	<<	"v.	Do simple 2D elliptical Gaussian fitting to a one-spot TIFF file to estimate stage drift.\n"
	<<	"w.	Concatenate spotFits.txt files\n"
	<<	"x.	Create drift correction file (center of mass measurement; you have to know what you are doing)\n"
	<<	"y.	Plot ons and offs in a single TIFF file.\n"
	<<	"q.	Quit\n\n"
	<<	"Please enter selection: ";
}

void displayCommandLineArguments(int argc, char *argv[])
{
	int i;
	for (i = 0; i < argc; i++)
	{
		std::cout << i << "	" << argv[i] << "\n";
	}
	
}

int updatePhILMPreferencesUsingCommandLineArguments(int argc, char *argv[], char mainSelection)
{
	switch (mainSelection) {
		case 'A':
		{
			if (argc > 5) {
				thePhILMPreferences.setTIFFFileName( argv[2]);
				thePhILMPreferences.minimumSpotSeparation = strtod(argv[3], NULL);
				thePhILMPreferences.detectionThreshold = strtod(argv[4], NULL);
				thePhILMPreferences.zoomFactor = strtod(argv[5], NULL);
			}
			else {
				std::cout << "Too few arguments supplied for option " << mainSelection << ".  Exiting.\n";
				return -1;
			}
		}
			break;
			
		case 'B':
		{
			if (argc > 5) {
				thePhILMPreferences.usingBatchMode = 1;
				thePhILMPreferences.setTIFFFileName( argv[2]);
				thePhILMPreferences.minimumSpotSeparation = strtod(argv[3], NULL);
				thePhILMPreferences.detectionThreshold = strtod(argv[4], NULL);
				thePhILMPreferences.zoomFactor = strtod(argv[5], NULL);
			}
			else {
				std::cout << "Too few arguments supplied for option " << mainSelection << ".  Exiting.\n";
				return -1;
			}
		}
			break;
			
		case 'a':
		{
			if (argc > 5) {
				thePhILMPreferences.setTIFFFileName( argv[2]);
				thePhILMPreferences.minimumSpotSeparation = strtod(argv[3], NULL);
				thePhILMPreferences.detectionThreshold = strtod(argv[4], NULL);
				thePhILMPreferences.zoomFactor = strtod(argv[5], NULL);
			}
			else {
				std::cout << "Too few arguments supplied for option " << mainSelection << ".  Exiting.\n";
				return -1;
			}
		}
			break;
			
		case 'b':
		{
			if (argc > 5) {
				thePhILMPreferences.setTIFFFileName( argv[2]);
				thePhILMPreferences.minimumSpotSeparation = strtod(argv[3], NULL);
				thePhILMPreferences.detectionThreshold = strtod(argv[4], NULL);
				thePhILMPreferences.zoomFactor = strtod(argv[5], NULL);
			}
			else {
				std::cout << "Too few arguments supplied for option " << mainSelection << ".  Exiting.\n";
				return -1;
			}
		}
			break;
			
		case 'c':
		{
			if (argc > 5) {
				thePhILMPreferences.setTIFFFileName( argv[2]);
				thePhILMPreferences.minimumSpotSeparation = strtod(argv[3], NULL);
				thePhILMPreferences.detectionThreshold = strtod(argv[4], NULL);
				thePhILMPreferences.zoomFactor = strtod(argv[5], NULL);
			}
			else {
				std::cout << "Too few arguments supplied for option " << mainSelection << ".  Exiting.\n";
				return -1;
			}
		}
			break;
		case 'd':
		{
			if (argc > 5) {
				thePhILMPreferences.setTIFFFileName( argv[2]);
				thePhILMPreferences.minimumSpotSeparation = strtod(argv[3], NULL);
				thePhILMPreferences.detectionThreshold = strtod(argv[4], NULL);
				thePhILMPreferences.zoomFactor = strtod(argv[5], NULL);
			}
			else {
				std::cout << "Too few arguments supplied for option " << mainSelection << ".  Exiting.\n";
				return -1;
			}
		}
			break;
		case 'e':
		{
			if (argc > 5) {
				thePhILMPreferences.setTIFFFileName( argv[2]);
				thePhILMPreferences.minimumSpotSeparation = strtod(argv[3], NULL);
				thePhILMPreferences.detectionThreshold = strtod(argv[4], NULL);
				thePhILMPreferences.zoomFactor = strtod(argv[5], NULL);
			}
			else {
				std::cout << "Too few arguments supplied for option " << mainSelection << ".  Exiting.\n";
				return -1;
			}
		}
			break;
		case 'f':
		{
			if (argc > 5) {
				thePhILMPreferences.setTIFFFileName( argv[2]);
				thePhILMPreferences.minimumSpotSeparation = strtod(argv[3], NULL);
				thePhILMPreferences.detectionThreshold = strtod(argv[4], NULL);
				thePhILMPreferences.zoomFactor = strtod(argv[5], NULL);
			}
			else {
				std::cout << "Too few arguments supplied for option " << mainSelection << ".  Exiting.\n";
				return -1;
			}
		}
			break;
		case 'g':
		{
			if (argc > 5) {
				thePhILMPreferences.setTIFFFileName( argv[2]);
				thePhILMPreferences.minimumSpotSeparation = strtod(argv[3], NULL);
				thePhILMPreferences.detectionThreshold = strtod(argv[4], NULL);
				thePhILMPreferences.zoomFactor = strtod(argv[5], NULL);
			}
			else {
				std::cout << "Too few arguments supplied for option " << mainSelection << ".  Exiting.\n";
				return -1;
			}
		}
			break;
		case 'h':
		{
			if (argc > 5) {
				thePhILMPreferences.setTIFFFileName( argv[2]);
				thePhILMPreferences.minimumSpotSeparation = strtod(argv[3], NULL);
				thePhILMPreferences.detectionThreshold = strtod(argv[4], NULL);
				thePhILMPreferences.zoomFactor = strtod(argv[5], NULL);
			}
			else {
				std::cout << "Too few arguments supplied for option " << mainSelection << ".  Exiting.\n";
				return -1;
			}
		}
			break;
		case 'i':
		{
			if (argc > 5) {
				thePhILMPreferences.setTIFFFileName( argv[2]);
				thePhILMPreferences.minimumSpotSeparation = strtod(argv[3], NULL);
				thePhILMPreferences.detectionThreshold = strtod(argv[4], NULL);
				thePhILMPreferences.zoomFactor = strtod(argv[5], NULL);
			}
			else {
				std::cout << "Too few arguments supplied for option " << mainSelection << ".  Exiting.\n";
				return -1;
			}
		}
			break;
			
			
		case 'm'://Draw normalized spot super-resolution image.
		{
			if (argc > 5) {
				thePhILMPreferences.setTIFFFileName( argv[2]);
				thePhILMPreferences.minimumSpotSeparation = strtod(argv[3], NULL);
				thePhILMPreferences.detectionThreshold = strtod(argv[4], NULL);
				thePhILMPreferences.zoomFactor = strtod(argv[5], NULL);
			}
			else {
				std::cout << "Too few arguments supplied for option " << mainSelection << ".  Exiting.\n";
				return -1;
			}
		}
			break;
			
			
		case 'n'://Draw normalized spot super-resolution image.
		{
			if (argc > 5) {
				thePhILMPreferences.setTIFFFileName( argv[2]);
				thePhILMPreferences.minimumSpotSeparation = strtod(argv[3], NULL);
				thePhILMPreferences.detectionThreshold = strtod(argv[4], NULL);
				thePhILMPreferences.zoomFactor = strtod(argv[5], NULL);
			}
			else {
				std::cout << "Too few arguments supplied for option " << mainSelection << ".  Exiting.\n";
				return -1;
			}
		}
			break;
			
			
		case 'j':
		{
			if (argc > 5) {
				thePhILMPreferences.setTIFFFileName( argv[2]);
				thePhILMPreferences.minimumSpotSeparation = strtod(argv[3], NULL);
				thePhILMPreferences.detectionThreshold = strtod(argv[4], NULL);
				thePhILMPreferences.zoomFactor = strtod(argv[5], NULL);
			}
			else {
				std::cout << "Too few arguments supplied for option " << mainSelection << ".  Exiting.\n";
				return -1;
			}
		}
			break;
			
		case 'k':
		{
			if (argc > 5) {
				thePhILMPreferences.setTIFFFileName( argv[2]);
				thePhILMPreferences.minimumSpotSeparation = strtod(argv[3], NULL);
				thePhILMPreferences.detectionThreshold = strtod(argv[4], NULL);
				thePhILMPreferences.zoomFactor = strtod(argv[5], NULL);
			}
			else {
				std::cout << "Too few arguments supplied for option " << mainSelection << ".  Exiting.\n";
				return -1;
			}
		}
			break;
			
		case 'l':
		{
			if (argc > 5) {
				thePhILMPreferences.setTIFFFileName( argv[2]);
				thePhILMPreferences.minimumSpotSeparation = strtod(argv[3], NULL);
				thePhILMPreferences.detectionThreshold = strtod(argv[4], NULL);
				thePhILMPreferences.zoomFactor = strtod(argv[5], NULL);
			}
			else {
				std::cout << "Too few arguments supplied for option " << mainSelection << ".  Exiting.\n";
				return -1;
			}
		}
			break;
			
			
            
			
		case 'z':
		{
			if (argc > 5) {
				thePhILMPreferences.setTIFFFileName(argv[2]);
				thePhILMPreferences.minimumSpotSeparation = strtod(argv[3], NULL);
				thePhILMPreferences.detectionThreshold = strtod(argv[4], NULL);
				thePhILMPreferences.zoomFactor = strtod(argv[5], NULL);
			}
			else {
				std::cout << "Too few arguments supplied for option " << mainSelection << ".  Exiting.\n";
				return -1;
			}
		}
			break;
			
			
		default:
			std::cout << "Option " << mainSelection << " is currently not recognized for use in batch mode.\n";
			return 0;
			break;
	}
	
	thePhILMPreferences.usingBatchMode = true;
	
	if (argc > 6) {
		thePhILMPreferences.outputDirectory = argv[6];
		mkdir(thePhILMPreferences.outputDirectory.c_str(), 0777);
	}
	
	if (argc > 7) {
		thePhILMPreferences.outputFilePrefix = argv[7];
	}
	
	return 0;
}


int handleCommandLineArguments(int argc, char *argv[], char &mainSelection)
{
	displayCommandLineArguments(argc, argv);
	
	if (!strcmp(argv[1], "--help")) {
		displayHelp();
		return 0;
	}
	
	mainSelection = argv[1][0];
	if(mainSelection == '-')
	{
		mainSelection = argv[1][1];
	}
	
	return updatePhILMPreferencesUsingCommandLineArguments(argc, argv, mainSelection);
}


void enterInputParameters(void)
{
	std::cout << "\nPlease enter a tiff file path (use Unix style, i.e., forward slashes): ";
	std::cin >> thePhILMPreferences.tiffFileName;
	checkForExitCommand(thePhILMPreferences.tiffFileName.c_str());
	thePhILMPreferences.chooseOutputDirectoryUsingTIFFName();
	
	std::cout << "Please enter minimum allowed spot separation: ";
	std::cin >> thePhILMPreferences.minimumSpotSeparation;
	
	std::cout << "Please enter detectionThreshold: ";
	std::cin >> thePhILMPreferences.detectionThreshold;
	
	std::cout << "Please enter zoomFactor: ";
	std::cin >> thePhILMPreferences.zoomFactor;
	
	//std::cout << "Please enter minimumNumberOfFramesToAverage: ";
	//std::cin >> thePhILMPreferences.minimumNumberOfFramesToAverage;
	
	//std::cout << "Please enter drawingIntensityScalingFactor: ";
	//std::cin >> thePhILMPreferences.drawingIntensityScalingFactor;
}


int main(int argc, char *argv[])
{    
	std::cout << "This program was written by:\nPaul D. Simonson\nSelvin Lab\nDepartment of Physics\nUniversity of Illinois at Urbana-Champaign\nCopyright 2009-2011\n";
	std::cout << "\nNote that this program only works with 16 bit TIFF files.\n\n";
		
    
	bool usingBatchMode = false;
	char mainSelection;
	
	if (argc > 1) 
	{		
		usingBatchMode = true;
		int errorValue = handleCommandLineArguments(argc, argv, mainSelection);
		if (errorValue) {
			std::cout << "Bad command line arguments.  Exiting...\n";
			return errorValue;
		}
	}
	else 
	{
		displayProgramOptions();
		mainSelection = std::cin.get();
		std::cin.ignore();
	}
	
	switch (mainSelection)
	{
		case 'A'://Do the analysis, start to end...
		{	
			std::cout << "\nYou selected option \"A.\"  This option performs all of the steps necessary to create a super-resolution image starting from a tiff file.  It finds photobleaching and photoactivation events, etc., and it does frame averaging wherever possible.\n";
			
			if(!usingBatchMode)
			{
				enterInputParameters();
			}
            
            thePhILMPreferences.saveCurrentPreferencesFile(thePhILMPreferences.formOutputFilePath("PhILMPreferences.txt"));

            clock_t startTime = clock();
            std::cout << "Elapsed time = " << (clock() - startTime)/(60.0* CLOCKS_PER_SEC) << " minutes.\n";
            
            
            //0
            std::cout << "\nLoading TIFF file...\n";
            std::vector< TNT::Array2D< int > > imageVector;
            SimonsonLibTIFF_IO::readTIFFStack(thePhILMPreferences.tiffFileName, imageVector);
            std::cout << "Number of frames in image vector = " << imageVector.size() << ".\n";

			//1
			std::cout << "\nCreating backwards-subtracted TIFF stack...\n";
			//quicklySequentiallyBackwardsSubtractFramesUsingFreeImage(thePhILMPreferences.tiffFileName.c_str(), thePhILMPreferences.formOutputFilePath("backwardsSubtracted.tif").c_str());
            //quicklySequentiallyBackwardsSubtractFramesUsingLibTIFF(thePhILMPreferences.tiffFileName.c_str(), thePhILMPreferences.formOutputFilePath("backwardsSubtracted.tif").c_str());
            std::vector< TNT::Array2D< int > > backwardsSubtractedStack = returnBackwardsSubtracted(imageVector);
			std::cout << "Elapsed time = " << (clock() - startTime)/(60.0* CLOCKS_PER_SEC) << " minutes.\n";
            
			//2
			std::cout << "\nDetecting spots in backwards-subtracted TIFF stack.\n";
			DetectParticlesClass spotDetector;
			//spotDetector.setWriteOutputTIFFsFlag(thePhILMPreferences.writeDetectedSpotsTIFFFiles);
            spotDetector.particleDetectionMethod = thePhILMPreferences.spotDetectionMethod;
			spotDetector.outputDirectory = thePhILMPreferences.outputDirectory;
			spotDetector.outputFilePrefix = thePhILMPreferences.outputFilePrefix;
            spotDetector.detectParticles(backwardsSubtractedStack, 
                                         thePhILMPreferences.formOutputFilePath("detectedSpots.txt").c_str(), 
                                         1, -1, 0, thePhILMPreferences.dilationSteps, thePhILMPreferences.spotDetectionIntegrationRadius, 
                                         thePhILMPreferences.detectionThreshold, 
                                         0, 0.0001, 10, 20, 1, thePhILMPreferences.backwardsSubtractedImageZeroPoint);
			std::cout << "Elapsed time = " << (clock() - startTime)/(60.0* CLOCKS_PER_SEC) << " minutes.\n";

            DetectParticlesClass antiSpotDetector;
            antiSpotDetector.particleDetectionMethod = thePhILMPreferences.spotDetectionMethod;
			antiSpotDetector.outputDirectory = thePhILMPreferences.outputDirectory;
			antiSpotDetector.outputFilePrefix = thePhILMPreferences.outputFilePrefix;
            antiSpotDetector.detectParticles(backwardsSubtractedStack, 
                                         thePhILMPreferences.formOutputFilePath("detectedAntiSpots.txt").c_str(), 
                                         1, -1, 0, thePhILMPreferences.dilationSteps, thePhILMPreferences.spotDetectionIntegrationRadius, 
                                         thePhILMPreferences.detectionThreshold, 
                                         0, 0.0001, 10, 20, 0, thePhILMPreferences.backwardsSubtractedImageZeroPoint);
            std::cout << "Elapsed time = " << (clock() - startTime)/(60.0* CLOCKS_PER_SEC) << " minutes.\n";
            std::cout.flush();
            
            //Write the detected spots files.
            if(thePhILMPreferences.writeDetectedSpotsTIFFFiles)
            {
                std::cout << "Writing detected spots TIFF.\n";
                spotDetector.createDetectedSpotsTIFF(imageVector);
                std::cout << "Writing detected anti-spots TIFF.\n";
                antiSpotDetector.createDetectedSpotsTIFF(imageVector);
                std::cout << "Writing backwards subtracted tiff.\n";
                SimonsonLibTIFF_IO::writeTIFFStack(thePhILMPreferences.formOutputFilePath("backwardsSubtracted.tif").c_str(), backwardsSubtractedStack);
            }
            else
            {
                std::cout << "Set the writeDetectedSpotsTIFFFiles flag if you want to write the backwards-subtracted TIFF to disk using option A in the main menu.\n";
            }
            backwardsSubtractedStack.clear();
            spotDetector.detectedSpots.clear();
            antiSpotDetector.detectedSpots.clear();
            
            //3
            std::cout << "\nCalculating frame averaging ranges...\n";
            fastCalculateSpotFrameRanges(thePhILMPreferences.tiffFileName.c_str(), thePhILMPreferences.minimumSpotSeparation);            
            std::cout << "Elapsed time = " << (clock() - startTime)/(60.0* CLOCKS_PER_SEC) << " minutes.\n";
            
            fastCalculateAntiSpotFrameRanges(thePhILMPreferences.tiffFileName.c_str(), thePhILMPreferences.minimumSpotSeparation);
            std::cout << "Elapsed time = " << (clock() - startTime)/(60.0* CLOCKS_PER_SEC) << " minutes.\n";
            if (thePhILMPreferences.throwAwayIntermediateFrames) 
            {
                throwAwayIntermediateFramesUsingFrameRangesFiles();
            }
            
            
            //4
            std::cout << "\nFitting averaged spots...\n";
            //int numGoodFits =             
            createSpotFitsFile(imageVector, 
                               thePhILMPreferences.minimumNumberOfFramesToAverage, 
                               thePhILMPreferences.darkCountsNoise);
            std::cout << "Elapsed time = " << (clock() - startTime)/(60.0* CLOCKS_PER_SEC) << " minutes.\n";
            
            
            
            //5
            std::cout << "\nDrawing super-resolution images...\n";
            quicklyDrawSpotsInSuperResolutionImage(thePhILMPreferences.tiffFileName.c_str(), 
                                                   thePhILMPreferences.formOutputFilePath("superResolutionImage.tif").c_str(), 
                                                   thePhILMPreferences.zoomFactor, 
                                                   thePhILMPreferences.drawingIntensityScalingFactor, standard);
            
            quicklyDrawSpotsInSuperResolutionImage(thePhILMPreferences.tiffFileName.c_str(), 
                                                   thePhILMPreferences.formOutputFilePath("superResolutionImage.maxZProject.tif").c_str(), 
                                                   thePhILMPreferences.zoomFactor, 
                                                   thePhILMPreferences.drawingIntensityScalingFactor, 
                                                   maxZProject);
            
            /*
            quicklyDrawSpotsInSuperResolutionImage(thePhILMPreferences.tiffFileName.c_str(), 
                                                   thePhILMPreferences.formOutputFilePath("superResolutionImage.pixels.tif").c_str(), 
                                                   thePhILMPreferences.zoomFactor, 1, pixels);
            */
            
            drawSuperResolutionImageUsingNormalizedSpots(thePhILMPreferences.tiffFileName.c_str(), 
                                                         thePhILMPreferences.formOutputFilePath("superResolutionImage.normalizedSpots.tif").c_str(), 
                                                         thePhILMPreferences.zoomFactor, 
                                                         thePhILMPreferences.drawingIntensityScalingFactor);
            
            quicklyDrawSpotsInSuperResolutionImage(thePhILMPreferences.tiffFileName.c_str(), 
                                                   thePhILMPreferences.formOutputFilePath("superResolutionImage.PhILM.tif").c_str(), 
                                                   thePhILMPreferences.zoomFactor, 1, PhILMDrawingStyle);
            
            std::cout.flush();
            
            class SuperResolutionPlotting::PixelsPlot pixelsPlot2;
            pixelsPlot2.outputTIFFFileName = thePhILMPreferences.formOutputFilePath("superResolutionImage.pixels.tif");
            pixelsPlot2.zoomFactor = thePhILMPreferences.zoomFactor;
            pixelsPlot2.originalDim1 = imageVector.at(0).dim1();
            pixelsPlot2.originalDim2 = imageVector.at(0).dim2();
            pixelsPlot2.plotSpotFits();
            
            class SuperResolutionPlotting::RoundNormalizedSpotsPlot normalizedSRPlot;
            normalizedSRPlot.outputTIFFFileName = thePhILMPreferences.formOutputFilePath("superResolutionImage.roundNormalized.tif");
            normalizedSRPlot.zoomFactor = thePhILMPreferences.zoomFactor;
            normalizedSRPlot.originalDim1 = imageVector.at(0).dim1();
            normalizedSRPlot.originalDim2 = imageVector.at(0).dim2();
            normalizedSRPlot.plotSpotFits();
            
            std::cout << "Elapsed time = " << (clock() - startTime)/(60.0* CLOCKS_PER_SEC) << " minutes.\n";
            
            

            
                      /*
             //6
             std::cout << "The estimated portion of fluorophores localized is " << estimatePortionOfFluorophoresLocalized(numGoodFits, thePhILMPreferences.tiffFileName.c_str()) << ".\n";
             
             //7
             std::cout << "Now estimating photobleaching lifetime...\n";
             class PhotobleachingLifetimeEstimate lifetimeEstimate;
             lifetimeEstimate.writeXYFitData(thePhILMPreferences.formOutputFilePath("photobleachingLifetimeFit.txt").c_str());
             */
            
            
			//8
			std::cout << "\a\a\a\a\a";
			std::cout << "\nTotal time to process " << thePhILMPreferences.tiffFileName << " was " << (clock() - startTime)/(60.0* CLOCKS_PER_SEC) << " minutes after starting algorithm.\n";
			std::cout << "\nNote that if your superResolution.tif file is blank, you probably need to choose option 'g', 'h', or 'i' and choose a smaller drawingIntensityScalingFactor value.\n";
            //std::cout << "Elapsed time = " << (clock() - startTime)/(60.0* CLOCKS_PER_SEC) << " minutes.\n";
            //std::cout << "Number of frames in image vector = " << imageVector.size() << ".\n";
            

            thePhILMPreferences.retrospectivelySuggestDetectionThreshold(argc, argv);
		}
			break;
			
			
		case 'B'://Do the analysis, start to end...
		{	
			FastPhILM PhILMObject;
			PhILMObject.startToFinish();
		}
			break;
			
			
		case 'a'://Step 1: create the backwards-subtracted image sequence
		{
			if(!usingBatchMode)
			{
				std::cout << "\nPlease enter a file path (use Unix style, i.e., forward slashes): ";
				std::cin >> thePhILMPreferences.tiffFileName;
				checkForExitCommand(thePhILMPreferences.tiffFileName.c_str());
			}
			
            quicklySequentiallyBackwardsSubtractFramesUsingLibTIFF(thePhILMPreferences.tiffFileName.c_str(), thePhILMPreferences.formOutputFilePath("backwardsSubtracted.tif").c_str());
            
			std::cout << "\a";
		}
			break;
			
			
		case 'b'://detect postitive particles
		{
			if(!usingBatchMode)
			{
				std::cout << "Please enter detectionThreshold: ";
				std::cin >> thePhILMPreferences.detectionThreshold;				
			}
			
			DetectParticlesClass spotDetector;
            
            spotDetector.setWriteOutputTIFFsFlag(thePhILMPreferences.writeDetectedSpotsTIFFFiles);
            
			spotDetector.detectParticlesUsingFreeImage(thePhILMPreferences.formOutputFilePath("backwardsSubtracted.tif").c_str(), thePhILMPreferences.formOutputFilePath("detectedSpots.txt").c_str(), 1, -1, 0, thePhILMPreferences.dilationSteps, thePhILMPreferences.spotDetectionIntegrationRadius, thePhILMPreferences.detectionThreshold, 0, 0.0001, 10, 20, 1, thePhILMPreferences.backwardsSubtractedImageZeroPoint);

		}
			break;
			
			
		case 'c'://detect anti-particles
		{
			if(!usingBatchMode)
			{
				std::cout << "Please enter detectionThreshold: ";
				std::cin >> thePhILMPreferences.detectionThreshold;				
			}
			
			DetectParticlesClass spotDetector;
            spotDetector.setWriteOutputTIFFsFlag(thePhILMPreferences.writeDetectedSpotsTIFFFiles);
			spotDetector.detectParticlesUsingFreeImage(thePhILMPreferences.formOutputFilePath("backwardsSubtracted.tif").c_str(), thePhILMPreferences.formOutputFilePath("detectedAntiSpots.txt").c_str(), 1, -1, 0, thePhILMPreferences.dilationSteps, thePhILMPreferences.spotDetectionIntegrationRadius, thePhILMPreferences.detectionThreshold, 0, 0.0001, 10, 20, 0, thePhILMPreferences.backwardsSubtractedImageZeroPoint);
			//std::cout << "Finished detecting spots and anti-spots after " << Q.read()/60 << " minutes after starting algorithm.\n";
			
		}
			break;
			
			
		case 'd'://	<<	"d.	-Alternate to steps 4 & 5-: Fit spots in backwards-subtracted TIFF\n"
		{			
			std::cout << "Creating the super-resolution image...\n";
			
			if(!usingBatchMode)
			{
				std::cout << "\nPlease enter a tiff file path (use Unix style, i.e., forward slashes): ";
				std::cin >> thePhILMPreferences.tiffFileName;
				thePhILMPreferences.chooseOutputDirectoryUsingTIFFName();
				checkForExitCommand(thePhILMPreferences.tiffFileName.c_str());
				
				std::cout << "Please enter minimum allowed spot separation: ";
				std::cin >> thePhILMPreferences.minimumSpotSeparation;
			}
			
			TNT::Stopwatch Q;
			Q.start();
			
			int numGoodFits = createSpotFitsFileFromBackwardsSubtracted(thePhILMPreferences.tiffFileName.c_str(), 
																		thePhILMPreferences.darkCountsNoise, 
																		thePhILMPreferences.minimumSpotSeparation);
			
			std::cout << "The estimated portion of fluorophores localized is " << estimatePortionOfFluorophoresLocalized(numGoodFits, thePhILMPreferences.tiffFileName.c_str()) << ".\n";
			
			std::cout << "Total time to process " << thePhILMPreferences.tiffFileName << " was " << Q.read()/60.0 << " minutes after starting algorithm.\n\a";
		}
			break;
			
			
		case 'e'://calculate spot frame ranges.
		{
			if (!usingBatchMode) {
				std::cout << "Please enter minimum allowed spot separation: ";
				std::cin >> thePhILMPreferences.minimumSpotSeparation;
                
                std::cout << "Please enter tiff file name: ";
                std::cin >> thePhILMPreferences.tiffFileName;
			}
			
			fastCalculateSpotFrameRanges(thePhILMPreferences.tiffFileName.c_str(), thePhILMPreferences.minimumSpotSeparation);
			
			std::cout << "Finished calculating frame ranges for spots.\n";
			fastCalculateAntiSpotFrameRanges(thePhILMPreferences.tiffFileName.c_str(), thePhILMPreferences.minimumSpotSeparation);
			
			std::cout << "Finished calculating frame ranges for anti-spots.\n";
			
			std::cout << "\a";
		}
			break;
			
			
		case 'f'://Calculate the spots positions and uncertainties.
		{
			if (!usingBatchMode) {
				std::cout << "\nPlease enter the original tiff file path (use Unix style, i.e., forward slashes): ";
				std::cin >> thePhILMPreferences.tiffFileName;
				thePhILMPreferences.chooseOutputDirectoryUsingTIFFName();
				
				checkForExitCommand(thePhILMPreferences.tiffFileName.c_str());
				
				std::cout << "Please enter minimumNumberOfFramesToAverage: ";
				std::cin >> thePhILMPreferences.minimumNumberOfFramesToAverage;
			}
			createSpotFitsFile(thePhILMPreferences.tiffFileName.c_str(), 
							   thePhILMPreferences.minimumNumberOfFramesToAverage,
							   thePhILMPreferences.darkCountsNoise);
		}
			break;
			
			
		case 'g'://draw the localized spots
		{
			if(!usingBatchMode)
			{
				std::cout << "\nPlease enter the original tiff file path (use Unix style, i.e., forward slashes): ";
				std::cin >> thePhILMPreferences.tiffFileName;
				thePhILMPreferences.chooseOutputDirectoryUsingTIFFName();
				
				checkForExitCommand(thePhILMPreferences.tiffFileName.c_str());
				
				std::cout << "Please enter zoomFactor: ";
				std::cin >> thePhILMPreferences.zoomFactor;
				
				std::cout << "Please enter drawingIntensityScalingFactor: ";
				std::cin >> thePhILMPreferences.drawingIntensityScalingFactor;
			}
			
			double fixedPeakHeight = 0;
			//std::cout << "Please enter fixedPeakHeight (enter 0 to fixed height according to Gaussian fit peak heights): ";
			//std::cin >> fixedPeakHeight;
			
			quicklyDrawSpotsInSuperResolutionImage(thePhILMPreferences.tiffFileName.c_str(), 
												   thePhILMPreferences.formOutputFilePath("superResolutionImage.tif").c_str(), 
												   thePhILMPreferences.zoomFactor, 
												   thePhILMPreferences.drawingIntensityScalingFactor, 
												   fixedPeakHeight);
			std::cout << "\a";
		}
			break;
			
			
            //"h.	Step 6b: Create the super-resolution image using max z project\n"
		case 'h':
		{
			if(!usingBatchMode){
				std::cout << "\nPlease enter the original tiff file path (use Unix style, i.e., forward slashes): ";
				std::cin >> thePhILMPreferences.tiffFileName;
				thePhILMPreferences.chooseOutputDirectoryUsingTIFFName();
				
				checkForExitCommand(thePhILMPreferences.tiffFileName.c_str());
				
				std::cout << "Please enter zoomFactor: ";
				std::cin >> thePhILMPreferences.zoomFactor;
				
				std::cout << "Please enter drawingIntensityScalingFactor: ";
				std::cin >> thePhILMPreferences.drawingIntensityScalingFactor;
				
			}
			
			int drawingStyle = 1;
			quicklyDrawSpotsInSuperResolutionImage(thePhILMPreferences.tiffFileName.c_str(), 
												   thePhILMPreferences.formOutputFilePath("superResolutionImage.maxZProject.tif").c_str(), 
												   thePhILMPreferences.zoomFactor, 
												   thePhILMPreferences.drawingIntensityScalingFactor, 
												   drawingStyle);
			std::cout << "\a";
		}
			break;
			
			
			//"i.	Step 6c: Create the super-resolution image using pixels representation\n"
		case 'i':
		{
			if(!usingBatchMode)
			{
				std::cout << "\nPlease enter the original tiff file path (use Unix style, i.e., forward slashes): ";
				std::cin >> thePhILMPreferences.tiffFileName;
				thePhILMPreferences.chooseOutputDirectoryUsingTIFFName();
				
				checkForExitCommand(thePhILMPreferences.tiffFileName.c_str());
				
				std::cout << "Please enter zoomFactor: ";
				std::cin >> thePhILMPreferences.zoomFactor;
				
				std::cout << "Please enter drawingIntensityScalingFactor: ";
				std::cin >> thePhILMPreferences.drawingIntensityScalingFactor;
			}
			
			int drawingStyle = 2;
			
			quicklyDrawSpotsInSuperResolutionImage(thePhILMPreferences.tiffFileName.c_str(), thePhILMPreferences.formOutputFilePath("superResolutionImage.pixels.tif").c_str(), thePhILMPreferences.zoomFactor, thePhILMPreferences.drawingIntensityScalingFactor, drawingStyle);
			std::cout << "\a";
		}
			break;
			
			
			
		case 'm':
		{
			if(!usingBatchMode){
				std::cout << "\nPlease enter the original tiff file path (use Unix style, i.e., forward slashes): ";
				std::cin >> thePhILMPreferences.tiffFileName;
				thePhILMPreferences.chooseOutputDirectoryUsingTIFFName();
				
				checkForExitCommand(thePhILMPreferences.tiffFileName.c_str());
				
				std::cout << "Please enter zoomFactor: ";
				std::cin >> thePhILMPreferences.zoomFactor;
				
				std::cout << "Please enter drawingIntensityScalingFactor: ";
				std::cin >> thePhILMPreferences.drawingIntensityScalingFactor;
				
			}
			
			drawSuperResolutionImageUsingNormalizedSpots(thePhILMPreferences.tiffFileName.c_str(), 
														 thePhILMPreferences.formOutputFilePath("superResolutionImage.normalizedSpots.tif").c_str(), 
														 thePhILMPreferences.zoomFactor, 
														 thePhILMPreferences.drawingIntensityScalingFactor);
			
            
            //I am getting lazy here...
            //0
            std::cout << "\nLoading TIFF file...\n";
            std::vector< TNT::Array2D< int > > imageVector;
            SimonsonLibTIFF_IO::readTIFFStack(thePhILMPreferences.tiffFileName, imageVector);
            std::cout << "Number of frames in image vector = " << imageVector.size() << ".\n";
            
            class SuperResolutionPlotting::RoundNormalizedSpotsPlot normalizedSRPlot;
            normalizedSRPlot.outputTIFFFileName = thePhILMPreferences.formOutputFilePath("superResolutionImage.roundNormalized.tif");
            normalizedSRPlot.zoomFactor = thePhILMPreferences.zoomFactor;
            normalizedSRPlot.originalDim1 = imageVector.at(0).dim1();
            normalizedSRPlot.originalDim2 = imageVector.at(0).dim2();
            normalizedSRPlot.plotSpotFits();
            
			
			std::cout << "\a";
		}
			break;
			
			
		case 'n':
		{
			if(!usingBatchMode)
			{
				std::cout << "\nPlease enter the original tiff file path (use Unix style, i.e., forward slashes): ";
				std::cin >> thePhILMPreferences.tiffFileName;
				thePhILMPreferences.chooseOutputDirectoryUsingTIFFName();
				
				checkForExitCommand(thePhILMPreferences.tiffFileName.c_str());
				
				std::cout << "Please enter zoomFactor: ";
				std::cin >> thePhILMPreferences.zoomFactor;
				
				std::cout << "Please enter drawingIntensityScalingFactor: ";
				std::cin >> thePhILMPreferences.drawingIntensityScalingFactor;
			}
			
			quicklyDrawSpotsInSuperResolutionImage(thePhILMPreferences.tiffFileName.c_str(), thePhILMPreferences.formOutputFilePath("superResolutionImage.PhILM.tif").c_str(), thePhILMPreferences.zoomFactor, thePhILMPreferences.drawingIntensityScalingFactor, PhILMDrawingStyle);
			std::cout << "\a";
		}
			break;
			
			
			/*
             //	<<	"j.	Display the super-resolution image\n"
             case 'j'://display the super-resolution image
             {
             Magick::Image superResolutionImage(thePhILMPreferences.formOutputFilePath("superResolutionImage.tif").c_str());
             superResolutionImage.normalize();
             superResolutionImage.display();
             }
             break;
             */
			
		case 'k':
		{
			if(!usingBatchMode)
			{
				std::cout << "\nPlease enter a file path (use Unix style, i.e., forward slashes): ";
				std::cin >> thePhILMPreferences.tiffFileName;
				checkForExitCommand(thePhILMPreferences.tiffFileName.c_str());
			}
			
			std::cout << "The spot fits are supposed to be found in " << (thePhILMPreferences.formOutputFilePath("spotFits.txt").c_str()) << ".\n";
			ScienceFile spotFitsFile(thePhILMPreferences.formOutputFilePath("spotFits.txt").c_str());
			int numGoodFits = spotFitsFile.numRows();
			std::cout << "The estimated portion of fluorophores localized is " << estimatePortionOfFluorophoresLocalized(numGoodFits, thePhILMPreferences.tiffFileName.c_str()) << ".\n";
		}
			break;
			
			
		case 'l':
		{			
			if(!usingBatchMode)
			{
				std::cout << "\nPlease enter a file path (use Unix style, i.e., forward slashes): ";
				std::cin >> thePhILMPreferences.tiffFileName;
				checkForExitCommand(thePhILMPreferences.tiffFileName.c_str());
			}
			
			std::cout << "Now estimating photobleaching lifetime...\n";
			class PhotobleachingLifetimeEstimate lifetimeEstimate;
			lifetimeEstimate.writeXYFitData(thePhILMPreferences.formOutputFilePath("photobleachingLifetimeFit.txt").c_str());
		}
			break;
			
			
		case 'v':
		{
            ///Perform FIONA on a spot
            std::cout	<<	"This function only works on 16 bit images.\n";

			std::string outputFileName = thePhILMPreferences.formOutputFilePath("stageDriftCorrection.txt").c_str();
			
			std::cout << "\nPlease enter TIFF file path (use Unix style, i.e., forward slashes): ";
			std::cin >> thePhILMPreferences.tiffFileName;
			thePhILMPreferences.chooseOutputDirectoryUsingTIFFName();

            std::vector< TNT::Array2D<int> > imageVector;
            SimonsonLibTIFF_IO::readTIFFStack(thePhILMPreferences.tiffFileName, imageVector);
            
            int numFrames = imageVector.size();
            
            //For writing results to text file:
            std::vector<double> frames(numFrames);
            std::vector<double> xValues(numFrames);
            std::vector<double> yValues(numFrames);
            std::vector<double> s_xValues(numFrames);
            std::vector<double> s_yValues(numFrames);
            std::vector<double> thetaValues(numFrames);
            std::vector<double> ellipticityValues(numFrames);
            
            ScienceFile secondOutputFile;		
            
            const int xColumn = 0;
            const int yColumn = 1;
            const int intensityColumn = 2;
            
            int i;
            for(i = 0; i < numFrames; i++)
            {
                std::cout << "Frame #" << i + 1 << "\n";
                
                TNT::Array2D<int> imageArray = imageVector.at(i);
                subtractAConstant(imageArray, thePhILMPreferences.cameraBaselineCounts);
                multiplyByAConstant(imageArray, thePhILMPreferences.countsToPhotonsConversionFactor);
                ScienceFile spotInformation = returnDataForGaussianFitting(imageArray);
                
                TwoDGaussianFittingParametersAndErrors theCurveFit;
                
                if (thePhILMPreferences.spotFittingMethod == 1) {
                    theCurveFit = weightedFitTo2DGaussian(spotInformation.returnColumn(xColumn),
                                                          spotInformation.returnColumn(yColumn),
                                                          spotInformation.returnColumn(intensityColumn),
                                                          thePhILMPreferences.darkCountsNoise);
                }
                /*
                else if(thePhILMPreferences.spotFittingMethod == 3)
                {
                    //std::cout << "Fitting with method 3\n";
                    class twoDGaussianFitter_WithReadoutNoiseAndEMGain fitter;
                    fitter.maxIterations = 30;
                    
                    double readoutNoisePhotonsSquared 
                    = thePhILMPreferences.countsToPhotonsConversionFactor 
                    * thePhILMPreferences.darkCountsNoise 
                    * thePhILMPreferences.countsToPhotonsConversionFactor 
                    * thePhILMPreferences.darkCountsNoise;
                    
                    fitter.xValues = spotInformation.returnColumn(xColumn);
                    fitter.yValues = spotInformation.returnColumn(yColumn);
                    fitter.observedValues = spotInformation.returnColumn(intensityColumn);
                    
                    std::vector<double> varianceEstimates(spotInformation.numRows());
                    int n;
                    for (n = 0; n < spotInformation.numRows(); n++) 
                    {
                        varianceEstimates[n] = fitter.observedValues[n] + readoutNoisePhotonsSquared;
                        if (thePhILMPreferences.emGain) {
                            varianceEstimates[n] *= 2.0;
                        }
                    }
                    
                    //fitter.varianceValues = varianceEstimates;
                    
                    std::vector<double> fitParameters = fitter.fitParameters(fitter.guessStartingParameters());
                    std::vector<double> crlb = fitter.calculateCRLB(fitParameters);
                    
                    //std::cout << fitter.calculateFIM(fitParameters);
                    //fitter.printCRLB(fitParameters);
                    std::cout << "iterations = " << fitter.numIterations << ", tolerance = " << fitter.fitTolerance << "\n";
                    
                    theCurveFit = convertMLE2DGaussianFitter_GaussianFitResultsToSpotFitClass(fitParameters, crlb);
                    theCurveFit.numFitIterations = fitter.numIterations;
                    theCurveFit.fitTolerance = fitter.fitTolerance;
                    
                    theCurveFit.printFit();
                }
                 */
                else
                {
                    std::cout << "Unused spot fitting method indicated in PhILMPreferences.txt.\n";
                    return -1;
                }

                frames.at(i) = (i + 1);
                xValues.at(i) = (theCurveFit.xCenterValue);
                yValues.at(i) = (theCurveFit.yCenterValue);
                s_xValues.at(i) = (theCurveFit.xWidth);
                s_yValues.at(i) = (theCurveFit.yWidth);
                thetaValues.at(i) = (theCurveFit.tiltAngle);
                ellipticityValues.at(i) = (theCurveFit.ellipticity());
                
                std::vector<double> fitVector = theCurveFit.returnFitAsVector();
                std::vector<double> oneFitResult;
                oneFitResult.push_back(i + 1);
                oneFitResult.insert(oneFitResult.end(), fitVector.begin(), fitVector.end());
                oneFitResult.push_back(theCurveFit.ellipticity());
                oneFitResult.push_back(theCurveFit.numFitIterations);
                oneFitResult.push_back(theCurveFit.fitTolerance);
                oneFitResult.push_back(theCurveFit.estimateTotalCountsUsingFittingParameters());
                secondOutputFile.addRow(oneFitResult);
            }
            
            ScienceFile outputFIONAFile;		
            outputFIONAFile.addColumn(frames);
            outputFIONAFile.addColumn(xValues);
            outputFIONAFile.addColumn(yValues);
            outputFIONAFile.addColumn(s_xValues);
            outputFIONAFile.addColumn(s_yValues);
            outputFIONAFile.addColumn(thetaValues);
            outputFIONAFile.addColumn(ellipticityValues);
            outputFIONAFile.addColumn(secondOutputFile.returnColumn(9));
            outputFIONAFile.addColumn(secondOutputFile.returnColumn(10));
            outputFIONAFile.writeToFile(outputFileName.c_str(), "%%frame	x0	y0	s_x	s_y	theta	ellipticity	x0Error	y0Error");
		}
			break;
			
			
            //"w.	Concatenate shrimpFits files\n"
		case 'w':
		{
			std::string file1, file2, outputFileName;
            
            
            if (argc < 5) {
                std::cout << "What is the name of the first spotFits file?:";
                std::cin >> file1;
                std::cout << "What is the name of the second spotFits file?:";
                std::cin >> file2;
                std::cout << "What will be the name of the output spotFits file?:";
                std::cin >> outputFileName;
            }
            else
            {
                file1 = argv[2];
                file2 = argv[3];
                outputFileName = argv[4];
            }
			
			std::cout << file1 << " + " << file2 << " = " << outputFileName << "\n";
			concatenateShrimpFitsFiles(file1.c_str(), file2.c_str(), outputFileName.c_str());
		}
			break;
			
			
            
			
			
			//	<<	"y.	Plot ons and offs in a single TIFF file.\n"
		case 'y'://Plot ons and offs
			std::cout << "\nPlease enter a file path (use Unix style, i.e., forward slashes): ";
			std::cin >> thePhILMPreferences.tiffFileName;
			thePhILMPreferences.chooseOutputDirectoryUsingTIFFName();
			
			checkForExitCommand(thePhILMPreferences.tiffFileName.c_str());
			plotOnsAndOffs(thePhILMPreferences.tiffFileName.c_str());
			
			break;
			
			
            
			
		case 'q':
			break;
		default:
			break;
	}
	
	return 0;
}

