/*
 *  mainFindWidthOfMicrotubulesInNormalImages.cpp
 *  ReverseSTORM_SL
 *
 *  Created by Paul Simonson on 10/28/09.
 *  Copyright 2009 Champaign Illinois Stake. All rights reserved.
 *
 */



//includes
#include <iostream>
#include <fstream>
#include <string>

#include "PhILMCoreCode.h"
#include "PhILMMicrotubuleExtras.h"
#include "detectParticlesClass.h"
#include "tiffStackOperations.h"
#include "fitTo2DGaussianUsingGSL.h"
#include "Magick++.h"
#include "return2DArrayFromMultiBitmap.h"
#include "tiffFrameOperations.h"
#include "tiffFrameOperationsUsingMagick.h"

#include "writeTIFFFileUsingMagick.h"
//#include "stageDrift.h"

//#include "MicrotubuleFit.h"


using namespace PhILM_namespace;



//Global variables
FIMULTIBITMAP *multibitmap;
const void *nil = 0L;



int rotateImage(const char *inputFileName, const char *outputFileName, double rotationAngle, double yIntercept, double pixelThresholdValue = -1)
{
	ScienceFile rotatedImageFile;
	std::vector<double> oneRotatedPixel(3);
	
	TNT::Array2D<int> frame0Array = return2DIntArrayUsingMagick(inputFileName, 1);
	int width = frame0Array.dim1();
	int height = frame0Array.dim2();
	int i, j;
	
	if(pixelThresholdValue == 0)//then set the threshold to the minimum pixel intensity.
	{
		const int maxPossibleIntensity = pow(2, 16) - 1;
		
		pixelThresholdValue = maxPossibleIntensity;
		for(i = 0; i < width; i++)
			for(j = 0; j < height; j++)
			{
				if(frame0Array[i][j] < pixelThresholdValue)
					pixelThresholdValue = frame0Array[i][j];
			}
		std::cout << "pixelThresholdValue was set to " << pixelThresholdValue << "\n";
	}
	
	for(i = 0; i < width; i++)
		for(j = 0; j < height; j++)
		{
			double pixelIntensity = frame0Array[i][j];
			if(pixelThresholdValue >= 0)
				pixelIntensity -= pixelThresholdValue;
			double x = i;
			double y = j - yIntercept;
			std::vector<double> newCoordinates = rotateCoordinates(x, y, rotationAngle);
			newCoordinates.push_back(pixelIntensity);
			rotatedImageFile.addRow(newCoordinates);
		}
	
	rotatedImageFile.writeToFile(outputFileName);
	return 0;
}


ScienceFile returnVectorsForFittingALine(const char *inputFileName, double pixelThresholdValue)
{
	ScienceFile imageVectorStuff;
	std::vector<double> oneResult(2);
	
	TNT::Array2D<int> frame0Array = return2DIntArrayUsingMagick(inputFileName, 1);
	int width = frame0Array.dim1();
	int height = frame0Array.dim2();
	int i, j;
	
	if(pixelThresholdValue == 0)//then set the threshold to the minimum pixel intensity.
	{
		const int maxPossibleIntensity = pow(2, 16) - 1;
		
		pixelThresholdValue = maxPossibleIntensity;
		for(i = 0; i < width; i++)
			for(j = 0; j < height; j++)
			{
				if(frame0Array[i][j] < pixelThresholdValue)
					pixelThresholdValue = frame0Array[i][j];
			}
	}
	
	for(i = 0; i < width; i++)
		for(j = 0; j < height; j++)
		{
			int pixelIntensity = frame0Array[i][j] - pixelThresholdValue;
			if (pixelIntensity > 0) {
				int k;
				for(k = 0; k < pixelIntensity; k++)
				{
					oneResult.at(0) = i;
					oneResult.at(1) = j;
					imageVectorStuff.addRow(oneResult);
				}
			}
		}
	
	return imageVectorStuff;
}



void displayHelpMessage(void)
{
	std::cout	<< "Usage:\n"
    << "Old work horse: FindWidthOfMicrotubulesInNormalImages -A\n"
    << "Main work horse: FindWidthOfMicrotubulesInNormalImages -B folderName distanceFromLineCutOff pixelThresholdValue fileNamePrefixOfPhILMData\n"
    << "FindWidthOfMicrotubulesInNormalImages -e\n"
    << "Remove intermediate files: FindWidthOfMicrotubulesInNormalImages -f\n"
    << "Make pretty histogram data file: FindWidthOfMicrotubulesInNormalImages -p pixelWidth\n"
    << "Help: FindWidthOfMicrotubulesInNormalImages -h\n"
	;
    
}


///Keep track of which folders/segments you have added for calculating microtubule width.
void updateListOfFoldersConcatenated(std::string folderName, double pixelThresholdValue, double distanceFromLineCutOff)
{
	std::ofstream outputFile; // indata is like cin
	if(checkWhetherFileIsPresent("foldersConcatenated.txt"))
		outputFile.open("foldersConcatenated.txt", std::ios::app);
	else
		outputFile.open("foldersConcatenated.txt");
	outputFile << folderName << ", Pixel threshold = " << pixelThresholdValue << ", distanceFromLineCutOff = " << distanceFromLineCutOff << "\n";
	outputFile.close();
}

double determineScalingFactorFromNormalAndSuperResolutionImages(std::string normalImageName, std::string superResolutionImageName)
{
	Magick::Image originalTIFF(normalImageName);
	Magick::Image superResolutionImage(superResolutionImageName);
	double scalingFactor = superResolutionImage.rows()/originalTIFF.rows();
	return scalingFactor;
}

void appendResultToConcatenatedRotatedShrimpFitsFile(std::string rotatedShrimpFitsFileName)
{
	std::ofstream outputFile; // indata is like cin
	if(checkWhetherFileIsPresent("concatenatedRotatedspotFits.txt"))
		outputFile.open("concatenatedRotatedspotFits.txt", std::ios::app);
	else
		outputFile.open("concatenatedRotatedspotFits.txt");				
	std::ifstream indata(rotatedShrimpFitsFileName.c_str()); // indata is like cin
	std::string line;
	while ( !indata.eof())
	{
		getline(indata, line);
		outputFile << line << "\n";
	}
	outputFile.close();
}


void makeCountsDistributionFile(std::string tiffFileName, std::string rotatedImageFileName, std::string countsPositionsFileName, double rotationAngle, double yInterceptInNormalResolutionImage, double pixelThresholdValue)
{//	<<	"c.	Fit super resolution localizations to a line, rotate image coordinates, and make a counts distribution file\n"
	rotateImage(tiffFileName.c_str(), rotatedImageFileName.c_str(), -rotationAngle, yInterceptInNormalResolutionImage);
	
	ScienceFile rotatedImageFile(rotatedImageFileName.c_str());
	std::ofstream outputFile(countsPositionsFileName.c_str());
	
	int i;
	int numPixels = rotatedImageFile.numRows();
	for(i = 0; i < numPixels; i++)
	{
		int j;
		int numCountsInPixel = rotatedImageFile.at(i, 2) - pixelThresholdValue;
		numCountsInPixel *= 0.01;
		if(numCountsInPixel > 0)
			for(j = 0; j < numCountsInPixel; j++)
				outputFile << rotatedImageFile.at(i, 0) << "	" << rotatedImageFile.at(i, 1) << "\n";
	}
	outputFile.close();
}

void concatenateCountsDistributionFile(std::string countsPositionsFileName)
{//	<<	"d.	Concatenate countsPositions file\n"
	std::ofstream outputFile; // indata is like cin
	if(checkWhetherFileIsPresent("concatenatedCountsPositions.txt"))
	{
		outputFile.open("concatenatedCountsPositions.txt", std::ios::app);
	}
	else {
		outputFile.open("concatenatedCountsPositions.txt");
	}
	std::ifstream indata(countsPositionsFileName.c_str()); // indata is like cin
	std::string line;
	while ( !indata.eof())
	{
		getline(indata, line);
		outputFile << line << "\n";
	}
	outputFile.close();
}


int main(int argc, char *argv[])
{
	std::cout << "\nNote that this program only works with 16 bit TIFF files.\n\n";
	
	char mainSelection;
	std::string folderName;
	double distanceFromLineCutOff;
	double pixelThresholdValue;
	std::string fileNamePrefixOfPhILMData;
	
	bool usingBatchMode = 0;
	if (argc > 1) 
	{
		usingBatchMode = 1;
		
		if(argv[1][0] == '-')
		{
			mainSelection = argv[1][1];
		}
		else {
			std::cout << "I could not understand the command line input.  Not using batch mode...\n";
			usingBatchMode = 0;
		}
	}
	
	if (usingBatchMode) {
		switch (mainSelection)
		{		
			case 'h':
				displayHelpMessage();
				break;
				
			case 'A'://latest and greatest
			{	
				if(argc < 6)
				{
					std::cout << "Too few arguments...\n";
					return -1;
				}
				
				folderName = argv[2];
				distanceFromLineCutOff = strtod(argv[3], NULL);
				pixelThresholdValue = strtod(argv[4], NULL);
				fileNamePrefixOfPhILMData = argv[5];
				
				
				std::cout << "Automate the analysis by rotating and concatentating data stored in folders (steps a-d)...\n";
				
				std::cout << "fileNamePrefixOfPhILMData = " << fileNamePrefixOfPhILMData << "\n";
				
				std::string tiffFileName = folderName + "/" + folderName + ".tif";
				std::string shrimpFitsFileName = folderName + "/" + fileNamePrefixOfPhILMData + "spotFits.txt";
				std::string rotatedShrimpFitsFileName = folderName + "/" + fileNamePrefixOfPhILMData +"rotatedspotFits.txt";
				std::string rotatedImageFileName = folderName + "/" + fileNamePrefixOfPhILMData +"rotatedImage.txt";
				std::string countsPositionsFileName = folderName + "/"+ fileNamePrefixOfPhILMData +"countsPositions.txt";
				
				std::string driftCorrectedSpotFitsFileName = folderName + "/" + fileNamePrefixOfPhILMData + "driftCorrectedSpotFits.txt";
				std::string stageDriftCorrectionFileName = folderName + "/stageDriftCorrection.txt";
                
				int usingStageDriftCorrection = checkWhetherFileIsPresent(stageDriftCorrectionFileName.c_str());
				if(usingStageDriftCorrection){
					std::cout << stageDriftCorrectionFileName << " stage drift correction file was found.\n";
					createDriftCorrectedSpotFitsFile(stageDriftCorrectionFileName.c_str(), shrimpFitsFileName.c_str(), driftCorrectedSpotFitsFileName.c_str());
				}
				else {
					std::cout << stageDriftCorrectionFileName << " stage drift correction file was not found.\n";
				}
                
				
				{//keep track of which folders you have added.
					std::ofstream outputFile; // indata is like cin
					if(checkWhetherFileIsPresent("foldersConcatenated.txt"))
						outputFile.open("foldersConcatenated.txt", std::ios::app);
					else
						outputFile.open("foldersConcatenated.txt");
					outputFile << folderName << ", Pixel threshold = " << pixelThresholdValue << ", distanceFromLineCutOff = " << distanceFromLineCutOff << "\n";
					outputFile.close();
				}
				
				ScienceFile shrimpFitsFile;
				
				if(usingStageDriftCorrection)
				{
					shrimpFitsFile.loadFromFile(driftCorrectedSpotFitsFileName.c_str());
				}
				else {
					shrimpFitsFile.loadFromFile(shrimpFitsFileName.c_str());
				}
                
				std::vector<double> x0s = shrimpFitsFile.returnColumn(1);
				std::vector<double> y0s = shrimpFitsFile.returnColumn(2);
				
				
				
				std::vector<double> lineFit = fitDataToStraightLine(x0s, y0s);
				double rotationAngle = atan(lineFit.at(0));
				std::cout << "Angle of the fit line is " << rotationAngle << " radians = " << rotationAngle * 180.0/3.14159 << " degrees.\n";
				std::cout << "y intercept of the line is " << lineFit.at(1) << ".\n";
				
				//Now draw the line in the super resolution image.
				class MicrotubuleLineFit microtubuleLineFitImage1;
				microtubuleLineFitImage1.lineFit = lineFit;
				microtubuleLineFitImage1.tiffFileName =  folderName + "/" +folderName + ".tif";
				microtubuleLineFitImage1.outputDirectory = folderName + "/";
				microtubuleLineFitImage1.outputFilePrefix = fileNamePrefixOfPhILMData;
				//microtubuleLineFitImage1.drawLineFitInSuperResolutionImage();
				
				//	<<	"a.	Fit spots to a line and rotate coordinates\n"
				//Now get rid of the wild spots and refit the line.
				
				if (usingStageDriftCorrection) {
					rotateShrimpFitsFile(driftCorrectedSpotFitsFileName.c_str(), rotatedShrimpFitsFileName.c_str(), -rotationAngle, lineFit.at(1));
				}
				else
				{
					rotateShrimpFitsFile(shrimpFitsFileName.c_str(), rotatedShrimpFitsFileName.c_str(), -rotationAngle, lineFit.at(1));
				}
                
				
				class MicrotubuleFit MTFit;
				MTFit.tiffFileName =  folderName + "/" + fileNamePrefixOfPhILMData + "superResolutionImage.tif";
				MTFit.outputDirectory = folderName + "/";
				MTFit.outputFilePrefix = fileNamePrefixOfPhILMData;	
				MTFit.fit();
				MTFit.printFit();
				MTFit.lineColor = "blue";
				MTFit.drawLineFitInImage("MTfit.jpg");
				
				
				{//	<<	"b.	Concatenate rotatedShrimpFitsFile\n"
					std::ofstream outputFile; // indata is like cin
					if(checkWhetherFileIsPresent("concatenatedRotatedspotFits.txt"))
						outputFile.open("concatenatedRotatedspotFits.txt", std::ios::app);
					else
						outputFile.open("concatenatedRotatedspotFits.txt");				
					std::ifstream indata(rotatedShrimpFitsFileName.c_str()); // indata is like cin
					std::string line;
					while ( !indata.eof())
					{
						getline(indata, line);
						outputFile << line << "\n";
					}
					outputFile.close();
				}
				{//	<<	"c.	Fit super resolution localizations to a line, rotate image coordinates, and make a counts distribution file\n"
					rotateImage(tiffFileName.c_str(), rotatedImageFileName.c_str(), -rotationAngle, lineFit.at(1));
					
					ScienceFile rotatedImageFile(rotatedImageFileName.c_str());
					std::ofstream outputFile(countsPositionsFileName.c_str());
					
					int i;
					int numPixels = rotatedImageFile.numRows();
					for(i = 0; i < numPixels; i++)
					{
						int j;
						int numCountsInPixel = rotatedImageFile.at(i, 2) - pixelThresholdValue;
						numCountsInPixel *= 0.01;
						if(numCountsInPixel > 0)
							for(j = 0; j < numCountsInPixel; j++)
								outputFile << rotatedImageFile.at(i, 0) << "	" << rotatedImageFile.at(i, 1) << "\n";
					}
					outputFile.close();
				}
				{//	<<	"d.	Concatenate countsPositions file\n"
					std::ofstream outputFile; // indata is like cin
					if(checkWhetherFileIsPresent("concatenatedCountsPositions.txt"))
					{
						outputFile.open("concatenatedCountsPositions.txt", std::ios::app);
					}
					else {
						outputFile.open("concatenatedCountsPositions.txt");
					}
					std::ifstream indata(countsPositionsFileName.c_str()); // indata is like cin
					std::string line;
					while ( !indata.eof())
					{
						getline(indata, line);
						outputFile << line << "\n";
					}
					outputFile.close();
				}
			}
				break;
                
			case 'B'://latest and greatest
			{	
				std::cout << "B.  Automate the analysis by rotating and concatentating data stored in folders (steps a-d)...\n";
				std::cout << "This option is the same as 'A', but the microtubule segment fitting is done using Melikhan's approach (see his poster in the hallway) in the super resolution image.\n";
				
				if(argc < 6)
				{
					std::cout << "Too few arguments...\n";
					return -1;
				}
				
				folderName = argv[2];
				distanceFromLineCutOff = strtod(argv[3], NULL);
				pixelThresholdValue = strtod(argv[4], NULL);
				fileNamePrefixOfPhILMData = argv[5];
				
				std::string tiffFileName = folderName + "/" + folderName + ".tif";
				std::string shrimpFitsFileName = folderName + "/" + fileNamePrefixOfPhILMData + "spotFits.txt";
				std::string rotatedShrimpFitsFileName = folderName + "/" + fileNamePrefixOfPhILMData +"rotatedspotFits.txt";
				std::string rotatedImageFileName = folderName + "/" + fileNamePrefixOfPhILMData +"rotatedImage.txt";
				std::string countsPositionsFileName = folderName + "/"+ fileNamePrefixOfPhILMData +"countsPositions.txt";
				std::string driftCorrectedSpotFitsFileName = folderName + "/" + fileNamePrefixOfPhILMData + "driftCorrectedSpotFits.txt";
				std::string stageDriftCorrectionFileName = folderName + "/stageDriftCorrection.txt";
				
                
				//keep track of which folders you have added.
				updateListOfFoldersConcatenated(folderName, pixelThresholdValue, distanceFromLineCutOff);
                
                
				//Fit the microtubule.
				class MicrotubuleFit MTFit;
				MTFit.tiffFileName =  folderName + "/" + fileNamePrefixOfPhILMData + "superResolutionImage.tif";
				MTFit.outputDirectory = folderName + "/";
				MTFit.outputFilePrefix = fileNamePrefixOfPhILMData;	
				MTFit.lineColor = "blue";
				
				
				MTFit.calculatePreliminaryFitUsingSpotFitsFile();
				MTFit.printFit();
				MTFit.fit();
				MTFit.printFit();
				MTFit.drawLineFitInImage(folderName + ".MTfit.jpg");
				//MTFit.displayOutputImage();
				
				std::vector<double> lineFit = MTFit.returnLineFit();
				//std::cout << "The number of elements in lineFit is " << lineFit.size() << "\n";
				double rotationAngle = MTFit.rotationAngle();
				double scalingFactor = determineScalingFactorFromNormalAndSuperResolutionImages(tiffFileName, folderName + "/" + fileNamePrefixOfPhILMData + "superResolutionImage.tif");
				double yInterceptInNormalResolutionImage = lineFit.at(1)/scalingFactor;
				
				int usingStageDriftCorrection = checkWhetherFileIsPresent(stageDriftCorrectionFileName.c_str());
				if(usingStageDriftCorrection){
					std::cout << stageDriftCorrectionFileName << " stage drift correction file was found.\n";
					createDriftCorrectedSpotFitsFile(stageDriftCorrectionFileName.c_str(), shrimpFitsFileName.c_str(), driftCorrectedSpotFitsFileName.c_str());
					rotateShrimpFitsFile(driftCorrectedSpotFitsFileName.c_str(), rotatedShrimpFitsFileName.c_str(), -rotationAngle, yInterceptInNormalResolutionImage);
                    
				}
				else {
					std::cout << stageDriftCorrectionFileName << " stage drift correction file was not found.\n";
					rotateShrimpFitsFile(shrimpFitsFileName.c_str(), rotatedShrimpFitsFileName.c_str(), -rotationAngle, yInterceptInNormalResolutionImage);
				}
				std::cout << "Finished step a.\n";
                
				//"b.	Concatenate rotatedShrimpFitsFile\n"
				appendResultToConcatenatedRotatedShrimpFitsFile(rotatedShrimpFitsFileName);
				std::cout << "Finished step b.\n";
				
				//"c.	Fit super resolution localizations to a line, rotate image coordinates, and make a counts distribution file\n"
                
				makeCountsDistributionFile(tiffFileName, rotatedImageFileName, countsPositionsFileName, rotationAngle, yInterceptInNormalResolutionImage, pixelThresholdValue);
				std::cout << "Finished step c.\n";
                
				//"d.	Concatenate countsPositions file\n"
				concatenateCountsDistributionFile(countsPositionsFileName);
				std::cout << "Finished step d.\n";
                
				
			}
				break;
				
			case 'e'://put histogram data in columns files
			{//	<<	"e.	Put histogram data in columns file\n"
				ScienceFile countsPositionsCountsFile("countsPositionsCounts.txt");
				std::cout << "countsPositionsCounts.txt" << "\n";
				ScienceFile countsPositionsBinsFile("countsPositionsBins.txt");
				std::cout << "countsPositionsBins.txt" << "\n";
                
				ScienceFile newFile;
				newFile.addColumn(countsPositionsBinsFile.returnRow(0));
				newFile.addColumn(countsPositionsCountsFile.returnRow(0));
				newFile.writeToFile("nrHistogramData.txt");
				std::cout << "nrHistogramData.txt" << "\n";
                
				
				
				ScienceFile srHistogramCountsFile("errorCounts.txt");
				std::cout << "errorCounts.txt" << "\n";
				//srHistogramCountsFile.display();
                
				ScienceFile srHistogramBinsFile("errorValueBins.txt");
				std::cout << "errorValueBins.txt" << "\n";
				//srHistogramBinsFile.display();
                
				ScienceFile newFile2;
				newFile2.addColumn(srHistogramBinsFile.returnRow(0));
				newFile2.addColumn(srHistogramCountsFile.returnRow(0));
				newFile2.writeToFile("srHistogramData.txt");
				std::cout << "srHistogramData.txt" << "\n";
                
				std::cout << "Finished putting histogram data in columns files.\n";
			}
				break;
				
			case 'f':
			{
				remove("concatenatedCountsPositions.txt");
				remove("concatenatedRotatedspotFits.txt");	
				remove("countsPositionsCounts.txt");
				remove("countsPositionsBins.txt");
				remove("nrHistogramData.txt");
				remove("errorCounts.txt");
				remove("errorValueBins.txt");
				remove("srHistogramData.txt");
				remove("foldersConcatenated.txt");
				
			}
				break;
				
			case 'p'://make "pretty" histogram file.  The x column will now be scaled, and the y column will be normalized.
			{
				std::cout << "Making a \"pretty\" output file...\n";
				double pixelSize = strtod(argv[2], NULL);
				ScienceFile nrFile("nrHistogramData.txt");
				ScienceFile srFile("srHistogramData.txt");
				
				double normalizingFactor = ScienceFile::findMax(nrFile.returnColumn(1));
				
				
				int i;
				for(i = 0; i < nrFile.numRows(); i++)
				{
					std::cout << i << "\n";
                    
					nrFile.setElement(i, 0, nrFile.at(i,0)*pixelSize);
					nrFile.setElement(i, 1, nrFile.at(i,1)/normalizingFactor);
				}
				nrFile.writeToFile("prettyNRHistogramData.txt");
                
                
				normalizingFactor = ScienceFile::findMax(srFile.returnColumn(1));
				for(i = 0; i < srFile.numRows(); i++)
				{
					std::cout << i << "\n";
                    
					srFile.setElement(i, 0, srFile.at(i,0)*pixelSize);
					srFile.setElement(i, 1, srFile.at(i,1)/normalizingFactor);
				}
				srFile.writeToFile("prettySRHistogramData.txt");
				std::cout << "Done.\n";
			}
				break;
				
			case 'q':
				break;
			default:
				break;
		}
	}
	
	if(!usingBatchMode)
	{
		std::cout	<< "Main Menu Selections:\n" 
		<<	"THESE ARE ALL OUTDATED.  USE BATCH MODE INSTEAD.\n"
		<<	"A.	(steps 1-4) using folder names containing data files for each TIFF\n"
		<<	"a.	(step 1) Fit spots to a line and rotate coordinates\n"
		<<	"b.	(step 2) Concatenate rotatedShrimpFitsFile\n"
		<<	"c.	(step 3) Fit super resolution localizations to a line, rotate image coordinates, and make a counts distribution file\n"
		<<	"d.	(step 4) Concatenate countsPositions file\n"
		<<	"-- (step 5) Now run the matlab code to form the histograms--\n"
		<<	"e.	(step 6) Put histogram data in columns file for gnuplot\n"
		<<	"--Optional--\n"
		<<	"f.	Remove concatenated data files\n"
		<<	"h.	Fit image to a line and display results\n"
		<<	"z.	Test latest and greatest.\n"
		<<	"q.	Quit\n"
		<<	"Please enter selection: ";
		
		mainSelection = std::cin.get();
		std::cin.ignore();//Use this to get rid of the enter character.
		
		
		switch (mainSelection)
		{		
				
			case 'a':
			{//	<<	"a.	Fit spots to a line and rotate coordinates\n"
				
				std::string folderName;
				std::cout << "Enter folder name: ";
				std::cin >> folderName;
				
				double distanceFromLineCutOff;
				std::cout << "Enter distanceFromLineCutOff: ";
				std::cin >> distanceFromLineCutOff;
				
				std::string shrimpFitsFileName = folderName + "/spotFits.txt";
				std::string rotatedShrimpFitsFileName = folderName + "/rotatedspotFits.txt";
				
				ScienceFile shrimpFitsFile(shrimpFitsFileName.c_str());
				std::vector<double> x0s = shrimpFitsFile.returnColumn(1);
				std::vector<double> y0s = shrimpFitsFile.returnColumn(2);
				std::vector<double> lineFit = fitDataToStraightLine(x0s, y0s);
				double rotationAngle = atan(lineFit.at(0));
				std::cout << "Angle of the fit line is " << rotationAngle << " radians = " << rotationAngle * 180.0/3.14159 << " degrees.\n";
				std::cout << "y intercept of the line is " << lineFit.at(1) << ".\n";
				
				rotateShrimpFitsFile(shrimpFitsFileName.c_str(), rotatedShrimpFitsFileName.c_str(), -rotationAngle, lineFit.at(1));
				
				//Now get rid of the wild spots and refit the line.
				x0s.clear();
				y0s.clear();
				lineFit.clear();
				ScienceFile firstRotatedShrimpFitsFile(rotatedShrimpFitsFileName.c_str());
				int numSpots = firstRotatedShrimpFitsFile.numRows();
				std::vector<int> goodOrBadSpot(0, numSpots);
				int i;
				for(i = 0; i < numSpots; i++)
				{
					if(firstRotatedShrimpFitsFile.at(i, 2) < distanceFromLineCutOff)
					{
						goodOrBadSpot.at(i) = 1;
						x0s.push_back(shrimpFitsFile.at(i, 1));
						y0s.push_back(shrimpFitsFile.at(i, 2));
					}
					else {
						goodOrBadSpot.at(i) = 0;
					}
				}
				lineFit = fitDataToStraightLine(x0s, y0s);
				rotationAngle = atan(lineFit.at(0));
				std::cout << "After throwing away distant spots:";
				std::cout << "Angle of the fit line is " << rotationAngle << " radians = " << rotationAngle * 180.0/3.14159 << " degrees.\n";
				std::cout << "y intercept of the line is " << lineFit.at(1) << ".\n";
				rotateShrimpFitsFile(shrimpFitsFileName.c_str(), rotatedShrimpFitsFileName.c_str(), -rotationAngle, lineFit.at(1));
			}
				break;
				
			case 'b':
			{//	<<	"b.	Concatenate rotatedShrimpFitsFile\n"
				std::ofstream outputFile; // indata is like cin
				
				if(checkWhetherFileIsPresent("concatenatedRotatedspotFits.txt"))
				{
					outputFile.open("concatenatedRotatedspotFits.txt", std::ios::app);
				}
				else {
					outputFile.open("concatenatedRotatedspotFits.txt");
				}
				
				std::ifstream indata("rotatedspotFits.txt"); // indata is like cin
				std::string line;
				while ( !indata.eof())
				{
					getline(indata, line);
					outputFile << line << "\n";
				}
				outputFile.close();
			}
				break;
				
				
			case 'h':
			{
				char inputFileName[1000];
				std::cout << "\nPlease enter the original tiff file path (use Unix style, i.e., forward slashes): ";
				std::cin.getline(inputFileName, 1000, '\n');
				checkForExitCommand(inputFileName);
				
				double pixelThresholdValue;
				std::cout << "Please enter pixelThresholdValue:";
				std::cin >> pixelThresholdValue;
				
				ScienceFile imageVectorStuff;
				imageVectorStuff = returnVectorsForFittingALine(inputFileName, pixelThresholdValue);
				
				std::vector<double> x0s = imageVectorStuff.returnColumn(0);
				std::vector<double> y0s = imageVectorStuff.returnColumn(1);
				std::vector<double> lineFit = fitDataToStraightLine(x0s, y0s);
				double rotationAngle = atan(lineFit.at(0));
				std::cout << "Angle of the fit line is " << rotationAngle << " radians = " << rotationAngle * 180.0/3.14159 << " degrees.\n";
				std::cout << "y intercept of the line is " << lineFit.at(1) << ".\n";
			}
				break;
				
			case 'c':
			{//	<<	"c.	Fit super resolution localizations to a line, rotate image coordinates, and make a counts distribution file\n"
				char inputFileName[1000];
				std::cout << "\nPlease enter the original tiff file path (use Unix style, i.e., forward slashes): ";
				std::cin.getline(inputFileName, 1000, '\n');
				checkForExitCommand(inputFileName);
				
				double distanceFromLineCutOff;
				std::cout << "Enter distanceFromLineCutOff: ";
				std::cin >> distanceFromLineCutOff;
				
				double pixelThresholdValue;
				std::cout << "Please enter pixelThresholdValue:";
				std::cin >> pixelThresholdValue;
				ScienceFile shrimpFitsFile("spotFits.txt");
				std::vector<double> x0s = shrimpFitsFile.returnColumn(1);
				std::vector<double> y0s = shrimpFitsFile.returnColumn(2);
				std::vector<double> lineFit = fitDataToStraightLine(x0s, y0s);
				double rotationAngle = atan(lineFit.at(0));
				std::cout << "Angle of the fit line is " << rotationAngle << " radians = " << rotationAngle * 180.0/3.14159 << " degrees.\n";
				std::cout << "y intercept of the line is " << lineFit.at(1) << ".\n";
				
				std::string shrimpFitsFileName = "spotFits.txt";
				std::string rotatedShrimpFitsFileName = "rotatedspotFits.txt";
				
				//Now get rid of the wild spots and refit the line.
				rotateShrimpFitsFile(shrimpFitsFileName.c_str(), rotatedShrimpFitsFileName.c_str(), -rotationAngle, lineFit.at(1));
				x0s.clear();
				y0s.clear();
				lineFit.clear();
				ScienceFile firstRotatedShrimpFitsFile(rotatedShrimpFitsFileName.c_str());
				int numSpots = firstRotatedShrimpFitsFile.numRows();
				std::vector<int> goodOrBadSpot(0, numSpots);
				int i;
				for(i = 0; i < numSpots; i++)
				{
					if(firstRotatedShrimpFitsFile.at(i, 2) < distanceFromLineCutOff)
					{
						goodOrBadSpot.at(i) = 1;
						x0s.push_back(shrimpFitsFile.at(i, 1));
						y0s.push_back(shrimpFitsFile.at(i, 2));
					}
					else {
						goodOrBadSpot.at(i) = 0;
					}
				}
				lineFit = fitDataToStraightLine(x0s, y0s);
				rotationAngle = atan(lineFit.at(0));
				std::cout << "After throwing away distant spots:";
				std::cout << "Angle of the fit line is " << rotationAngle << " radians = " << rotationAngle * 180.0/3.14159 << " degrees.\n";
				std::cout << "y intercept of the line is " << lineFit.at(1) << ".\n";
				rotateShrimpFitsFile(shrimpFitsFileName.c_str(), rotatedShrimpFitsFileName.c_str(), -rotationAngle, lineFit.at(1));
				
				
				
				//rotateShrimpFitsFile("spotFits.txt", "rotatedspotFits.txt", -rotationAngle, lineFit.at(1));
				rotateImage(inputFileName, "rotatedImage.txt", -rotationAngle, lineFit.at(1));
				
				ScienceFile rotatedImageFile("rotatedImage.txt");
				std::ofstream outputFile("countsPositions.txt");
				
				int numPixels = rotatedImageFile.numRows();
				for(i = 0; i < numPixels; i++)
				{
					int j;
					int numCountsInPixel = rotatedImageFile.at(i, 2) - pixelThresholdValue;
					numCountsInPixel *= 0.01;
					if(numCountsInPixel > 0)
						for(j = 0; j < numCountsInPixel; j++)
							outputFile << rotatedImageFile.at(i, 0) << "	" << rotatedImageFile.at(i, 1) << "\n";
				}
				outputFile.close();
			}
				break;
				
			case 'd':
			{//	<<	"d.	Concatenate countsPositions file\n"
				std::ofstream outputFile; // indata is like cin
				
				if(checkWhetherFileIsPresent("concatenatedCountsPositions.txt"))
				{
					outputFile.open("concatenatedCountsPositions.txt", std::ios::app);
				}
				else {
					outputFile.open("concatenatedCountsPositions.txt");
				}
				
				std::ifstream indata("countsPositions.txt"); // indata is like cin
				std::string line;
				
				while ( !indata.eof())
				{
					getline(indata, line);
					outputFile << line << "\n";
				}
				
				outputFile.close();
			}
				break;
				
			case 'e':
			{//	<<	"e.	Put histogram data in columns file\n"
				ScienceFile countsPositionsCountsFile("countsPositionsCounts.txt");
				ScienceFile countsPositionsBinsFile("countsPositionsBins.txt");
				
				ScienceFile newFile;
				newFile.addColumn(countsPositionsBinsFile.returnRow(0));
				newFile.addColumn(countsPositionsCountsFile.returnRow(0));
				newFile.writeToFile("nrHistogramData.txt");
				
				
				
				ScienceFile srHistogramCountsFile("errorCounts.txt");
				ScienceFile srHistogramBinsFile("errorValueBins.txt");
				
				ScienceFile newFile2;
				newFile2.addColumn(srHistogramBinsFile.returnRow(0));
				newFile2.addColumn(srHistogramCountsFile.returnRow(0));
				newFile2.writeToFile("srHistogramData.txt");
				
			}
				break;
				
			case 'f':
			{
				remove("concatenatedCountsPositions.txt");
				remove("concatenatedRotatedspotFits.txt");	
				remove("countsPositionsCounts.txt");
				remove("countsPositionsBins.txt");
				remove("nrHistogramData.txt");
				remove("errorCounts.txt");
				remove("errorValueBins.txt");
				remove("srHistogramData.txt");
				remove("foldersConcatenated.txt");
				
			}
				break;
			case 'A'://latest and greatest
			{	
				std::cout << "Automate the analysis by rotating and concatentating data stored in folders (steps a-d)...\n";
				
				std::string folderName;
				std::cout << "Enter folder name: ";
				std::cin >> folderName;
				
				double distanceFromLineCutOff;
				std::cout << "Enter distanceFromLineCutOff: ";
				std::cin >> distanceFromLineCutOff;
				
				std::string tiffFileName = folderName + "/" + folderName + ".tif";
				std::string shrimpFitsFileName = folderName + "/spotFits.txt";
				std::string rotatedShrimpFitsFileName = folderName + "/rotatedspotFits.txt";
				std::string rotatedImageFileName = folderName + "/rotatedImage.txt";
				std::string countsPositionsFileName = folderName + "/countsPositions.txt";
				
				double pixelThresholdValue;
				std::cout << "Please enter pixelThresholdValue (for the regular images): ";
				std::cin >> pixelThresholdValue;
				
				{//keep track of which folders you have added.
					std::ofstream outputFile; // indata is like cin
					if(checkWhetherFileIsPresent("foldersConcatenated.txt"))
						outputFile.open("foldersConcatenated.txt", std::ios::app);
					else
						outputFile.open("foldersConcatenated.txt");
					outputFile << folderName << ", Pixel threshold = " << pixelThresholdValue << ", distanceFromLineCutOff = " << distanceFromLineCutOff << "\n";
					outputFile.close();
				}
				
				ScienceFile shrimpFitsFile(shrimpFitsFileName.c_str());
				std::vector<double> x0s = shrimpFitsFile.returnColumn(1);
				std::vector<double> y0s = shrimpFitsFile.returnColumn(2);
				std::vector<double> lineFit = fitDataToStraightLine(x0s, y0s);
				double rotationAngle = atan(lineFit.at(0));
				std::cout << "Angle of the fit line is " << rotationAngle << " radians = " << rotationAngle * 180.0/3.14159 << " degrees.\n";
				std::cout << "y intercept of the line is " << lineFit.at(1) << ".\n";
				
				//	<<	"a.	Fit spots to a line and rotate coordinates\n"
				//Now get rid of the wild spots and refit the line.
				rotateShrimpFitsFile(shrimpFitsFileName.c_str(), rotatedShrimpFitsFileName.c_str(), -rotationAngle, lineFit.at(1));
				
				
				x0s.clear();
				y0s.clear();
				lineFit.clear();
				ScienceFile firstRotatedShrimpFitsFile(rotatedShrimpFitsFileName.c_str());
				
				
				
				int numSpots = firstRotatedShrimpFitsFile.numRows();
				int i;
				for(i = 0; i < numSpots; i++)
				{
					if(firstRotatedShrimpFitsFile.at(i, 2) < distanceFromLineCutOff)
					{
						x0s.push_back(shrimpFitsFile.at(i, 1));
						y0s.push_back(shrimpFitsFile.at(i, 2));
					}
				}
				lineFit = fitDataToStraightLine(x0s, y0s);
				rotationAngle = atan(lineFit.at(0));
				std::cout << "After throwing away distant spots:";
				std::cout << "Angle of the fit line is " << rotationAngle << " radians = " << rotationAngle * 180.0/3.14159 << " degrees.\n";
				std::cout << "y intercept of the line is " << lineFit.at(1) << ".\n";
				rotateShrimpFitsFile(shrimpFitsFileName.c_str(), rotatedShrimpFitsFileName.c_str(), -rotationAngle, lineFit.at(1));
				
				
				
				{//	<<	"b.	Concatenate rotatedShrimpFitsFile\n"
					std::ofstream outputFile; // indata is like cin
					if(checkWhetherFileIsPresent("concatenatedRotatedspotFits.txt"))
						outputFile.open("concatenatedRotatedspotFits.txt", std::ios::app);
					else
						outputFile.open("concatenatedRotatedspotFits.txt");				
					std::ifstream indata(rotatedShrimpFitsFileName.c_str()); // indata is like cin
					std::string line;
					while ( !indata.eof())
					{
						getline(indata, line);
						outputFile << line << "\n";
					}
					outputFile.close();
				}
				{//	<<	"c.	Fit super resolution localizations to a line, rotate image coordinates, and make a counts distribution file\n"
					rotateImage(tiffFileName.c_str(), rotatedImageFileName.c_str(), -rotationAngle, lineFit.at(1));
					
					ScienceFile rotatedImageFile(rotatedImageFileName.c_str());
					std::ofstream outputFile(countsPositionsFileName.c_str());
					
					int i;
					int numPixels = rotatedImageFile.numRows();
					for(i = 0; i < numPixels; i++)
					{
						int j;
						int numCountsInPixel = rotatedImageFile.at(i, 2) - pixelThresholdValue;
						numCountsInPixel *= 0.01;
						if(numCountsInPixel > 0)
							for(j = 0; j < numCountsInPixel; j++)
								outputFile << rotatedImageFile.at(i, 0) << "	" << rotatedImageFile.at(i, 1) << "\n";
					}
					outputFile.close();
				}
				{//	<<	"d.	Concatenate countsPositions file\n"
					std::ofstream outputFile; // indata is like cin
					if(checkWhetherFileIsPresent("concatenatedCountsPositions.txt"))
					{
						outputFile.open("concatenatedCountsPositions.txt", std::ios::app);
					}
					else {
						outputFile.open("concatenatedCountsPositions.txt");
					}
					std::ifstream indata(countsPositionsFileName.c_str()); // indata is like cin
					std::string line;
					while ( !indata.eof())
					{
						getline(indata, line);
						outputFile << line << "\n";
					}
					outputFile.close();
				}
			}
				break;
				
			case 'q':
				break;
			default:
				break;
		}
		
	}
}

