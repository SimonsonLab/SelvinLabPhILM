/*
 *  PhILMPreferences.h
 *  ReverseSTORM_SL
 *
 *  Created by Paul Simonson on 8/14/10.
 *  Copyright 2011 University of Illinois at Urbana-Champaign. All rights reserved.
 *
 */

#ifndef PhILMPreferences_H
#define PhILMPreferences_H

#include <string>
#include <cmath>

class PhILMPreferences 
{
    ///This class stores all of the preferences and parameters that might be needed globally by the program.
    
public:
	
    ///Variables loaded from file:
    int spotDetectionMethod;
    int dilationSteps;
    double spotDetectionIntegrationRadius;//Added July 8-12, 2011
    bool writeDetectedSpotsTIFFFiles;
    double maximumDetectionThreshold;
    bool throwAwayIntermediateFrames;
    int minimumNumberOfFramesToAverage;	
	int maxNumFramesToAverage;
    int spotFittingMethod;
    double cameraBaselineCounts;
    double countsToPhotonsConversionFactor;
    int emGain;
    double darkCountsNoise;
    double maximumLocalizationError;
	double minimumEllipticity, maximumEllipticity;
	double minimumSpotWidth, maximumSpotWidth;
    double minPeakIntensity, maxPeakIntensity;
	double minimumSpotWidthForStillDrawingGaussian;
	
	///Variables not loaded from preferences text file:
	double minimumSpotSeparation;
	double detectionThreshold;
	double zoomFactor;
	int drawingIntensityScalingFactor;
	bool usingBatchMode;
    std::string tiffFileName;
	std::string outputDirectory;
	std::string outputFilePrefix;
    int backwardsSubtractedImageZeroPoint;
    
    void setSomeDefaultParameters(void)
    {
        dilationSteps = 2;
        backwardsSubtractedImageZeroPoint = 32767;
        usingBatchMode = 0;
        outputDirectory = "./";
        
        minimumSpotSeparation = 6;
        detectionThreshold = 50;
        zoomFactor = 10.667;
        drawingIntensityScalingFactor = 1;
        minimumNumberOfFramesToAverage = 1;	
        drawingIntensityScalingFactor = 1;
        
        maximumDetectionThreshold = 0.0; //A value of 0.0 means that the program will not use a maximum detection threshold value.
        throwAwayIntermediateFrames = false;
        
        spotDetectionIntegrationRadius = 3.0;
        spotDetectionMethod = 2;
        
        drawingIntensityScalingFactor = 1;
        
        spotFittingMethod = 3;
        cameraBaselineCounts = 0;
        countsToPhotonsConversionFactor = 1;
        emGain = 0;
        
        minPeakIntensity = 0;
        maxPeakIntensity = 0;
    }

    
    
    double suggestADetectionThresholdUsingPeakPhotons(double medianPeakPhotonsPerFluorophorePerFrame, double medianSpotSigmaValue)
    {
        std::cout << "Current detection threshold value is " << detectionThreshold << ".\n";
        std::cout << "medianPeakPhotonsPerFluorophorePerFrame = " << medianPeakPhotonsPerFluorophorePerFrame << "\n";
        std::cout << "medianSpotSigmaValue = " << medianSpotSigmaValue << "\n";
        std::cout << "spotDetectionIntegrationRadius = " << spotDetectionIntegrationRadius << "\n";

        double suggestedDetectionThreshold = 25;
        
        switch (spotDetectionMethod) {
            case 1:
            {
                double temp1a = -0.5 * pow(spotDetectionIntegrationRadius/medianSpotSigmaValue, 2);
                double temp1b = -0.5 * pow((spotDetectionIntegrationRadius + 1)/medianSpotSigmaValue, 2);

                double temp2 = 1.0 - 2.0*exp(temp1a) + exp(temp1b);
                double temp3 = (medianPeakPhotonsPerFluorophorePerFrame/countsToPhotonsConversionFactor) * pow(medianSpotSigmaValue/spotDetectionIntegrationRadius, 2);
                suggestedDetectionThreshold = temp2*temp3;
            }
                break;
                
            case 2:
            {
                double temp1 = -0.5 * pow(spotDetectionIntegrationRadius/medianSpotSigmaValue, 2);
                double temp2 = 1.0 - exp(temp1);
                double temp3 = (medianPeakPhotonsPerFluorophorePerFrame/countsToPhotonsConversionFactor) * pow(medianSpotSigmaValue/spotDetectionIntegrationRadius, 2);
                suggestedDetectionThreshold = temp2*temp3;
            }
                break;
                
            default:
                break;
        }
        std::cout << "suggestedDetectionThreshold = " << suggestedDetectionThreshold << "\n";
        return suggestedDetectionThreshold;
    }
    
    double retrospectivelySuggestDetectionThreshold(void);
    double retrospectivelySuggestDetectionThreshold(int argc, char *argv[]);

    
    PhILMPreferences(std::string fileName)
    {
        setSomeDefaultParameters();
        
        if(checkWhetherFileIsPresent(fileName.c_str()))
        {
            loadPreferencesFile(fileName.c_str());
        }
        else {
            std::cout << "The file " << fileName << " was not found.  Now creating file " << fileName << " using default preferences.\n";
            generateDefaultPreferencesFile(fileName.c_str());
            loadPreferencesFile(fileName.c_str());
        }
    }
    
    int checkWhetherFileIsPresent(const char *cpath);
	int loadPreferencesFile(const char *);
	int generateDefaultPreferencesFile(std::string fileName);
    int saveCurrentPreferencesFile(std::string fileName);
	int setTIFFFileName(const char *fileName);
	int chooseOutputDirectoryUsingTIFFName(void);
	std::string returnOutputDirectory(void);
	std::string prefixWithOutputDirectory(const char *);
	std::string formOutputFilePath(std::string simpleFileName);
};	

#endif

