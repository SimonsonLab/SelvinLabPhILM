/*
 *  tiffFrameOperationsUsingMagick.cpp
 *  ReverseSTORM_SL
 *
 *  Created by Paul Simonson on 10/19/09.
 *  Copyright 2009 Champaign Illinois Stake. All rights reserved.
 *
 */

#include <iostream>

#include "tiffFrameOperationsUsingMagick.h"
#include "tiffFrameOperations.h"
#include "writeTIFFFileUsingMagick.h"

#include "tnt.h"


Magick::Image createNewMagick16BitImage(int columns, int rows);
Magick::ColorGray returnMagickColorUsingGrayScaleIntensity(int intensity);


Magick::Image returnMagickImageFromTNTArray(TNT::Array2D< int > imageArray)
{
	int rows, columns;
	columns = imageArray.dim1();
	rows = imageArray.dim2();
	
	Magick::Image newImage = createNewMagick16BitImage(columns, rows);
	
	/*
	 Magick::Pixels view(newImage);
	 Magick::PixelPacket *pixels = view.get(0,0,columns,rows); 
	 int i, j;
	 for(i = 0; i < columns; i++)
	 for(j = 0; j < rows; j++)
	 *pixels++ = returnMagickColorUsingGrayScaleIntensity(imageArray[i][rows - j - 1]); 
	 view.sync();*/
	
	int i, j;
	for(i = 0; i < columns; i++)
		for(j = 0; j < rows; j++)
			newImage.pixelColor( i, j, returnMagickColorUsingGrayScaleIntensity(imageArray[i][rows - j - 1]));
	
	return newImage;
}


TNT::Array2D< int > returnTNTArrayFromMagickImage(Magick::Image &inputImage)
{
	int rows, columns;
	columns = inputImage.columns();
	rows = inputImage.rows();
	
	TNT::Array2D< int > imageArray(columns, rows, 0);
	int i, j;
	for(i = 0; i < columns; i++)
		for(j = 0; j < rows; j++)
			imageArray[i][rows - j - 1] = inputImage.pixelColor( i, j).redQuantum();
	
	return imageArray;
}



//whichFrame should be the frame number using a counting system that starts with ONE.
TNT::Array2D< int > return2DIntArrayUsingMagick(std::vector<Magick::Image> &imageVector, int whichFrame)
{
	return returnTNTArrayFromMagickImage(imageVector.at(whichFrame - 1));
}


TNT::Array2D< int > return2DIntArrayUsingMagick(const char *TIFFFileName, int whichFrame)
{
	std::vector<Magick::Image> imageVector;
	Magick::readImages(&imageVector, TIFFFileName);	
	return returnTNTArrayFromMagickImage(imageVector.at(whichFrame - 1));
}

//startFrame and endFrame should be the frame number using a counting system that starts with ONE.
TNT::Array2D< int > returnIntArrayAverageOfFramesUsingMagick(std::vector<Magick::Image> &imageVector, int startFrame, int endFrame)
{	
	TNT::Stopwatch Q;
	
	
	int numFrames = imageVector.size();
	
	if (endFrame < 1) {
		endFrame = numFrames;
	}
	
	int numToAverage = endFrame - startFrame + 1;
	
	double multiplicationFactor = 1.0L/(double)numToAverage;
	
	int width, height;
	TNT::Array2D< int > tempImage1 = returnTNTArrayFromMagickImage(imageVector.at(0));
	width = tempImage1.dim1();
	height = tempImage1.dim2();
	//writeTIFFFileUsingMagick("1frame.tif", tempImage1);
	
	TNT::Array2D< double > averagedFrame(width,height,0.0);
	int i;
	for(i = startFrame; i < endFrame + 1; i++)
	{
		//std::cout << "i = " << i << ", startFrame = " << startFrame << ", endFrame = " << endFrame <<  "\n";

		TNT::Array2D< int > tempImage = returnTNTArrayFromMagickImage(imageVector.at(i-1));
		
		TNT::Array2D< double > tempImage2(width,height,0.0);
		int x,y;
		for (x = 0; x< width; x++) {
			for (y = 0; y<height; y++) {
				tempImage2[x][y] = (double)(tempImage[x][y]) * multiplicationFactor;
			}
		}
		
		//multiplyByAConstant(tempImage, multiplicationFactor);
		averagedFrame  = averagedFrame + tempImage2;
	}
	
	TNT::Array2D< int > averagedFrame2(width,height);
	int x,y;
	for (x = 0; x< width; x++) {
		for (y = 0; y<height; y++) {
			averagedFrame2[x][y] = (int)(averagedFrame[x][y]);
		}
	}

	//writeTIFFFileUsingMagick("ave.tif", averagedFrame2);
	
	//std::cout << "I made it this far...\n";

	return averagedFrame2;
}

TNT::Array2D< int > returnIntArrayAverageOfFramesUsingMagick(const char *inputFileName, int startFrame, int endFrame);


TNT::Array2D< int > returnStandardDeviationOfFramesUsingMagick(const char *inputFileName, int startFrame, int endFrame)
{
	///The start frame is ONE.
	
	TNT::Stopwatch Q;
	
	
	std::cout << "Calculating standard deviation image...\n";
	
	std::vector<Magick::Image> imageVector;

	Q.start();

	Magick::readImages(&imageVector, inputFileName);	
	
	std::cout << "Finished reading frames at " << Q.read() << ".\n";
	
	int numFrames = imageVector.size();

	if (endFrame < 1) {
		endFrame = numFrames;
	}
	

	int numToAverage = endFrame - startFrame + 1;

	std::cout << "Averaging frames...\n";
	Q.start();


	TNT::Array2D< int > averagedImage = returnIntArrayAverageOfFramesUsingMagick(imageVector, startFrame, endFrame);
	
	std::cout << "Finished averaging frames... " << Q.read() << ".\n";;

	if (numFrames < 2) {
		std::cout << "Sorry, this stack has less than 2 frames, so a standard deviation cannot be calculated!\n";
		return averagedImage;
	}
	
	//std::cout << "I made it this far 0...\n";

	Q.start();

	
	int width, height;
	width = averagedImage.dim1();
	height = averagedImage.dim2();	
	TNT::Array2D< double > intermediateStandardDeviationImage(width,height, 0.0);

	TNT::Array2D< int > standardDeviationImage(width,height,0);
	
	//std::cout << "I made it this far 1...\n";

	double multiplicationFactor = 1.0L/(double)(numToAverage-1);
	int i;
	for(i = startFrame; i < endFrame + 1; i++)
	{
		//std::cout << "i = " << i << ", startFrame = " << startFrame << ", endFrame = " << endFrame <<  "\n";
		TNT::Array2D< int > nextFrame = returnTNTArrayFromMagickImage(imageVector.at(i-1));
		int x,y;
		for (x = 0; x< width; x++) {
			for (y = 0; y<height; y++) {
				intermediateStandardDeviationImage[x][y] += multiplicationFactor * (double)((nextFrame[x][y] - averagedImage[x][y])*(nextFrame[x][y] - averagedImage[x][y]));
			}
		}
	}
	
	//std::cout << "I made it this far 2...\n";

	int x,y;

	for (x = 0; x< width; x++) {
		for (y = 0; y<height; y++) {
			standardDeviationImage[x][y] = sqrt(intermediateStandardDeviationImage[x][y]);
		}
	}
	
	
	std::cout << "Finished calculating standard deviation image..." << Q.read() << std::endl;

	return standardDeviationImage;
}






