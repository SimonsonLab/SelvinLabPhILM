#include <string.h>
#include "FreeImage.h"
#include <iostream>

static char FreeImageErrorMessage[1024];
void FreeImageErrorHandler(FREE_IMAGE_FORMAT fif, const char *message)
{
	strncpy(FreeImageErrorMessage, message, sizeof(FreeImageErrorMessage));
	FreeImageErrorMessage[sizeof(FreeImageErrorMessage)-1] = '\0';
	
	std::cout << "\n*** ";
	if(fif != FIF_UNKNOWN) {
		std::cout << FreeImage_GetFormatFromFIF(fif) << " Format\n";
	}
	std::cout << "FreeImage Error Message: " << message << "\n";
	std::cout << "***\n";
}

class FreeImageInitializer
{
public:
	FreeImageInitializer()
	{
		FreeImage_Initialise();
		FreeImage_SetOutputMessage(FreeImageErrorHandler);
		//NSLog(@"FreeImage initialized.");
		std::cout << "FreeImage initialized.\n";
		//NSLog([NSString stringWithCString:(const char *)FreeImage_GetCopyrightMessage() encoding:1]);
		std::cout << FreeImage_GetCopyrightMessage() << "\n";
		std::flush(std::cout);
	}

	~FreeImageInitializer()
	{
		FreeImage_DeInitialise();
		//NSLog(@"FreeImage de-initialized.");
		std::cout << "\nFreeImage de-initialized.\n";
	}
};
static FreeImageInitializer initializer;
