/*
 *  reversePhotobleachingSTORM.cpp
 *  ReverseSTORM
 *
 *  Created by Paul Simonson on 4/24/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

const bool verboseOutput = false;


#include <omp.h>
#include <cstring>
#include <vector>
#include <iostream>
#include <fstream>
#include <list>
#include <cmath>

#include "writeTIFFFileUsingMagick.h"
#include "PhILMCoreCode.h"
#include "return2DArrayFromMultiBitmap.h"
#include "ScienceFile.h"
#include "tiffStackOperations.h"
#include "tiffFrameOperations.h"
#include "returnSpotIntensity.h"
//#include "fitTo2DGaussianUsingGSL.h"
#include "fitTo2DEllipticalGaussian.h"
#include "tiffFrameOperations.h"
#include "FreeImage.h"
#include "SimonsonLibTIFF_IO.h"

//includes for method 2 spot fitting
#include "returnDataForGaussianFitting.h"
#include "MLE2DGaussianFitterPoissonian.h"
#include "MLE2DGaussianFitterGaussian.h"

using namespace Fitting2DEllipticalGaussianUsingGSL;

#define RESTRICTING_FRAME_RANGES

///Global variables
PhILMPreferences thePhILMPreferences("PhILMPreferences.txt");
const int newPixelOffset = 32767;
const double pixelShiftForDrawingSuperResolutionImages = 0.5;


namespace PhILM_namespace 
{	
	//Functions
	
	int checkForExitCommand(const char *cpath)
	{
		if(!strcmp(cpath, "q"))
			exit(0);
		if(!strcmp(cpath, "Q"))
			exit(0);
		if(!strcmp(cpath, "quit"))
			exit(0);
		if(!strcmp(cpath, "exit"))
			exit(0);
		if(!strcmp(cpath, "Quit"))
			exit(0);
		if(!strcmp(cpath, "Exit"))
			exit(0);
		if(!strcmp(cpath, "QUIT"))
			exit(0);
		if(!strcmp(cpath, "EXIT"))
			exit(0);
		if(!strcmp(cpath, "Get me outa here!"))
			exit(0);
		return 0;
	}
	
	
	int checkWhetherFileIsPresent(const char *cpath)
	{
		std::ifstream file; // indata is like cin
		file.open(cpath); // opens the file
		if(!file) { // file couldn't be opened
			return 0;
		}
		else
		{
			file.close();
			return 1;
		}
	}
	
	
    std::vector< TNT::Array2D< int > > returnBackwardsSubtracted(std::vector< TNT::Array2D< int > > &imageVector)
    {
        const bool verboseOutput = false;
        //const unsigned short newPixelOffset = 32767;
        
        if (verboseOutput) {
            std::cout << "Now backwards-subtracting...\n";
        }
        
        
        TNT::Array2D< int > originalFirstFrame = imageVector.at(0);
        
        if (verboseOutput) {
            std::cout << "Returned first frame from TIFF file...\n";
        }
        
        int width, height;
        width = originalFirstFrame.dim1();
        height = originalFirstFrame.dim2();
        TNT::Array2D< int > newPixelOffsetArray(width, height, newPixelOffset);
        
        int numFrames = imageVector.size();
        
        //The new image stack:
        std::vector<TNT::Array2D<int> > newImageList(numFrames);
        
        
        int j;
#pragma omp parallel for
        for(j = 1;  j < numFrames; j++)
        {
            if (verboseOutput) {
#pragma omp critical
                {
                    std::cout << "Now subtracting frame " << j + 1 << " from frame " << j << "...\n";
                }
            }
            TNT::Array2D< int > imageArray = imageVector.at(j-1);//return2DIntArrayFromMultiBitmap(multibitmap, j);
            imageArray = imageArray - imageVector.at(j);
            imageArray = imageArray + newPixelOffsetArray;
            newImageList.at(j - 1) = imageArray;
        }
        
        //Set the last frame to the offset.
        newImageList.at(numFrames - 1) = newPixelOffsetArray;
        
        std::cout << "Finished creation of sequentially-subtracted image.\n";
        return newImageList;
    }
    
    
	inline double separationDistanceSquared(const double x1, const double x2, const double y1, const double y2)
	{
		return (x1-x2)*(x1-x2) + (y1-y2)*(y1-y2);
		//return pow(x1-x2,2) + pow(y1-y2,2);
	}
    
	
    ScienceFile removeFrameRangesMarkedAsBad(ScienceFile &spotFrameRanges, std::vector<bool> &badSpotFlags)
    {
        ScienceFile goodFrameRanges;
        
        if ((unsigned int)spotFrameRanges.numRows() != badSpotFlags.size()) {
            std::cout << "Error in function removeFrameRangesMarkedAsBad\n\a";
            return goodFrameRanges;
        }
        
        int numSpots = spotFrameRanges.numRows();
        int i;
        for(i = 0; i < numSpots; i++)
        {
			if(badSpotFlags.at(i) == false)
            {
				goodFrameRanges.addRow(spotFrameRanges.returnRow(i));
            }
        }
        return goodFrameRanges;
    }
    
    
    void markSpotsThatAreTooCloseTogetherAsBad(ScienceFile &finalSpotFrameRanges, ScienceFile &detectedSpots, std::vector<bool> &badSpotFlags, double minimumSeparation)
    {
        ///Mark as bad those spots that are too close together.
        double minimumSeparationSquared = minimumSeparation * minimumSeparation;
        
        int numSpots = finalSpotFrameRanges.numRows();
        int i;
        
#pragma omp parallel for
        for(i = 0; i < numSpots - 1; i++)
        {
            int j;
            for (j = i + 1; j < numSpots; j++)
            {
                //if(i != j)
                {
                    if(finalSpotFrameRanges.at(j, 3) > finalSpotFrameRanges.at(i, 3))
                        break;
                    
                    if(finalSpotFrameRanges.at(i, 3) == finalSpotFrameRanges.at(j, 3))
                        if(separationDistanceSquared(finalSpotFrameRanges.returnElement(i, 0), 
                                                     finalSpotFrameRanges.returnElement(j, 0), 
                                                     finalSpotFrameRanges.returnElement(i, 1),
                                                     finalSpotFrameRanges.returnElement(j, 1))
                           < minimumSeparationSquared)
                        {
                            badSpotFlags.at(i) = true;
                            badSpotFlags.at(j) = true;
                        }
                }
            }
        }
        //End of marking close spots.
    }
    
    double returnMinSeparationSquared(double minimumSeparation)
    {
        if(minimumSeparation == 0)
		{
			std::cout << "Please enter minimum allowed spot separation: ";
			std::cin >> minimumSeparation;
		}
		if(minimumSeparation < 1)
			minimumSeparation = 1;
		return minimumSeparation * minimumSeparation;
    }
    
    enum DetectedSpotFilesColumns {
        xColumn = 0,
        yColumn, frameColumn, intensityColumn        
    };
    
    
	int fastCalculateOneSpotFrameRange(int i,
									   int numSpots,
									   int numAntiSpots,
									   double minimumSeparationSquared,
									   ScienceFile &detectedSpots, ScienceFile &detectedAntiSpots, 
									   std::vector<double> &xs, std::vector<double> &ys, 
									   std::vector<double> &detectedSpotsFrames, 
									   std::vector<double> &xsAntiSpots, std::vector<double> &ysAntiSpots, 
									   std::vector<double> &detectedAntiSpotsFrames, 
									   std::vector<double> &frame1, 
									   std::vector<double> &frame2, 
                                       std::vector<double> &frame3, 
									   std::vector<double> &frame4)
	{        
		int j;
		
		for (j = i; j < numSpots; j++) //compare the frames
		{
			if(i != j)
			{
				if(frame4[i] < detectedSpotsFrames[j])//then you have already found the maximum frame range.
				{
					break;
				}
				
				if(separationDistanceSquared(xs[i], 
											 xs[j], 
											 ys[i],
											 ys[j])
				   <= minimumSeparationSquared)
				{
					//std::cout << i << ", " << j << "\n";
					if(frame2[i] > detectedSpotsFrames[j])//You have to check to see whether or not it is greater because there can be more than one detected spot in a frame.
						if(frame1[i] < detectedSpotsFrames[j])
							frame1[i] = detectedSpotsFrames[j];
					
					if(frame2[i] < detectedSpotsFrames[j])//You have to check to see whether or not it is greater because there can be more than one detected spot in a frame.
						if(frame4[i] > detectedSpotsFrames[j])
						{
							frame4[i] = detectedSpotsFrames[j];
						}
				}
				
#ifdef RESTRICTING_FRAME_RANGES
				///This is for limiting how many frames after the photobleaching event it will go through.
				int currentFramesDistance = detectedSpotsFrames[j] - detectedSpotsFrames[i];
				if (currentFramesDistance > thePhILMPreferences.maxNumFramesToAverage) 
                {
					frame4[i] = frame2[i] + thePhILMPreferences.maxNumFramesToAverage;
					//std::cout << "Exceeded maxNumFramesToAverage in calculating spot frame ranges.  Jumping out of loop...\n";
					break;
					
				}
#endif
			}			
		}
		

		for (j = i; j > -1; j--)
		{
			if(i != j)
			{
				if(frame1[i] > detectedSpotsFrames[j])//then you have already found the minimum frame range.
				{
					break;
				}
				
				if(separationDistanceSquared(xs[i], 
											 xs[j], 
											 ys[i],
											 ys[j])
				   <= minimumSeparationSquared)
				{
					//std::cout << i << ", " << j << "\n";
					if(frame2[i] > detectedSpotsFrames[j])
						if(frame1[i] < detectedSpotsFrames[j])
							frame1[i] = detectedSpotsFrames[j] + 1;
					
					if(frame2[i] < detectedSpotsFrames[j])
                    {
						if(frame4[i] > detectedSpotsFrames[j])
						{
							frame4[i] = detectedSpotsFrames[j];
						}
                    }
				}
			}			
		}
		
        static int startingAntiSpot = 0;

		if (numAntiSpots > 0) 
		{			
			int firstOfCheckedRange, lastOfCheckedRange;
			
			for (j = startingAntiSpot; j > -1; j--)
			{
				if(frame1[i] > detectedAntiSpotsFrames[j])//then you have already found the minimum frame range.
				{
					break;
				}
				
				if(separationDistanceSquared(xs[i], 
											 xsAntiSpots[j], 
											 ys[i],
											 ysAntiSpots[j])
				   <= minimumSeparationSquared)
				{
					if(frame2[i] > detectedAntiSpotsFrames[j])
						if(frame1[i] <= detectedAntiSpotsFrames[j])
							frame1[i] = detectedAntiSpotsFrames[j] + 1;
					
					if(frame2[i] < detectedAntiSpotsFrames[j])
						if(frame4[i] > detectedAntiSpotsFrames[j])
							frame4[i] = detectedAntiSpotsFrames[j];
				}
				
			}
			firstOfCheckedRange = j;
			
			for (j = startingAntiSpot; j < numAntiSpots; j++)
			{
				if(frame4[i] < detectedAntiSpotsFrames[j])//then you have already found the maximum frame range.
				{
					break;
				}
				
				if(separationDistanceSquared(xs[i], 
											 xsAntiSpots[j], 
											 ys[i],
											 ysAntiSpots[j])
				   <= minimumSeparationSquared)
				{
					if(frame2[i] > detectedAntiSpotsFrames[j])
						if(frame1[i] <= detectedAntiSpotsFrames[j])
							frame1[i] = detectedAntiSpotsFrames[j] + 1;
					
					if(frame2[i] < detectedAntiSpotsFrames[j])
						if(frame4[i] > detectedAntiSpotsFrames[j])
							frame4[i] = detectedAntiSpotsFrames[j];
				}
				
#ifdef RESTRICTING_FRAME_RANGES
				///This is for limiting how many frames after the photobleaching event it will go through.
				int currentFramesDistance = detectedAntiSpotsFrames[j] - detectedSpotsFrames[i];
				if (currentFramesDistance > thePhILMPreferences.maxNumFramesToAverage) 
				{
					frame4[i] = detectedSpotsFrames[i] + thePhILMPreferences.maxNumFramesToAverage;
					//std::cout << "Exceeded maxNumFramesToAverage in calculating spot frame ranges.  Jumping out of loop...\n";
					break;
				}
#endif
			}
			lastOfCheckedRange = j;
			
			startingAntiSpot = 0.5*(lastOfCheckedRange - firstOfCheckedRange) + firstOfCheckedRange;
			
			if(startingAntiSpot < 0)
			{
				startingAntiSpot = 0;
			}
			if (startingAntiSpot > numAntiSpots - 1) {
				startingAntiSpot = numAntiSpots - 1;
			}
		}
		
		if (frame2[i] - frame1[i] > thePhILMPreferences.maxNumFramesToAverage) {
			frame1[i] = frame2[i] - thePhILMPreferences.maxNumFramesToAverage;
		}
		
		
		if (frame4[i] > detectedSpotsFrames[i] + thePhILMPreferences.maxNumFramesToAverage) 
		{
			frame4[i] = detectedSpotsFrames[i] + thePhILMPreferences.maxNumFramesToAverage;
		}
		
        frame3[i] = frame2[i] + 1;
        
        if (verboseOutput) 
        {
			std::cout << "Spot " << i + 1 << ", frame averaging ranges: " << frame1[i] << "	" << frame2[i] << "	" << frame3[i] <<"\t" << frame4[i] << "\n";
		}
        
		return 0;
	}
	

    
    

    
    ///This function is used to determine what frames can be averaged before and after a photobleaching event.
	int fastCalculateSpotFrameRanges(const char *tiffFileName, double minimumSeparation)
	{		
		int numFrames = SimonsonLibTIFF_IO::countFramesInTIFFStack(tiffFileName);
		double minimumSeparationSquared = returnMinSeparationSquared(minimumSeparation);

		//std::cout << (thePhILMPreferences.formOutputFilePath("detectedSpots.txt").c_str()) << "\n";
		ScienceFile detectedSpots(thePhILMPreferences.formOutputFilePath("detectedSpots.txt").c_str());
		int numSpots = detectedSpots.numRows();
        
		//std::cout << (thePhILMPreferences.formOutputFilePath("detectedAntiSpots.txt").c_str()) << "\n";
		ScienceFile detectedAntiSpots(thePhILMPreferences.formOutputFilePath("detectedAntiSpots.txt").c_str());
		int numAntiSpots = detectedAntiSpots.numRows();
		
		std::vector<double> xsAntiSpots; 
		std::vector<double> ysAntiSpots; 
		std::vector<double> detectedAntiSpotsFrames;
		if (numAntiSpots > 0) 
		{
			xsAntiSpots = detectedAntiSpots.returnColumn(xColumn); 
			ysAntiSpots = detectedAntiSpots.returnColumn(yColumn); 
			detectedAntiSpotsFrames = detectedAntiSpots.returnColumn(frameColumn);
		}
		
        ScienceFile finalFinalSpotFrameRanges;
		if(numSpots > 0)
		{
			std::vector<double> xs = detectedSpots.returnColumn(xColumn); 
			std::vector<double> ys = detectedSpots.returnColumn(yColumn); 
			std::vector<double> detectedSpotsFrames = detectedSpots.returnColumn(frameColumn);
			std::vector<double> frame1(numSpots, 1);
			std::vector<double> frame2 = detectedSpotsFrames;
            std::vector<double> frame3 = frame2;		
			std::vector<double> frame4(numSpots, numFrames);		
            std::vector<bool> badSpotFlags(numSpots, false);
            
			int i;
            //#pragma omp parallel for//<--seems to introduce bugs
			for(i = 0; i < numSpots; i++)
			{
                if (verboseOutput) {
                    std::cout << "Calculating frame averaging for spot " << i + 1 << ".\n";
                }
                
                if (thePhILMPreferences.maximumDetectionThreshold && detectedSpots.at(i, intensityColumn) > thePhILMPreferences.maximumDetectionThreshold) 
                {
                    badSpotFlags[i] = true;
                }
                else
                {
                    fastCalculateOneSpotFrameRange(i,numSpots,numAntiSpots,
                                                   minimumSeparationSquared,
                                                   detectedSpots, detectedAntiSpots, 
                                                   xs, ys, 
                                                   detectedSpotsFrames, 
                                                   xsAntiSpots, ysAntiSpots, 
                                                   detectedAntiSpotsFrames, 
                                                   frame1, 
                                                   frame2, 
                                                   frame3,
                                                   frame4);
                }
                
			}
			if (verboseOutput) {
				std::cout << "Now making last corrections to spot frame ranges...\n";
			}
            ScienceFile finalSpotFrameRanges;

            finalSpotFrameRanges.addColumn(xs);
			finalSpotFrameRanges.addColumn(ys);
			finalSpotFrameRanges.addColumn(frame1);
			finalSpotFrameRanges.addColumn(frame2);
            finalSpotFrameRanges.addColumn(frame3);
			finalSpotFrameRanges.addColumn(frame4);
			//finalSpotFrameRanges.display();
            markSpotsThatAreTooCloseTogetherAsBad(finalSpotFrameRanges, detectedSpots, badSpotFlags, minimumSeparation);
            
            finalFinalSpotFrameRanges = removeFrameRangesMarkedAsBad(finalSpotFrameRanges, badSpotFlags);
		}
        finalFinalSpotFrameRanges.writeToFile(thePhILMPreferences.formOutputFilePath("finalSpotFrameRanges.txt").c_str());

		return 0;
	}
	
	
    
	int fastCalculateOneAntiSpotFrameRange(int i,
										   int numSpots,
										   int numAntiSpots,
										   double minimumSeparationSquared,
										   ScienceFile &detectedSpots, ScienceFile &detectedAntiSpots, 
										   std::vector<double> &xsSpots, std::vector<double> &ysSpots, 
										   std::vector<double> &detectedSpotsFrames, 
										   std::vector<double> &xsAntiSpots, std::vector<double> &ysAntiSpots, 
										   std::vector<double> &detectedAntiSpotsFrames, 
										   std::vector<double> &AS_frame1, 
										   std::vector<double> &AS_frame2, 
                                           std::vector<double> &AS_frame3, 
										   std::vector<double> &AS_frame4)
	{
		
		int j;
		
		for (j = i; j < numAntiSpots; j++)
		{
			if(i != j)
			{
				if(AS_frame4[i] < detectedAntiSpotsFrames[j])//then you have already found the maximum frame range.
				{
					break;
				}
				
				if(separationDistanceSquared(xsAntiSpots[i], 
											 xsAntiSpots[j], 
											 ysAntiSpots[i],
											 ysAntiSpots[j])
				   <= minimumSeparationSquared)
				{
					//std::cout << i << ", " << j << "\n";
					if(detectedAntiSpotsFrames[i] > detectedAntiSpotsFrames[j])
						if(AS_frame1[i] < detectedAntiSpotsFrames[j])
							AS_frame1[i] = detectedAntiSpotsFrames[j];
					
					if(detectedAntiSpotsFrames[i] < detectedAntiSpots.at(j, 2))
						if(AS_frame4[i] > detectedAntiSpotsFrames[j])
							AS_frame4[i] = detectedAntiSpotsFrames[j];
				}
				
#ifdef RESTRICTING_FRAME_RANGES
				///This is for limiting how many frames after the photobleaching event it will go through.
				int currentFramesDistance = detectedAntiSpots.at(j, 2) - detectedAntiSpots.at(i, 2);
				if (currentFramesDistance > thePhILMPreferences.maxNumFramesToAverage) 
				{
					AS_frame4[i] = detectedAntiSpots.at(i, 2) + thePhILMPreferences.maxNumFramesToAverage;
					//std::cout << "Exceeded maxNumFramesToAverage in calculating spot frame ranges.  Jumping out of loop...\n";
					break;
				}
#endif
			}
		}
		
		for (j = i; j > -1; j--)
		{
			if(i != j)
			{
				if(AS_frame1[i] > detectedAntiSpotsFrames[j])//then you have already found the maximum frame range.
				{
					break;
				}
				
				if(separationDistanceSquared(xsAntiSpots[i], 
											 xsAntiSpots[j], 
											 ysAntiSpots[i],
											 ysAntiSpots[j])
				   <= minimumSeparationSquared)
				{
					//std::cout << i << ", " << j << "\n";
					if(detectedAntiSpotsFrames[i] > detectedAntiSpotsFrames[j])
						if(AS_frame1[i] < detectedAntiSpotsFrames[j])
							AS_frame1[i] = detectedAntiSpotsFrames[j];
					
					if(detectedAntiSpotsFrames[i] < detectedAntiSpots.at(j, 2))
						if(AS_frame4[i] > detectedAntiSpotsFrames[j])
							AS_frame4[i] = detectedAntiSpotsFrames[j];
				}
				
#ifdef RESTRICTING_FRAME_RANGES
				///This is for limiting how many frames after the photobleaching event it will go through.
				int currentFramesDistance = detectedAntiSpots.at(j, 2) - detectedAntiSpots.at(i, 2);
				if (currentFramesDistance > thePhILMPreferences.maxNumFramesToAverage) 
				{
					AS_frame4[i] = thePhILMPreferences.maxNumFramesToAverage + detectedAntiSpots.at(i, 2);
					break;
				}
#endif
			}
		}
		
        static int startingSpot = 0;
		
		if(numSpots)
		{			
			int firstOfCheckedRange, lastOfCheckedRange;
			
			for (j = startingSpot; j > - 1; j--)
			{
				if(AS_frame1[i] > detectedSpotsFrames[j])//then you have already found the maximum frame range.
				{
					break;
				}
				
				if(separationDistanceSquared(xsSpots[j], 
											 xsAntiSpots[i], 
											 ysSpots[j],
											 ysAntiSpots[i])
				   <= minimumSeparationSquared)
				{
					if(AS_frame2[i] > detectedSpotsFrames[j])
						if(AS_frame1[i] <= detectedSpotsFrames[j])
							AS_frame1[i] = detectedSpotsFrames[j] + 1;
					
					if(AS_frame2[i] < detectedSpotsFrames[j])
						if(AS_frame4[i] > detectedSpotsFrames[j])
							AS_frame4[i] = detectedSpotsFrames[j];
				}
				
				
#ifdef RESTRICTING_FRAME_RANGES
				///This is for limiting how many frames after the photobleaching event it will go through--hopefully the processing will be faster.
				int currentFramesDistance = detectedSpotsFrames[j] - detectedAntiSpotsFrames[i];
				if (currentFramesDistance > thePhILMPreferences.maxNumFramesToAverage) 
				{
					AS_frame4[i] = detectedAntiSpotsFrames[i] + thePhILMPreferences.maxNumFramesToAverage;
					
					//std::cout << "Exceeded maxNumFramesToAverage in calculating spot frame ranges.  Jumping out of loop...\n";
					break;
				}
#endif
			}
			firstOfCheckedRange = j;
			
			for (j = startingSpot; j < numSpots; j++)
			{
				if(AS_frame4[i] < detectedSpotsFrames[j])//then you have already found the maximum frame range.
				{
					break;
				}
				
				if(separationDistanceSquared(xsSpots[j], 
											 xsAntiSpots[i], 
											 ysSpots[j],
											 ysAntiSpots[i])
				   <= minimumSeparationSquared)
				{
					if(detectedAntiSpotsFrames[i] > detectedSpotsFrames[j])
						if(AS_frame1[i] <= detectedSpotsFrames[j])
							AS_frame1[i] = detectedSpotsFrames[j] + 1;
					
					if(detectedAntiSpotsFrames[i] < detectedSpotsFrames[j])
						if(AS_frame4[i] > detectedSpotsFrames[j])
							AS_frame4[i] = detectedSpotsFrames[j];
				}
				
#ifdef RESTRICTING_FRAME_RANGES
				///This is for limiting how many frames after the photobleaching event it will go through--hopefully the processing will be faster.
				int currentFramesDistance = detectedSpotsFrames[j] - detectedAntiSpotsFrames[i];
				if (currentFramesDistance > thePhILMPreferences.maxNumFramesToAverage) {
					/*
					 if(AS_frame4[i] > detectedSpotsFrames[j])
					 {
					 AS_frame4[i] = detectedSpotsFrames[j];
					 }*/
					AS_frame4[i] = thePhILMPreferences.maxNumFramesToAverage + detectedAntiSpotsFrames[i];
					//std::cout << "Exceeded maxNumFramesToAverage in calculating spot frame ranges.  Jumping out of loop...\n";
					break;
				}
#endif
			}
			lastOfCheckedRange = j;
			
			startingSpot = 0.5*(lastOfCheckedRange - firstOfCheckedRange) + firstOfCheckedRange;
			
			if(startingSpot < 0)
			{
				startingSpot = 0;
			}
			if (startingSpot > numSpots - 1) {
				startingSpot = numSpots - 1;
			}
			
		}
		
#ifdef RESTRICTING_FRAME_RANGES
        
		if (AS_frame4[i] > detectedAntiSpots.at(i, 2) + thePhILMPreferences.maxNumFramesToAverage) 
		{
			AS_frame4[i] = detectedAntiSpots.at(i, 2) + thePhILMPreferences.maxNumFramesToAverage;
		}
		
		if (AS_frame1[i] < AS_frame2[i] - thePhILMPreferences.maxNumFramesToAverage) 
		{
			AS_frame1[i] = AS_frame2[i] - thePhILMPreferences.maxNumFramesToAverage;
		}
		
#endif
        
        AS_frame3[i] = AS_frame2[i] + 1;
        
		if (verboseOutput) 
		{
			std::cout << "Anti-spot " << i + 1 << ", frame averaging ranges: " << AS_frame1[i] << "	" << AS_frame2[i] << "	" << AS_frame3[i] << "\t" << AS_frame4[i] << "\n";
		}
		return 0;	
	}
	
    
	///This function is used to determine what frames can be averaged before and after a photoactivation event.
	int fastCalculateAntiSpotFrameRanges(const char *tiffFileName, double minimumSeparation)
	{		
		ScienceFile detectedAntiSpots(thePhILMPreferences.formOutputFilePath("detectedAntiSpots.txt").c_str());
		int numAntiSpots = detectedAntiSpots.numRows();

        ScienceFile finalFinalSpotFrameRanges;
		if(numAntiSpots)
		{
            int numFrames = SimonsonLibTIFF_IO::countFramesInTIFFStack(tiffFileName);
            double minimumSeparationSquared = returnMinSeparationSquared(minimumSeparation);
            
            ScienceFile detectedSpots(thePhILMPreferences.formOutputFilePath("detectedSpots.txt").c_str());
            int numSpots = detectedSpots.numRows();
			std::vector<double> xsSpots; 
			std::vector<double> ysSpots; 
			std::vector<double> detectedSpotsFrames;
			if(numSpots)
			{
				xsSpots = detectedSpots.returnColumn(0); 
				ysSpots = detectedSpots.returnColumn(1); 
				detectedSpotsFrames = detectedSpots.returnColumn(2);
			}
			
			std::vector<double> xsAntiSpots = detectedAntiSpots.returnColumn(0); 
			std::vector<double> ysAntiSpots = detectedAntiSpots.returnColumn(1); 
			std::vector<double> detectedAntiSpotsFrames = detectedAntiSpots.returnColumn(2);
			std::vector<double> AS_frame1(numAntiSpots, 1);
			std::vector<double> AS_frame2 = detectedAntiSpots.returnColumn(2);
            std::vector<double> AS_frame3 = AS_frame2;
			std::vector<double> AS_frame4(numAntiSpots, numFrames);
            std::vector<bool> badSpotFlags(numAntiSpots, false);
            
			int i;
            double maximumDetectionThreshold = thePhILMPreferences.maximumDetectionThreshold;
            //#pragma omp parallel for//<--seems to introduce bugs
			for(i = 0; i < numAntiSpots; i++)
			{
                if (maximumDetectionThreshold && -1.0*detectedAntiSpots.at(i, intensityColumn) > maximumDetectionThreshold) 
                {
                    badSpotFlags[i] = true;
                }
                else
                {
                    fastCalculateOneAntiSpotFrameRange(i,numSpots,numAntiSpots,
                                                       minimumSeparationSquared,
                                                       detectedSpots, detectedAntiSpots, 
                                                       xsSpots, ysSpots, 
                                                       detectedSpotsFrames, 
                                                       xsAntiSpots, ysAntiSpots, 
                                                       detectedAntiSpotsFrames, 
                                                       AS_frame1, 
                                                       AS_frame2, 
                                                       AS_frame3,
                                                       AS_frame4);
                }
			}
			
			if (verboseOutput) {
				std::cout << "Now making last corrections to anti-spot frame ranges...\n";
			}
			
            /*
#pragma omp parallel for
			for(i = 0; i < numAntiSpots; i++)
			{
				if (AS_frame2.at(i) > 1)
					if(AS_frame1.at(i) != 1)
						AS_frame1.at(i) += 1;
			}
             */
			
            ScienceFile finalSpotFrameRanges;
			finalSpotFrameRanges.addColumn(xsAntiSpots);
			finalSpotFrameRanges.addColumn(ysAntiSpots);
			finalSpotFrameRanges.addColumn(AS_frame1);
			finalSpotFrameRanges.addColumn(AS_frame2);
            finalSpotFrameRanges.addColumn(AS_frame3);
			finalSpotFrameRanges.addColumn(AS_frame4);
			//finalSpotFrameRanges.display();
            markSpotsThatAreTooCloseTogetherAsBad(finalSpotFrameRanges, detectedAntiSpots, badSpotFlags, minimumSeparation);
            finalFinalSpotFrameRanges = removeFrameRangesMarkedAsBad(finalSpotFrameRanges, badSpotFlags);
            
            std::cout << "ranges... " << finalSpotFrameRanges.numRows() << ", " << finalFinalSpotFrameRanges.numRows() << "\n";

		}
        finalFinalSpotFrameRanges.writeToFile(thePhILMPreferences.formOutputFilePath("finalAntiSpotFrameRanges.txt").c_str());

		return 0;
	}
	
    
    
    void throwAwayIntermediateFramesUsingFrameRangesFiles(void)
    {
        ///This function opens the frame averaging range files and overwrites them with modified versions that eliminate the 
        
        {
            ScienceFile spotFrameRanges(thePhILMPreferences.formOutputFilePath("finalSpotFrameRanges.txt").c_str());
            ScienceFile newSpotFrameRanges;
            int numSpots = spotFrameRanges.numRows();
            int i;
            for (i = 0; i < numSpots; i++) {
                if (spotFrameRanges.at(i, 3) - spotFrameRanges.at(i, 2) > 2)
                {
                    if (spotFrameRanges.at(i, 5) - spotFrameRanges.at(i, 4) > 2)
                    {
                        std::vector<double> newRow(6);
                        newRow[0] = spotFrameRanges.at(i,0);
                        newRow[1] = spotFrameRanges.at(i,1);
                        newRow[2] = spotFrameRanges.at(i,2) + 1;
                        newRow[3] = spotFrameRanges.at(i,3) - 1;
                        newRow[4] = spotFrameRanges.at(i,4) + 1;
                        newRow[5] = spotFrameRanges.at(i,5) - 1;
                        newSpotFrameRanges.addRow(newRow);
                    }
                    
                }
            }
            newSpotFrameRanges.writeToFile(thePhILMPreferences.formOutputFilePath("finalSpotFrameRanges.txt").c_str(), "%x\ty\tf1\tf2\tf3\tf4");
        }
        
        {
            ScienceFile spotFrameRanges(thePhILMPreferences.formOutputFilePath("finalAntiSpotFrameRanges.txt").c_str());
            ScienceFile newSpotFrameRanges;
            int numSpots = spotFrameRanges.numRows();
            int i;
            for (i = 0; i < numSpots; i++) {
                if (spotFrameRanges.at(i, 3) - spotFrameRanges.at(i, 2) > 2)
                {
                    if (spotFrameRanges.at(i, 5) - spotFrameRanges.at(i, 4) > 2)
                    {
                        std::vector<double> newRow(6);
                        newRow[0] = spotFrameRanges.at(i,0);
                        newRow[1] = spotFrameRanges.at(i,1);
                        newRow[2] = spotFrameRanges.at(i,2) + 1;
                        newRow[3] = spotFrameRanges.at(i,3) - 1;
                        newRow[4] = spotFrameRanges.at(i,4) + 1;
                        newRow[5] = spotFrameRanges.at(i,5) - 1;
                        newSpotFrameRanges.addRow(newRow);
                    }
                    
                }
            }
            newSpotFrameRanges.writeToFile(thePhILMPreferences.formOutputFilePath("finalAntiSpotFrameRanges.txt").c_str(), "%x\ty\tf1\tf2\tf3\tf4");
        }
        
    }
    
	
	int checkWhetherSpotIsGood(TwoDGaussianFittingParametersAndErrors &spotFit, bool verboseSpotChecking)
	{
		if (!verboseOutput) {
			verboseSpotChecking = false;
		}
		
		
		if(verboseSpotChecking)
		{
			if(spotFit.peakHeight <= 0
			   || spotFit.xCenterValueError <= 0
			   || spotFit.yCenterValueError <= 0) //Of course it has to be greater than zero...
			{
				std::cout << "The peak height (" << spotFit.peakHeight << ") is less than or equal to zero.\n";
				return 0;
			}
			else if(spotFit.xCenterValueError > thePhILMPreferences.maximumLocalizationError 
					|| spotFit.yCenterValueError > thePhILMPreferences.maximumLocalizationError)
			{
				std::cout << "The spot's localization error (" << spotFit.xCenterValueError << " or " << spotFit.yCenterValueError << ") is too big.\n";
				return 0;
			}
			else if(std::isinf(spotFit.peakHeightError) || std::isnan(spotFit.peakHeightError) || spotFit.peakHeightError <= 0)
			{
				std::cout << "The peakHeightError (" << spotFit.peakHeightError << ") could not be calculated correctly.\n";
				return 0;
			}
			else if(spotFit.xCenterValue < 0 || spotFit.yCenterValue < 0)
			{
				std::cout << "The spot center is outside the image area.\n";
				return 0;
			}
			else if(spotFit.xWidth < thePhILMPreferences.minimumSpotWidth
					|| spotFit.yWidth < thePhILMPreferences.minimumSpotWidth 
					|| spotFit.xWidth > thePhILMPreferences.maximumSpotWidth
					|| spotFit.yWidth > thePhILMPreferences.maximumSpotWidth)
			{
				std::cout << "The spot is too narrow or too wide.\n";
				return 0;
			}
			else if(spotFit.ellipticity() < thePhILMPreferences.minimumEllipticity
					|| spotFit.ellipticity() > thePhILMPreferences.maximumEllipticity)
			{
				std::cout << "The spot ellipticity (" << spotFit.ellipticity() << ") does not meet the ellipticity requirements.\n";
				return 0;
			}
            else if(spotFit.peakHeight < thePhILMPreferences.minPeakIntensity)
            {
                {
                    std::cout << "The spot peak intensity (" << spotFit.peakHeight << ") is < " << thePhILMPreferences.minPeakIntensity << ".\n";

                    return false;
                }
            }
            else if(thePhILMPreferences.maxPeakIntensity && spotFit.peakHeight > thePhILMPreferences.maxPeakIntensity)
            {
                {
                    std::cout << "The spot peak intensity (" << spotFit.peakHeight << ") is > " << thePhILMPreferences.maxPeakIntensity << ".\n";
                    return false;
                }
            }
			else {
				std::cout << "THE SPOT IS GOOD.\n";
				return 1;
			}
			
		}
		else
		{
			if(spotFit.peakHeight <= 0
			   || spotFit.xCenterValueError <= 0
			   || spotFit.yCenterValueError <= 0) //Of course it has to be greater than zero...
			{
				//std::cout << "The peak height is less than or equal to zero.\n";
				return 0;
			}
			else if(spotFit.xCenterValueError > thePhILMPreferences.maximumLocalizationError 
					|| spotFit.yCenterValueError > thePhILMPreferences.maximumLocalizationError)
			{
				//std::cout << "The spot's localization error is too big.\n";
				return 0;
			}
			else if(std::isinf(spotFit.peakHeightError) || std::isnan(spotFit.peakHeightError) || spotFit.peakHeightError <= 0)
			{
				//std::cout << "The peakHeightError could not be calculated.\n";
				return 0;
			}
			else if(spotFit.xCenterValue < 0 || spotFit.yCenterValue < 0)
			{
				//std::cout << "The spot is outside the image area.\n";
				return 0;
			}
			else if(spotFit.xWidth < thePhILMPreferences.minimumSpotWidth
					|| spotFit.yWidth < thePhILMPreferences.minimumSpotWidth 
					|| spotFit.xWidth > thePhILMPreferences.maximumSpotWidth
					|| spotFit.yWidth > thePhILMPreferences.maximumSpotWidth)
			{
				//std::cout << "The spot is too narrow or too wide.\n";
				return 0;
			}
			else if(spotFit.ellipticity() < thePhILMPreferences.minimumEllipticity
					|| spotFit.ellipticity() > thePhILMPreferences.maximumEllipticity)
			{
				//std::cout << "The spot does not meet the ellipticity requirements.\n";
				return 0;
			}
            else if(spotFit.peakHeight < thePhILMPreferences.minPeakIntensity)
            {
                return false;
            }
            else if(thePhILMPreferences.maxPeakIntensity && spotFit.peakHeight > thePhILMPreferences.maxPeakIntensity)
            {
                return false;
            }
			else {
				//std::cout << "The spot is good.\n";
				return 1;
			}
		}
        std::cout << "Error in checkWhetherSpotIsGood function!\a\n";
        return true;
	}
    
	
    ///This function takes all the detected spots and their frame averaging ranges, and then it calculates spot fits.
	int createSpotFitsFile(const char *inputFileName, int minimumNumberOfFramesToAverage, double darkCountsNoise)
    {
        std::vector< TNT::Array2D< int > > imageVector;
		SimonsonLibTIFF_IO::readTIFFStack(inputFileName, imageVector);
        return createSpotFitsFile(imageVector, minimumNumberOfFramesToAverage, darkCountsNoise);
    }
    
    
    std::vector<double> estimateVariances(const double framesAveragedA, const std::vector<double> &intensitiesA, const double framesAveragedB, const std::vector<double> &intensitiesB)
    {
        std::vector<double> varianceEstimates(intensitiesA.size());
        double readoutPhotonsSquared = thePhILMPreferences.countsToPhotonsConversionFactor * thePhILMPreferences.darkCountsNoise * thePhILMPreferences.countsToPhotonsConversionFactor * thePhILMPreferences.darkCountsNoise;
        unsigned int n;
        for (n = 0; n < varianceEstimates.size(); n++) {
            
            if (intensitiesA[n] < 0) {
                std::cout << "Error: the pixel intensity value is less than zero!  Check the camera baseline value in the PhILMPreferences.txt file...\a\n";
            }
            
            if (intensitiesB[n] < 0) {
                std::cout << "Error: the pixel intensity value is less than zero!  Check the camera baseline value in the PhILMPreferences.txt file...\a\n";
            }
            
            varianceEstimates[n] = 
                (intensitiesA[n] + readoutPhotonsSquared)/framesAveragedA 
                + (intensitiesB[n] + readoutPhotonsSquared)/framesAveragedB;
            if (thePhILMPreferences.emGain) {
                varianceEstimates[n] *= 2.0;
            }
        }
        return varianceEstimates;
    }
    
    std::vector<double> returnVectorDifference(const std::vector<double> &intensitiesA, const std::vector<double> &intensitiesB)
    {
        std::vector<double> result(intensitiesA.size());
        unsigned int n;
        for (n = 0; n < result.size(); n++) {
            result[n] = intensitiesA[n] - intensitiesB[n];
        }
        return result;
    }
    
    
    TwoDGaussianFittingParametersAndErrors convertMLE2DGaussianFitter_GaussianFitResultsToSpotFitClass(const std::vector<double> &fitParameters, const std::vector<double> &crlb)
    {
        TwoDGaussianFittingParametersAndErrors spotFit;
        
        spotFit.peakHeight = fitParameters[0];
        spotFit.xCenterValue = fitParameters[1];
        spotFit.yCenterValue = fitParameters[2];
        spotFit.xWidth = fitParameters[3];
        spotFit.yWidth = spotFit.xWidth;
        spotFit.tiltAngle = 0;
        spotFit.background = 0;
        
        spotFit.peakHeightError = crlb[0];
        spotFit.xCenterValueError = crlb[1];
        spotFit.yCenterValueError = crlb[2];
        spotFit.xWidthError = crlb[3];
        spotFit.yWidthError = spotFit.xWidthError;
        spotFit.tiltAngleError = 0;
        spotFit.backgroundError = 0;
        
        return spotFit;
    }
    
    
    void convertCountsImagesToPhotonsImages(TNT::Array2D<double> beforePhotobleachingArray, TNT::Array2D<double> afterPhotobleachingArray)
    {
        subtractAConstant(beforePhotobleachingArray, thePhILMPreferences.cameraBaselineCounts);
        subtractAConstant(afterPhotobleachingArray, thePhILMPreferences.cameraBaselineCounts);
        multiplyByAConstant(beforePhotobleachingArray, thePhILMPreferences.countsToPhotonsConversionFactor);
        multiplyByAConstant(afterPhotobleachingArray, thePhILMPreferences.countsToPhotonsConversionFactor);
    }
    
    
    TwoDGaussianFittingParametersAndErrors fitUsingMethod3(TNT::Array2D<double> beforePhotobleachingArray,
                                                           TNT::Array2D<double> afterPhotobleachingArray,
                                                           double spotRangesXPixel, double spotRangesYPixel,
                                                           int numFramesAveragedBeforePhotobleaching, 
                                                           int numFramesAveragedAfterPhotobleaching,
                                                           double spotFittingRadius
                                                           )
    {
        //std::cout << "Fitting with method 3\n";
        class MLE2DGaussianFitter_Gaussian fitter;
        fitter.maxIterations = 100;
        
        const int xColumn = 0;
        const int yColumn = 1;
        const int intensityColumn = 2;
                
        ScienceFile spotInformation = returnDataForGaussianFitting(beforePhotobleachingArray, spotRangesXPixel, spotRangesYPixel, spotFittingRadius);
        ScienceFile imageToSubtract = returnDataForGaussianFitting(afterPhotobleachingArray, spotRangesXPixel, spotRangesYPixel, spotFittingRadius);
        
        fitter.xValues = spotInformation.returnColumn(xColumn);
        fitter.yValues = spotInformation.returnColumn(yColumn);

        fitter.wValues = returnVectorDifference(spotInformation.returnColumn(intensityColumn), imageToSubtract.returnColumn(intensityColumn));

        fitter.varianceValues = estimateVariances(numFramesAveragedBeforePhotobleaching, spotInformation.returnColumn(intensityColumn), numFramesAveragedAfterPhotobleaching, imageToSubtract.returnColumn(intensityColumn));
        
        std::vector<double> fitParameters = fitter.fitParameters(fitter.guessStartingParameters());
        std::vector<double> crlb = fitter.calculateCRLB(fitParameters);
        
        //fitter.printCRLB(fitParameters);
        //std::cout << "iterations = " << fitter.numIterations << ", tolerance = " << fitter.fitTolerance << "\n";
        
        TwoDGaussianFittingParametersAndErrors spotFit = convertMLE2DGaussianFitter_GaussianFitResultsToSpotFitClass(fitParameters, crlb);
        spotFit.numFitIterations = fitter.numIterations;
        spotFit.fitTolerance = fitter.fitTolerance;
        
        //spotFit.printFit();
        return spotFit;
    }
    
    
    void addFitToSpotFitsFile(ScienceFile &spotFitsFile, TwoDGaussianFittingParametersAndErrors &spotFit, int frame1,int frame2,int frame3, int frame4, bool isItAPhotobleachingEvent)
    {
        std::vector<double> theFit = spotFit.returnFitAsVector();
        theFit.push_back(frame1);
        theFit.push_back(frame2);
        theFit.push_back(frame3);
        theFit.push_back(frame4);
        theFit.push_back(isItAPhotobleachingEvent);
        theFit.push_back(spotFit.numFitIterations);
#pragma omp critical
        {
            if (spotFitsFile.data.max_size() == spotFitsFile.data.size()) {
                std::cout << "Already reached max size of the number of possible spot fits...\n";
            }
            
            spotFitsFile.addRow(theFit);
        }
    }
    
    
    ///This function takes all the detected spots and their frame averaging ranges, and then it calculates spot fits.
	int createSpotFitsFile(std::vector< TNT::Array2D< int > > &imageVector, int minimumNumberOfFramesToAverage, double darkCountsNoise)
	{	
		int numGoodFitsFound = 0;
        int spotFittingMethod = thePhILMPreferences.spotFittingMethod;
        
		if(minimumNumberOfFramesToAverage < 1)
		{
			std::cout << "minimumNumberOfFramesToAverage was entered as " << minimumNumberOfFramesToAverage << ".  Resetting to 1.\n";
			minimumNumberOfFramesToAverage = 1;
		}
		
		double spotFittingRadius = 4;
		ScienceFile spotFitsFile;			
		
		//std::cout << "Maximum number of good spot fits that can currently be contained in memory is " << spotFitsFile.data.max_size() << "\n";
        
		if (checkWhetherFileIsPresent(thePhILMPreferences.formOutputFilePath("finalSpotFrameRanges.txt").c_str())) 
		{
			ScienceFile spotRanges(thePhILMPreferences.formOutputFilePath("finalSpotFrameRanges.txt").c_str());
			int numSpots = spotRanges.numRows();
			int i;
#pragma omp parallel for
			for(i = 0; i < numSpots; i++)
			{
				int spotRangesXPixel = spotRanges.at(i, 0);
				int spotRangesYPixel = spotRanges.at(i, 1);
                
				int frameWhenSpotAppears = spotRanges.at(i, 2);
				int lastFrameBeforeSpotDisappears = spotRanges.at(i, 3);
                int firstSubtractableFrame = spotRanges.at(i, 4);
				int lastSubtractableFrame = spotRanges.at(i, 5);
				
				int numFramesAveragedBeforePhotobleaching = lastFrameBeforeSpotDisappears - frameWhenSpotAppears + 1;
				int numFramesAveragedAfterPhotobleaching = lastSubtractableFrame - firstSubtractableFrame + 1;
				
				if(numFramesAveragedBeforePhotobleaching > minimumNumberOfFramesToAverage - 1)
				{
					if(numFramesAveragedAfterPhotobleaching > minimumNumberOfFramesToAverage - 1)
					{
						if (verboseOutput) {
#pragma omp critical
							{
								std::cout << "Now fitting spot " << i + 1 << "...\n";
								std::cout << frameWhenSpotAppears << "	" << lastFrameBeforeSpotDisappears << "	"<< firstSubtractableFrame << "\t" << lastSubtractableFrame << "\n";
							}
						}

                        TNT::Array2D<double> beforePhotobleachingArray = SimonsonLibTIFF_IO::returnAverageOfFramesAsDoubleArray(imageVector, frameWhenSpotAppears, lastFrameBeforeSpotDisappears);

                        TNT::Array2D<double> afterPhotobleachingArray = SimonsonLibTIFF_IO::returnAverageOfFramesAsDoubleArray(imageVector, firstSubtractableFrame, lastSubtractableFrame);

                        
                        convertCountsImagesToPhotonsImages(beforePhotobleachingArray, afterPhotobleachingArray);

                        TwoDGaussianFittingParametersAndErrors spotFit;

                        //Apparently the bugs with OpenMP go away when I get rid of switch statements...                        
                        if(spotFittingMethod == 3)//Case 3: Gaussian distributed noise
                        {
                            //std::cout << "Fitting with method 3\n";
                            spotFit = fitUsingMethod3(beforePhotobleachingArray,
                                                      afterPhotobleachingArray,
                                                      spotRangesXPixel,  spotRangesYPixel,
                                                      numFramesAveragedBeforePhotobleaching, 
                                                      numFramesAveragedAfterPhotobleaching,
                                                      spotFittingRadius
                                                      );
                        }
                        else if(spotFittingMethod == 2)//   case 2://Poisson-distributed MLE with round 2D Gaussian
                        {
                            //std::cout << "Fitting with method 2\n";
                            
                            class ImageFitter fitter;
                            fitter.maxIterations = 20;
                            
                            const int xColumn = 0;
                            const int yColumn = 1;
                            const int intensityColumn = 2;
                            
                            //subtractAConstant(beforePhotobleachingArray, cameraBaselineCounts);
                            //subtractAConstant(afterPhotobleachingArray, cameraBaselineCounts);
                            
                            
                            ScienceFile spotInformation = returnDataForGaussianFitting(beforePhotobleachingArray, spotRangesXPixel, spotRangesYPixel, spotFittingRadius);
                            ScienceFile imageToSubtract = returnDataForGaussianFitting(afterPhotobleachingArray, spotRangesXPixel, spotRangesYPixel, spotFittingRadius);
                            
                            fitter.xValues = spotInformation.returnColumn(xColumn);
                            fitter.yValues = spotInformation.returnColumn(yColumn);
                            fitter.zValues = std::vector<double>(fitter.xValues.size(), 1);
                            fitter.expectedBackgroundValues = imageToSubtract.returnColumn(intensityColumn);
                            fitter.observedValues = spotInformation.returnColumn(intensityColumn);
                            
                            std::vector<double> fitParameters = fitter.fitParameters(fitter.guessStartingParameters());
                            std::vector<double> crlb = fitter.calculateCRLB(fitParameters);
                            
                            spotFit.peakHeight = fitParameters[0];
                            spotFit.xCenterValue = fitParameters[1];
                            spotFit.yCenterValue = fitParameters[2];
                            spotFit.xWidth = fitParameters[3];
                            spotFit.yWidth = spotFit.xWidth;
                            spotFit.tiltAngle = 0;
                            spotFit.background = 0;
                            
                            spotFit.peakHeightError = crlb[0];
                            spotFit.xCenterValueError = crlb[1];
                            spotFit.yCenterValueError = crlb[2];
                            spotFit.xWidthError = crlb[3];
                            spotFit.yWidthError = spotFit.xWidthError;
                            spotFit.tiltAngleError = 0;
                            spotFit.backgroundError = 0;
                            
                            spotFit.numFitIterations = fitter.numIterations;
                            spotFit.fitTolerance = fitter.fitTolerance;
                            
                            //spotFit.printFit();
                        }
                        else//default to case 1://weighted 2D elliptical Gaussian fitting with Levenberg-Marquardt
                        {
                            spotFit = subtractRoundImageAndFitTo2DGaussian(beforePhotobleachingArray,
                                                                           afterPhotobleachingArray,
                                                                           darkCountsNoise, 
                                                                           spotRangesXPixel, 
                                                                           spotRangesYPixel, 
                                                                           spotFittingRadius,
                                                                           numFramesAveragedBeforePhotobleaching,
                                                                           numFramesAveragedAfterPhotobleaching);
                        }
						
						if(checkWhetherSpotIsGood(spotFit))
						{
							numGoodFitsFound++;

                            addFitToSpotFitsFile(spotFitsFile, spotFit, frameWhenSpotAppears, lastFrameBeforeSpotDisappears, firstSubtractableFrame, lastSubtractableFrame, true);

						}	
					}
				}
			}
		}
		
		if (checkWhetherFileIsPresent(thePhILMPreferences.formOutputFilePath("finalAntiSpotFrameRanges.txt").c_str())) 
		{
			ScienceFile antiSpotRanges(thePhILMPreferences.formOutputFilePath("finalAntiSpotFrameRanges.txt").c_str());
			int numAntiSpots = antiSpotRanges.numRows();
            int i;
#pragma omp parallel for //schedule(guided, 20)
			for(i = 0; i < numAntiSpots; i++)
			{
                int spotRangesXPixel = antiSpotRanges.at(i, 0);
				int spotRangesYPixel = antiSpotRanges.at(i, 1);
                
				int earliestSubtractableFrame = antiSpotRanges.at(i, 2);
				int lastFrameBeforeSpotAppears = antiSpotRanges.at(i, 3);
                int frameInWhichSpotAppears = antiSpotRanges.at(i, 4);
				int lastFrameBeforeSpotCannotBeSingledOut = antiSpotRanges.at(i, 5);
				
                
                int numFramesAveragedBeforePhotobleaching = lastFrameBeforeSpotCannotBeSingledOut - frameInWhichSpotAppears + 1;
				int numFramesAveragedAfterPhotobleaching = lastFrameBeforeSpotAppears - earliestSubtractableFrame + 1;
                
				if(lastFrameBeforeSpotCannotBeSingledOut - frameInWhichSpotAppears > minimumNumberOfFramesToAverage - 2)
				{
					if(lastFrameBeforeSpotAppears - earliestSubtractableFrame > minimumNumberOfFramesToAverage - 2)
					{
						if (verboseOutput) 
						{
#pragma omp critical
							{
								std::cout << "Now fitting anti-spot " << i + 1 << "...\n";
								std::cout << earliestSubtractableFrame << "	" << lastFrameBeforeSpotAppears << "	" << frameInWhichSpotAppears << "\t" << lastFrameBeforeSpotCannotBeSingledOut << "\n";
							}
							
						}
						
						TNT::Array2D<double> beforePhotobleachingArray = SimonsonLibTIFF_IO::returnAverageOfFramesAsDoubleArray(imageVector, frameInWhichSpotAppears, lastFrameBeforeSpotCannotBeSingledOut);
						TNT::Array2D<double> afterPhotobleachingArray = SimonsonLibTIFF_IO::returnAverageOfFramesAsDoubleArray(imageVector, earliestSubtractableFrame, lastFrameBeforeSpotAppears);
												
                        convertCountsImagesToPhotonsImages(beforePhotobleachingArray, afterPhotobleachingArray);

                        TwoDGaussianFittingParametersAndErrors spotFit;
                        
                        
                        if(spotFittingMethod == 3)//Case 3: Gaussian distributed noise
                        {
                            //std::cout << "Fitting with method 3\n";
                            spotFit = fitUsingMethod3(beforePhotobleachingArray,
                                                      afterPhotobleachingArray,
                                                      spotRangesXPixel,  spotRangesYPixel,
                                                      numFramesAveragedBeforePhotobleaching, 
                                                      numFramesAveragedAfterPhotobleaching,
                                                      spotFittingRadius
                                                      );
                        }
                        else if(spotFittingMethod == 2)//case 2://Poisson-distributed MLE with round 2D Gaussian
                        {
                            class ImageFitter fitter;
                            fitter.maxIterations = 20;
                            
                            const int xColumn = 0;
                            const int yColumn = 1;
                            const int intensityColumn = 2;
                            
                            
                            //subtractAConstant(beforePhotobleachingArray, cameraBaselineCounts);
                            //subtractAConstant(afterPhotobleachingArray, cameraBaselineCounts);
                            
                            
                            ScienceFile spotInformation = returnDataForGaussianFitting(beforePhotobleachingArray, antiSpotRanges.at(i, 0), antiSpotRanges.at(i, 1), spotFittingRadius);
                            ScienceFile imageToSubtract = returnDataForGaussianFitting(afterPhotobleachingArray, antiSpotRanges.at(i, 0), antiSpotRanges.at(i, 1), spotFittingRadius);
                            
                            fitter.xValues = spotInformation.returnColumn(xColumn);
                            fitter.yValues = spotInformation.returnColumn(yColumn);
                            fitter.zValues = std::vector<double>(fitter.xValues.size(), 1);
                            fitter.expectedBackgroundValues = imageToSubtract.returnColumn(intensityColumn);
                            fitter.observedValues = spotInformation.returnColumn(intensityColumn);
                            
                            std::vector<double> fitParameters = fitter.fitParameters(fitter.guessStartingParameters());
                            std::vector<double> crlb = fitter.calculateCRLB(fitParameters);
                            
                            spotFit.peakHeight = fitParameters[0];
                            spotFit.xCenterValue = fitParameters[1];
                            spotFit.yCenterValue = fitParameters[2];
                            spotFit.xWidth = fitParameters[3];
                            spotFit.yWidth = spotFit.xWidth;
                            spotFit.tiltAngle = 0;
                            spotFit.background = 0;
                            
                            spotFit.peakHeightError = crlb[0];
                            spotFit.xCenterValueError = crlb[1];
                            spotFit.yCenterValueError = crlb[2];
                            spotFit.xWidthError = crlb[3];
                            spotFit.yWidthError = spotFit.xWidthError;
                            spotFit.tiltAngleError = 0;
                            spotFit.backgroundError = 0;
                            
                            spotFit.numFitIterations = fitter.numIterations;
                            spotFit.fitTolerance = fitter.fitTolerance;
                            
                            //spotFit.printFit();
                        }
                        else//case 1://weighted 2D elliptical Gaussian fitting with Levenberg-Marquardt
                        {
                            spotFit = subtractRoundImageAndFitTo2DGaussian(beforePhotobleachingArray,
                                                                           afterPhotobleachingArray,
                                                                           darkCountsNoise, 
                                                                           antiSpotRanges.at(i, 0), 
                                                                           antiSpotRanges.at(i, 1), 
                                                                           spotFittingRadius);
                        }
                        
                        
						if(checkWhetherSpotIsGood(spotFit))
						{
							numGoodFitsFound++;
                            addFitToSpotFitsFile(spotFitsFile, spotFit, earliestSubtractableFrame, lastFrameBeforeSpotAppears, frameInWhichSpotAppears, lastFrameBeforeSpotCannotBeSingledOut, false);
						}
					}
				}
			}
		}
		
		std::cout << "Finished the fitting...\n";
		std::cout << "Number of good spot fits found = " << numGoodFitsFound << ".\n";
		char spotFitsFileHeader[] = "%%peakHeight	x0	y0	xWidth	yWidth	background	tiltAngle	peakHeightError	x0Error	y0Error	xWidthError	yWidthError	backgroundError	tiltAngleError	frame1\tframe2\tframe3\tframe4\tspot?\tfitIterations";
		
		spotFitsFile.writeToFile(thePhILMPreferences.formOutputFilePath("spotFits.txt").c_str(), spotFitsFileHeader);
		
		std::cout << "\a";
        		
		return numGoodFitsFound;
	}
	
    
    
	///Used in FastPhILM.
	int createSpotFitsFileFromBackwardsSubtracted(const char *inputFileName, double darkCountsNoise, double minimumSeparation)
	{	
		int numGoodFitsFound = 0;
		double spotFittingRadius = 4;
		
		std::vector<Magick::Image> imageVector;
		Magick::readImages(&imageVector, inputFileName);
		
		
		ScienceFile detectedSpots(thePhILMPreferences.formOutputFilePath("detectedSpots.txt").c_str());
		
		if(minimumSeparation)
		{
			;
		}
		
		
		int numSpots = detectedSpots.numRows();
		
		const int xColumn = 0;
		const int yColumn = 1;
		const int frameColumn = 2;
		
		ScienceFile shrimpFits;
		int i;
		for(i = 0; i < numSpots; i++)
		{
			if (verboseOutput) {
				std::cout << "Now fitting spot " << i + 1 << ", which is in frame " << detectedSpots.at(i, frameColumn) << "...\n";
			}
			
			TwoDGaussianFittingParametersAndErrors spotFit = fitIndicatedSpotTo2DGaussian(imageVector, detectedSpots.at(i,frameColumn), darkCountsNoise, detectedSpots.at(i,xColumn), detectedSpots.at(i,yColumn), spotFittingRadius);
			
			if(checkWhetherSpotIsGood(spotFit))
			{
				numGoodFitsFound++;
				std::vector<double> theFit = spotFit.returnFitAsVector();
				theFit.push_back(detectedSpots.at(i, frameColumn));
				theFit.push_back(detectedSpots.at(i, frameColumn));
				theFit.push_back(detectedSpots.at(i, frameColumn));
				theFit.push_back(1);
                theFit.push_back(spotFit.numFitIterations);
				shrimpFits.addRow(theFit);
			}					
		}
		
		
		std::cout << "Finished the fitting...\n";
		std::cout << "Number of good spot fits found = " << numGoodFitsFound << ".\n";
		char shrimpFileHeader[] = "%%peakHeight	x0	y0	xWidth	yWidth	background	tiltAngle	peakHeightError	x0Error	y0Error	xWidthError	yWidthError	backgroundError tiltAngleError";
		//std::cout << "Header: " << shrimpFileHeader << "\n";
		//shrimpFits.display();
		
		shrimpFits.writeToFile(thePhILMPreferences.formOutputFilePath("spotFits.txt").c_str(), shrimpFileHeader);
		
		std::cout << "\a";
		return numGoodFitsFound;
	}
    
}


