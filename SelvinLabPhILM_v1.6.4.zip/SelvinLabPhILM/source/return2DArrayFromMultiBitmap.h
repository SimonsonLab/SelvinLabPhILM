/*
 *  return2DArrayFromMultiBitmap.h
 *  TIFFStackEditor
 *
 *  Created by Paul Simonson on 10/2/06.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef return2DArrayFromMultiBitmap_H
#define return2DArrayFromMultiBitmap_H

#include "FreeImage.h"
#include "tnt.h"

namespace Return2DArray  
{
	//whichFrame should be the frame number using a counting system that starts with ONE.
	TNT::Array2D< unsigned short > return2DArrayFromMultiBitmap(FIMULTIBITMAP *MTmultibitmap, int whichFrame);
	TNT::Array2D< double > return2DDoubleArrayFromMultiBitmap(FIMULTIBITMAP *MTmultibitmap, int whichFrame);
	TNT::Array2D< int > return2DIntArrayFromMultiBitmap(FIMULTIBITMAP *MTmultibitmap, int whichFrame);
	TNT::Array2D< int > return2DIntArrayFromMultiBitmap(const char *TIFFFileName, int whichFrame);
	
	//startFrame and endFrame should be the frame number using a counting system that starts with ONE.
	TNT::Array2D< double > returnDoubleArrayAverageOfFrames(FIMULTIBITMAP *MTmultibitmap, int startFrame, int endFrame);
	TNT::Array2D< int > returnIntArrayAverageOfFrames(FIMULTIBITMAP *MTmultibitmap, int startFrame, int endFrame);
	TNT::Array2D< int > returnIntArrayAverageOfFrames(const char *inputFileName, int startFrame, int endFrame);
}

#endif



