//
//  SuperResolutionPlotting.h
//  SelvinLabPhILM_XCode
//
//  Created by Paul Simonson on 8/3/11.
//  Copyright 2011 University of Illinois at Urbana-Champaign. All rights reserved.
//


#ifndef SuperResolutionPlotting_H
#define SuperResolutionPlotting_H

#include <string>
#include <fstream>

#include "twoDGaussianFit.h"
#include "ScienceFile.h"
#include "tnt.h"

namespace SuperResolutionPlotting {
    
    
    class PixelsPlot
    {
    public:
        unsigned int originalDim1, originalDim2;
        double zoomFactor;
        std::string outputTIFFFileName;
        bool verboseOutput;
        double pixelShiftForDrawingSuperResolutionImages;
        bool usingStageDriftCorrection;
        int numNormalSpotsDrawn;
		int numAntiSpotsDrawn;
		int numSpotsDrawn;
        ScienceFile stageDriftCorrectionFile;
        TNT::Array2D<int> superResolutionImage;
        std::string plottingMethodName;
        
        void setDefaults(void)
        {
            originalDim1 = 0;
            originalDim2 = 0;
            zoomFactor = 1.0;
            verboseOutput = false;
            pixelShiftForDrawingSuperResolutionImages = 0.5;
            usingStageDriftCorrection = false;
            numNormalSpotsDrawn = 0;
            numAntiSpotsDrawn = 0;
            numSpotsDrawn = 0;
        }
        
        PixelsPlot()
        {
            setDefaults();
            plottingMethodName = "pixels";
        }
        
        virtual void plotSingleSpot(TwoDGaussianFittingParametersAndErrors scaledSpotFit, TNT::Array2D<int> superResolutionImage);
        void plotSpotFits(void);
        bool checkWhetherFileIsPresent(const char *cpath)
        {
            std::ifstream file; // indata is like cin
            file.open(cpath); // opens the file
            if(!file) { // file couldn't be opened
                return false;
            }
            else
            {
                file.close();
                return true;
            }
        }
        void movePastHeaderLines(std::ifstream &indata);
        int readALineInAsSpotFit(std::ifstream &indata, TwoDGaussianFittingParametersAndErrors &spotFit, int &normalSpotFlag);
        TwoDGaussianFittingParametersAndErrors returnSpotFitScaledForSuperResolutionPixels(TwoDGaussianFittingParametersAndErrors spotFit, int frameWherePhotobleachingOccurs);
    };
    
    
    class RoundNormalizedSpotsPlot : public PixelsPlot
    {
    public:
        double normalizedTotalSpotIntensity;
        
        RoundNormalizedSpotsPlot() : PixelsPlot()
        {
            normalizedTotalSpotIntensity = 1000.0;
            plottingMethodName = "round, normalized spots";
        }
        
        virtual void plotSingleSpot(TwoDGaussianFittingParametersAndErrors scaledSpotFit, TNT::Array2D<int> superResolutionImage);
        
        double round2DGaussianIntegratedOverPixel(double x, 
                                                  double y, 
                                                  double peakHeight, 
                                                  double x0, 
                                                  double y0, 
                                                  double sigma);
    };
    
}


#endif
