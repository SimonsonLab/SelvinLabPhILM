clear data;



reply = input('What is the name of the spot fits file?: ', 'shrimpFits.txt');
if isempty(reply)
	reply = '../shrimpFits.txt';
end


pixelSizeString = input('What is the pixel size (in nm)? ', '106.67');
if isempty(pixelSizeString)
	pixelSizeString = '106.67';
end

pixelSize = str2num(pixelSizeString);

data = load(reply);

peakHeights = data(:,1);
figure(100);
title("Peak Heights");
xlabel("Intensity (a.u.)");
hist(peakHeights, 20);

x0Errors = data(:,9).*pixelSize;
figure(200);
title("Spot localization error");
xlabel("Error in x (nm)");
hist(x0Errors, 20);

photobleachingFrames = data(:,16);
figure(300);
title("Frame in which drawn spots photobleach");
xlabel("Frame");
hist(photobleachingFrames, 40);


clear data2;

data2 = load('detectedSpots.txt');

detectedSpotsIntensities = data2(:,4);
figure(400);
xlabel("Intensity (a.u.)");
hist(detectedSpotsIntensities, 40);